---
type: plan
status: active  # Phase A/B/C 已完成，D/E 待实施
created: 2026-06-01
tags:
  - implementation-plan
  - competition
  - roadmap
---

# NDLMPanel-Agent 下一步实现方案

[[Design-1]] [[Design-2]] [[Skeleton-Design]] [[Gap-Analysis]] [[Operational-Flow]] [[MCP-Deep-Dive]]

---

## 0. 赛题约束与现实场景分析

### 0.1 硬约束

| 约束 | 值 | 影响 |
|------|-----|------|
| 目标平台 | LoongArch + 麒麟高级服务器版 V11 | 禁止 pydantic/openai-sdk/psutil 等含 C/Rust 扩展的依赖 |
| Python 版本 | 3.10 | 可用 `str \| None` 语法，但无 `tomllib`（用 JSON 配置） |
| 外部依赖 | **零** | 所有功能用 stdlib 实现 |
| 包管理 | `venv` + `pip`（不用 uv） | 安装脚本用标准命令 |
| 集成方式 | 作为 Python 包被后端 import | 不独立启动进程，不走 stdio transport |

### 0.2 赛题核心考察点（推测）

根据"智能运维 Agent"赛题定位和原项目 Task01 的分析文档，赛题关注以下维度：

| 维度 | 赛题可能的关注点 | 当前状态 (2026-06-01) |
|------|-----------------|:--:|
| **安全防护** | Prompt Injection 检测、危险命令拦截、多级审批、最小权限执行 | ✅ 27组规则 + risk_scorer + 审批闭环(approve/reject/timeout) |
| **审计追溯** | 全链路日志、防篡改哈希链、敏感脱敏、可查询回溯 | ✅ 模块完成，AgentCore 集成待做 |
| **MCP 协议** | 是否实现标准 MCP 协议（即便没有官方 SDK） | ✅ 核心 4 方法 + schemas 自动生成 |
| **运维能力** | 能否覆盖磁盘/进程/网络/日志/服务等核心运维场景 | ✅ 48 工具/5 插件(全部 psutil→/proc+subprocess) |
| **LLM 适配** | 多供应商支持、流式、重试、零外部依赖 | ✅ 工厂(DeepSeek/Qwen/vLLM)+真流式+指数退避 |
| **零依赖适配** | 能否在目标平台上开箱即用 | ✅ 全部 stdlib |
| **后端对接** | 流式 SSE 输出、标准事件协议 | ✅ OpenAI/Claude SSE 适配器 |
| **Agent 推理** | ReAct 循环、工具调用、人审闭环 | ✅ 审批闭环打通，待 Context/Audit 集成 |

### 0.3 演示场景设计

评委可能看到的典型交互（按从简单到复杂排列）：

```
场景 1 — 安全拦截演示（最核心竞争力）
  用户: "帮我执行 rm -rf /"
  Agent: → Injection/危险命令检测 → BLOCK → 审计日志

场景 2 — 只读查询
  用户: "帮我看看系统负载情况"
  Agent: → getCpuInfo() + getMemoryInfo() → 用中文给出结论

场景 3 — 诊断 + 安全审批
  用户: "分析磁盘为什么满了，帮我清理"
  Agent: → disk.usage() → disk.find_large_files() → 生成清理方案
       → "发现 /var/log/journal 占用 12GB，建议清理。是否继续？"
  用户: 批准
  Agent: → journalctl --vacuum-size=500M → 报告结果

场景 4 — 根因分析
  用户: "nginx 服务启动失败，帮我排查"
  Agent: → service.status("nginx") → log.query_journal("nginx")
       → "发现端口 80 被占用，进程 PID 1234 (apache2)"
       → process.tree(1234) → 给出建议
```

这四个场景覆盖了赛题核心考察点，**应该是实现计划的验收标准**。

---

## 1. 总体策略：增量叠加，每阶段可演示

```
当前基线 (122 项测试通过) + 零外部依赖 + 48 工具
    │
    ▼ [✅ 已完成] ──────────────────────────────────────┐
Phase A: 修 Bug + 安全地基  ──→ 危险命令被拦截 (场景 1)       │
    │                                                       │
    ▼ [✅ 已完成] ────────────────────────────────────┐     │
Phase B: Provider 工厂 + 真机 API 测试  ──→ LLM 调用链路可验证│   │
    │                                                     │   │
    ▼ [✅ 已完成] ──────────────────────────────────┐     │   │
Phase C: 补插件 + 自动注册  ──→ 诊断可跑 (场景 1+2)  │     │   │
    │                                               │     │   │
    ▼                                               │     │   │
Phase D: Core 集成审计 + Context + 审批闭环  ──→ 完整演示│   │   │
    │                                               │     │   │
    ▼                                               │     │   │
Phase E: Router + Skills + 对接文档  ──→ 全部场景 + 后端集成  │
```

---

## 2. Phase A: 修 Bug + 安全地基 ✅ 已完成
> 测试 54→96，3 P0 bug 修复，27 组安全规则，风险评分，.env+日志初始化

### 2.A.1 修复 3 个 P0 Bug

**Bug 1 — APPROVAL_REQUIRED 假闭环** (`agent_core/agent_loop.py:129-135`)

```python
# 当前 (BUG):
elif verdict.value == "require_confirm":
    stream.emit(EventType.APPROVAL_REQUIRED, {...})
    toolOutput = await self._executeTool(name, args)  # ← 不应该执行！

# 目标:
elif verdict.value == "require_confirm":
    actionId = gen_tool_call_id()
    stream.emit(EventType.APPROVAL_REQUIRED, {
        "tool_name": name, "arguments": args,
        "action_id": actionId,
    })
    # 等待外部 approve() 或 reject()，不执行工具
    decision = await self._waitForApproval(actionId)
    if decision["approved"]:
        toolOutput = await self._executeTool(name, args)
    else:
        toolOutput = f"[用户拒绝] {decision.get('reason', '')}"
```

实现方案：在 AgentCore 中增加 `asyncio.Event` 字典，`_waitForApproval()` 等待对应事件的 set。AgentSession 新增 `approve(actionId)` / `reject(actionId, reason)` 方法，调用时 set 对应事件。

**Bug 2 — prompt_builder.py `messages` 属性崩溃** (`agent_core/prompt_builder.py:86-88`)

```python
# 当前: 引用不存在的 self._messages
@property
def messages(self) -> list[dict]:
    return self._messages

# 修复: 删除这个无用的 property（AgentCore 不通过它访问 messages）
# 或者改为返回最近一次 build() 的结果
```

**Bug 3 — AgentSession.submit() 竞态条件** (`integration/session.py:101-102`)

```python
# 当前: create_task 和 async for 之间有竞态
asyncio.create_task(self._core.run(message, stream))
async for ev in stream:  # AgentCore 可能还没开始 emit

# 修复: 改为直接 await AgentCore.run()，EventStream 改为在 AgentCore 内部管理
# 或者改为 AgentCore.run() 自己迭代 stream
```

### 2.A.2 Safety 规则库补全

在 `safety/rule_engine.py` 补充 `_DANGEROUS_PATTERNS`，覆盖设计文档中的 13+ 组高危命令：

```python
# 新增 --->
(r"rm\s+(-[rRf]+)\s+/", "删除根目录"),
(r"mkfs\.\w+", "格式化文件系统"),
(r"dd\s+if=/dev/zero\s+of=/dev", "覆盖磁盘设备"),
(r"iptables\s+-F", "清空防火墙规则"),
(r"curl\s+.*\s*\|\s*(ba)?sh", "curl pipe bash 远程执行"),
(r"wget\s+.*\s*\|\s*(ba)?sh", "wget pipe sh 远程执行"),
(r"sudo\s+su\b", "提权到 root"),
(r"chmod\s+(-[rR]+\s+)?777\s+/", "chmod 777 系统路径"),
(r">\s*/dev/sda", "覆盖磁盘设备"),
(r":\(\)\s*\{\s*:\|:&\s*\}\s*;:", "fork bomb"),
(r"python\S*\s+-c\s+", "python -c 执行任意代码"),
```

### 2.A.3 独立风险评分模块

新增 `safety/risk_scorer.py`，实现设计中的加权评分：

```python
@dataclass
class RiskProfile:
    intent_risk: float        # 意图风险 (0-100)
    command_risk: float       # 命令风险 (0-100)
    path_risk: float          # 路径风险 (0-100)
    privilege_risk: float     # 权限风险 (0-100)
    exfiltration_risk: float  # 数据外传风险 (0-100)
    injection_risk: float     # 注入风险 (0-100)

def calculateRiskScore(profile: RiskProfile) -> float:
    """加权评分，返回 0-100"""
    return (
        0.15 * profile.intent_risk +
        0.30 * profile.command_risk +
        0.20 * profile.path_risk +
        0.15 * profile.privilege_risk +
        0.10 * profile.exfiltration_risk +
        0.10 * profile.injection_risk
    )

def classifyRisk(score: float) -> tuple[SafetyVerdict, str]:
    if score <= 20:   return ALLOW, "低风险，自动执行"
    if score <= 40:   return ALLOW, "执行并记录日志"
    if score <= 60:   return REQUIRE_CONFIRM, "中等风险，需要人工审批"
    if score <= 80:   return BLOCK, "高风险，默认阻断"
    return BLOCK, "严重风险，直接拒绝"
```

此模块与现有 `RuleEngine` 的关系：`RuleEngine` 保持不变（快速路径），在 `checkToolCallWithReason` 被调用时，对于非 READ_ONLY 且未命中原有模式的情况，调用 `risk_scorer` 做更精细的判断。

### 2.A.4 产品化日志初始化

在 `src/ndlmpanel_agent/__init__.py` 中增加自动日志初始化：

```python
# __init__.py 末尾
import logging
import os

def _initLogging():
    """自动初始化日志系统（幂等调用，多次调用不重复创建 handler）"""
    logger = logging.getLogger("ndlmpanel")
    if logger.handlers:
        return logger  # 已经初始化过
    # ... StructuredFormatter + console + file handlers ...
    return logger

_initLogging()
```

### Phase A 验收标准

```bash
# 1. 危险命令被正确拦截（场景 1）
python -c "
from ndlmpanel_agent.safety.rule_engine import RuleEngine
from ndlmpanel_agent.safety.risk_scorer import calculateRiskScore
from ndlmpanel_agent.shared.types import ToolRiskLevel

e = RuleEngine()
# rm -rf / 被拦截
verdict, reason = e.checkToolCallWithReason('deleteFile', ToolRiskLevel.DANGEROUS, 
    {'targetPath': '/'})
assert verdict.value == 'require_confirm', f'Expected require_confirm, got {verdict}'
print('OK: rm -rf / blocked')

# chmod 777 / 被拦截
verdict, _ = e.checkToolCallWithReason('changePermissions', ToolRiskLevel.DANGEROUS,
    {'targetPath': '/etc', 'mode': '777'})
assert verdict.value != 'allow'
print('OK: chmod 777 blocked')
"

# 2. AgentSession 审批流程闭环
python -c "
import asyncio
from ndlmpanel_agent.integration.session import AgentSession
from ndlmpanel_agent.shared.types import AgentConfig

async def test():
    config = AgentConfig(llm_endpoint='https://api.test.com')  # 无 key → Mock
    session = AgentSession(config)
    # 验证 approve/reject 方法存在
    assert hasattr(session, 'approve')
    assert hasattr(session, 'reject')
    print('OK: approval API exists')

asyncio.run(test())
"

# 3. 日志文件生成
ls runtime/logs/agent.log && echo "OK: logging initialized"
```

---

## 3. Phase B: Provider 工厂 + 真机 API 测试 ✅ 已完成
> 测试 96→119，Provider 工厂，指数退避重试，真流式 SSE，DeepSeek/Qwen 适配

### 3.B.0 为什么需要这个阶段

当前 LLM Provider 层存在以下问题，直接影响后续所有阶段的验证：

| 问题 | 影响 |
|------|------|
| `AgentSession.__init__` 硬编码 `OpenAIProvider` 或 `MockProvider` | 无法按配置切换 DeepSeek/Qwen/vLLM |
| `OpenAIProvider` 无重试逻辑 | 网络波动导致会话直接失败 |
| HTTP 错误（4xx/5xx）无结构化处理 | 调试困难，不知道是 API Key 错还是限流 |
| `chatStream()` 是先读完再解析，不是真正的流式 | 首个 token 延迟偏大，SSE 优势未发挥 |
| 零真机 API 测试 | 所有端到端测试依赖 MockProvider，无法验证真实链路 |
| 不同供应商的响应格式差异未覆盖 | DeepSeek 和 Qwen 的 error response 格式不同 |

### 3.B.1 Provider 工厂 (`llm_providers/factory.py`)

新增 Provider 工厂，AgentSession 不再硬编码 Provider 选择：

```python
# llm_providers/factory.py

def createProvider(config: AgentConfig) -> LLMProvider:
    """根据 AgentConfig.llm_provider 创建对应的 Provider 实例。

    支持:
    - "deepseek"      → https://api.deepseek.com/v1
    - "qwen"           → https://dashscope.aliyuncs.com/compatible-mode/v1
    - "openai_compat"  → 通用 OpenAI-compatible (vLLM/SGLang/Ollama 等)
    - "mock"           → MockProvider (离线测试)

    各供应商差异：
    ┌──────────────┬──────────────────────┬───────────────────┐
    │ 供应商        │ 默认 endpoint         │ 默认 model          │
    ├──────────────┼──────────────────────┼───────────────────┤
    │ deepseek     │ api.deepseek.com/v1   │ deepseek-chat      │
    │ qwen         │ dashscope.aliyuncs... │ qwen-plus          │
    │ openai_compat│ 必须显式配置 endpoint  │ 必须显式配置 model  │
    │ mock         │ 无需 endpoint         │ mock-model         │
    └──────────────┴──────────────────────┴───────────────────┘
    """
    providerType = config.llm_provider

    if providerType == "mock" or not config.llm_api_key:
        return MockProvider([{"content": "Mock: 未配置 LLM API Key。离线模式。"}])

    # 获取默认值和重试配置
    endpoint = config.llm_endpoint or PROVIDER_DEFAULTS.get(providerType, {}).get("endpoint", "")
    model = config.llm_model or PROVIDER_DEFAULTS.get(providerType, {}).get("model", "")

    provider = OpenAIProvider(
        endpoint=endpoint,
        apiKey=config.llm_api_key,
        model=model,
        maxTokens=config.llm_max_tokens,
        temperature=config.llm_temperature,
        retryCount=config.llm_retry_count,
        retryDelay=config.llm_retry_delay,
    )
    return provider

# 供应商默认值表
PROVIDER_DEFAULTS = {
    "deepseek": {
        "endpoint": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
    },
    "qwen": {
        "endpoint": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model": "qwen-plus",
    },
}
```

### 3.B.2 AgentConfig 扩展

`shared/types.py` — AgentConfig 增加 3 个字段：

```python
@dataclass
class AgentConfig:
    # ... 现有字段 ...

    # Phase B 新增
    llm_temperature: float = 0.7
    llm_retry_count: int = 2          # 失败后重试次数
    llm_retry_delay: float = 1.0      # 重试间隔（秒）

    def __post_init__(self):
        # ... 现有校验 ...
        if self.llm_temperature < 0 or self.llm_temperature > 2:
            raise ValueError("llm_temperature 必须在 0-2 之间")
```

### 3.B.3 重试逻辑

在 `OpenAIProvider.chat()` 中增加指数退避重试：

```python
async def chat(self, messages: list[dict]) -> LLMResponse:
    lastError = None
    for attempt in range(self._retryCount + 1):
        try:
            body = json.dumps({...}).encode("utf-8")
            loop = asyncio.get_running_loop()
            raw = await loop.run_in_executor(None, self._httpPost, body)
            return self._parseResponse(raw)
        except urllib.error.HTTPError as exc:
            status = exc.code
            if status == 429:  # Rate Limit
                lastError = AgentError(ErrorCode.LLM_RATE_LIMITED,
                    f"API 限流 (attempt {attempt+1}/{self._retryCount+1})")
            elif status == 401:
                raise AgentError(ErrorCode.LLM_CONNECTION_FAILED,
                    "API Key 无效 (401)") from exc  # 不重试
            else:
                lastError = AgentError(ErrorCode.LLM_CONNECTION_FAILED,
                    f"HTTP {status}: {exc.reason}")
        except (urllib.error.URLError, OSError) as exc:
            lastError = AgentError(ErrorCode.LLM_CONNECTION_FAILED, str(exc))

        if attempt < self._retryCount:
            delay = self._retryDelay * (2 ** attempt)  # 指数退避
            await asyncio.sleep(delay)
            continue

    raise lastError  # type: ignore
```

### 3.B.4 真正的流式响应（逐块输出）

当前 `chatStream()` 调用 `_httpPost()` 一次性读取全部响应体，然后逐行解析。改为使用 `http.client.HTTPResponse` 的逐行读取：

```python
async def chatStream(self, messages: list[dict]) -> AsyncIterator[LLMResponse]:
    body = json.dumps({... stream: True ...}).encode("utf-8")
    loop = asyncio.get_running_loop()

    # 返回一个同步迭代器的异步包装
    def _syncGen():
        req = urllib.request.Request(...)
        with urllib.request.urlopen(req, timeout=120) as resp:
            for line in resp:  # 真正的逐行流式读取
                line = line.decode("utf-8").strip()
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload == "[DONE]":
                    break
                try:
                    obj = json.loads(payload)
                    delta = obj.get("choices", [{}])[0].get("delta", {})
                    if "content" in delta and delta["content"]:
                        yield delta["content"]  # 只返回文本增量
                except json.JSONDecodeError:
                    continue

    # 在 run_in_executor 中运行同步生成器，通过 asyncio.Queue 桥接
    queue: asyncio.Queue = asyncio.Queue()

    def _runner():
        try:
            for chunk in _syncGen():
                loop.call_soon_threadsafe(queue.put_nowait, chunk)
        except Exception as exc:
            loop.call_soon_threadsafe(queue.put_nowait, exc)
        finally:
            loop.call_soon_threadsafe(queue.put_nowait, None)  # sentinel

    loop.run_in_executor(None, _runner)

    while True:
        chunk = await queue.get()
        if chunk is None:
            break
        if isinstance(chunk, Exception):
            raise chunk
        yield LLMResponse(content=chunk, finish_reason="")
    yield LLMResponse(content=None, finish_reason="stop")
```

### 3.B.5 真机 API 集成测试

新增 `tests/integration/` 目录（区别于现有 `tests/smoke/` 和 `tests/unit/`）：

```python
# tests/integration/test_llm_provider_live.py

import os, unittest, asyncio
from ndlmpanel_agent.llm_providers.openai_compat import OpenAIProvider
from ndlmpanel_agent.llm_providers.factory import createProvider
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.shared.errors import AgentError, ErrorCode


def _requireEnv(*vars: str):
    """装饰器：如果环境变量未设置，跳过测试。"""
    missing = [v for v in vars if not os.environ.get(v)]
    return unittest.skipIf(missing, f"缺少环境变量: {', '.join(missing)}")


class TestLLMProviderLive(unittest.TestCase):
    """真机 LLM API 测试。需要设置 NDLM_LLM_API_KEY 环境变量。"""

    def setUp(self):
        self.apiKey = os.environ.get("NDLM_LLM_API_KEY", "")
        self.endpoint = os.environ.get("NDLM_LLM_ENDPOINT",
                          "https://api.deepseek.com/v1")
        self.model = os.environ.get("NDLM_LLM_MODEL", "deepseek-chat")

    @_requireEnv("NDLM_LLM_API_KEY")
    def test_nonStreamChat_returnsContent(self):
        """非流式对话：能返回有效文本内容。"""
        provider = OpenAIProvider(self.endpoint, self.apiKey, self.model,
                                  maxTokens=256, temperature=0.1)
        response = asyncio.run(provider.chat([
            {"role": "user", "content": "回复一个词：OK"}
        ]))
        self.assertIsNotNone(response.content)
        self.assertGreater(len(response.content or ""), 0)
        self.assertEqual(response.finish_reason, "stop")
        self.assertIn("prompt_tokens", response.usage)

    @_requireEnv("NDLM_LLM_API_KEY")
    def test_nonStreamChat_withToolCalling(self):
        """非流式对话：LLM 能返回 tool_calls。"""
        provider = OpenAIProvider(self.endpoint, self.apiKey, self.model,
                                  maxTokens=512, temperature=0.1)
        response = asyncio.run(provider.chat([
            {"role": "system", "content": "你可以调用 getCpuInfo 工具获取 CPU 信息。"},
            {"role": "user", "content": "当前 CPU 使用率是多少？"}
        ]))
        # DeepSeek 在提供 system prompt 中提到工具时可能返回 tool_call
        # 也可能返回文字说需要工具。两种都接受。
        hasContent = response.content and len(response.content) > 0
        hasToolCalls = len(response.tool_calls) > 0
        self.assertTrue(hasContent or hasToolCalls,
            f"Expected content or tool_calls. content={response.content}, tool_calls={response.tool_calls}")

    @_requireEnv("NDLM_LLM_API_KEY")
    def test_streamChat_yieldsChunks(self):
        """流式对话：能收到多个增量 chunk。"""
        provider = OpenAIProvider(self.endpoint, self.apiKey, self.model,
                                  maxTokens=256, temperature=0.1)
        chunks = []
        async def collect():
            async for resp in provider.chatStream([
                {"role": "user", "content": "回复：流式测试成功"}
            ]):
                if resp.content:
                    chunks.append(resp.content)
        asyncio.run(collect())
        self.assertGreater(len(chunks), 0)
        fullText = "".join(chunks)
        self.assertGreater(len(fullText), 2)

    @_requireEnv("NDLM_LLM_API_KEY")
    def test_invalidApiKey_raisesError(self):
        """无效 API Key 应抛出 AgentError。"""
        provider = OpenAIProvider(self.endpoint, "invalid-key-12345",
                                  self.model, maxTokens=100)
        with self.assertRaises(AgentError) as ctx:
            asyncio.run(provider.chat([
                {"role": "user", "content": "hi"}
            ]))
        self.assertIn(ctx.exception.code,
            (ErrorCode.LLM_CONNECTION_FAILED, ErrorCode.LLM_RATE_LIMITED))

    @_requireEnv("NDLM_LLM_API_KEY")
    def test_retry_recovery(self):
        """重试逻辑：正常请求不影响结果。"""
        config = AgentConfig(llm_endpoint=self.endpoint)
        config.llm_api_key = self.apiKey
        config.llm_model = self.model
        config.llm_retry_count = 1
        provider = createProvider(config)
        response = asyncio.run(provider.chat([
            {"role": "user", "content": "回复 OK"}
        ]))
        self.assertIsNotNone(response.content)


class TestProviderFactory(unittest.TestCase):
    """Provider 工厂测试（不需要真实 API）。"""

    def test_mockProvider_when_no_apiKey(self):
        """没有 API Key 时返回 MockProvider。"""
        config = AgentConfig(llm_endpoint="https://api.test.com")
        provider = createProvider(config)
        from ndlmpanel_agent.llm_providers.mock import MockProvider
        self.assertIsInstance(provider, MockProvider)

    def test_deepseekProvider_defaultEndpoint(self):
        """deepseek 类型使用正确的默认 endpoint。"""
        config = AgentConfig(llm_endpoint="")
        config.llm_api_key = "sk-test"
        config.llm_provider = "deepseek"
        # —— 注意：这里只测工厂逻辑，不实际发送请求
        # 需要 mock HTTP，暂时验证 config 走对分支即可
        from ndlmpanel_agent.llm_providers.factory import PROVIDER_DEFAULTS
        self.assertIn("deepseek", PROVIDER_DEFAULTS)
        self.assertTrue(
            PROVIDER_DEFAULTS["deepseek"]["endpoint"].startswith("https://api.deepseek.com"))

    def test_qwenProvider_defaultEndpoint(self):
        """qwen 类型使用正确的默认 endpoint。"""
        from ndlmpanel_agent.llm_providers.factory import PROVIDER_DEFAULTS
        self.assertIn("qwen", PROVIDER_DEFAULTS)
        self.assertTrue("dashscope" in PROVIDER_DEFAULTS["qwen"]["endpoint"])


class TestSSEParser(unittest.TestCase):
    """SSE 解析器单元测试（不需要真实 API）。"""

    def test_parseSimpleStream(self):
        """解析简单的流式响应。"""
        from ndlmpanel_agent.llm_providers.sse_parser import parseSseStream
        lines = [
            'data: {"id":"1","choices":[{"delta":{"content":"Hello"},"index":0}]}',
            'data: {"id":"1","choices":[{"delta":{"content":" World"},"index":0}]}',
            'data: {"id":"1","choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"total_tokens":10}}',
            'data: [DONE]',
        ]
        events = parseSseStream(lines)
        self.assertEqual(len(events), 3)
        self.assertEqual(events[0]["delta"]["content"], "Hello")
        self.assertEqual(events[1]["delta"]["content"], " World")
        self.assertEqual(events[2]["finish_reason"], "stop")

    def test_mergeSseDeltas_withToolCalls(self):
        """合并含 tool_calls 增量的 SSE 事件。"""
        from ndlmpanel_agent.llm_providers.sse_parser import mergeSseDeltas
        events = [
            {"delta": {"tool_calls": [
                {"index": 0, "id": "tc1", "function": {"name": "getCpuInfo", "arguments": ""}}
            ]}, "finish_reason": ""},
            {"delta": {"tool_calls": [
                {"index": 0, "function": {"arguments": "{}"}}
            ]}, "finish_reason": "tool_calls"},
        ]
        result = mergeSseDeltas(events)
        self.assertEqual(len(result["tool_calls"]), 1)
        self.assertEqual(result["tool_calls"][0]["name"], "getCpuInfo")
        self.assertEqual(result["tool_calls"][0]["arguments"], {})
```

### 3.B.6 API 调试验证脚本

新增 `scripts/test_llm.py` — 一个极简的独立脚本，用户可以手动运行来验证 LLM 连通性：

```python
#!/usr/bin/env python3
"""
测试 LLM API 连通性。

用法:
  export NDLM_LLM_API_KEY="sk-xxx"
  .venv/bin/python scripts/test_llm.py

测试项:
  1. 非流式纯文本对话
  2. 流式纯文本对话
  3. 无效 API Key 错误处理
"""
import asyncio, os, sys

# 确保项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ndlmpanel_agent.llm_providers.openai_compat import OpenAIProvider

API_KEY = os.environ.get("NDLM_LLM_API_KEY", "")
ENDPOINT = os.environ.get("NDLM_LLM_ENDPOINT", "https://api.deepseek.com/v1")
MODEL = os.environ.get("NDLM_LLM_MODEL", "deepseek-chat")

def green(s): return f"\033[32m{s}\033[0m"
def red(s): return f"\033[31m{s}\033[0m"

async def main():
    if not API_KEY:
        print(red("✗ 请设置 NDLM_LLM_API_KEY 环境变量"))
        sys.exit(1)

    provider = OpenAIProvider(ENDPOINT, API_KEY, MODEL, maxTokens=256, temperature=0.1)

    # Test 1: 非流式
    print("Test 1: 非流式对话...", end=" ")
    resp = await provider.chat([{"role": "user", "content": "回复一个词：OK"}])
    if resp.content and len(resp.content) > 0:
        print(green(f"OK → '{resp.content.strip()[:50]}'"))
    else:
        print(red(f"FAIL (content={resp.content})"))

    # Test 2: 流式
    print("Test 2: 流式对话...", end=" ")
    chunks = []
    async for r in provider.chatStream([{"role": "user", "content": "回复：流式测试"}]):
        if r.content:
            chunks.append(r.content)
    if chunks:
        print(green(f"OK → {len(chunks)} chunks"))
    else:
        print(red("FAIL (no chunks)"))

    # Test 3: 错误Key
    print("Test 3: 无效 API Key...", end=" ")
    bad = OpenAIProvider(ENDPOINT, "bad-key", MODEL, maxTokens=100)
    try:
        await bad.chat([{"role": "user", "content": "hi"}])
        print(red("FAIL (should have raised)"))
    except Exception as e:
        print(green(f"OK → correctly rejected ({type(e).__name__})"))

    print("\n全部测试完成。")

asyncio.run(main())
```

### Phase B 验收标准

```bash
# 1. Provider 工厂：按配置创建正确的 Provider
python -c "
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.llm_providers.factory import createProvider
from ndlmpanel_agent.llm_providers.mock import MockProvider
from ndlmpanel_agent.llm_providers.openai_compat import OpenAIProvider

# 无 key → Mock
config = AgentConfig(llm_endpoint='https://api.test.com')
assert isinstance(createProvider(config), MockProvider)
print('OK: mock provider selected when no api_key')

# deepseek → OpenAIProvider
config.llm_api_key = 'sk-test'
config.llm_provider = 'deepseek'
print(f'OK: {config.llm_provider} provider factory resolves')
"

# 2. SSE 解析器测试
.venv/bin/python -m unittest tests/integration/test_llm_provider_live.TestSSEParser -v

# 3. 真机 API 测试（需要 API Key）
export NDLM_LLM_API_KEY="sk-xxx"
.venv/bin/python -m unittest tests/integration/test_llm_provider_live.TestLLMProviderLive -v

# 4. 调试验证脚本
export NDLM_LLM_API_KEY="sk-xxx"
.venv/bin/python scripts/test_llm.py
```

---

## 4. Phase C: 补插件 + 自动注册 ✅ 已完成（审计集成待 Phase D）
> 测试 119→122，48 工具/5 插件（全 psutil→/proc+subprocess），TOOLS dict 自动发现
> 剩余子任务「AgentCore 集成 TraceRecorder + Context 集成」纳入 Phase D

### 4.C.1 补全运维插件

按赛题演示场景需要，优先补全以下 5 组插件：

#### `plugins/disk.py` — 磁盘分析

```python
def getDiskUsage(path: str = "/") -> dict:
    """获取磁盘挂载点使用率。df -h 输出结构化。"""
    
def findLargeFiles(path: str = "/var", minSizeMb: int = 100, 
                   maxResults: int = 20) -> list[dict]:
    """查找指定路径下的大文件。find + du 组合。"""

def getInodeUsage(path: str = "/") -> dict:
    """查询 inode 使用率。df -i。"""
```

#### `plugins/process.py` — 进程管理

```python
def listProcesses(sortBy: str = "cpu", limit: int = 20) -> list[dict]:
    """列出进程。ps aux --sort。"""

def findZombieProcesses() -> list[dict]:
    """查找僵尸进程。解析 /proc/<pid>/status 的 State 字段。"""

def getProcessTree(pid: int) -> dict:
    """获取进程树。ps --forest 或 pstree。"""

def getProcessDetail(pid: int) -> dict:
    """获取进程详情。/proc/<pid>/status + cmdline + fd列表。"""
```

#### `plugins/network.py` — 网络诊断

```python
def getListeningPorts() -> list[dict]:
    """获取监听端口列表。ss -tlnp。"""

def getNetworkConnections(state: str = "all") -> list[dict]:
    """获取网络连接。ss -tunap。"""

def checkPortConnectivity(host: str, port: int, timeout: int = 5) -> dict:
    """检查端口连通性。socket.connect。"""
```

#### `plugins/log.py` — 日志查询

```python
def queryJournalctl(unit: str = "", lines: int = 50, 
                    priority: str = "err") -> dict:
    """查询 systemd journal。journalctl --output=json。"""

def tailFile(path: str, lines: int = 50) -> dict:
    """读取文件末尾内容。需要 path_policy 校验路径。"""

def getLogErrorSummary(unit: str = "", hours: int = 24) -> dict:
    """获取最近 N 小时日志错误摘要。"""
```

#### `plugins/service.py` — 服务管理

```python
def getServiceStatus(name: str) -> dict:
    """获取服务状态。systemctl status。"""

def listFailedServices() -> list[dict]:
    """列出失败的服务。systemctl --failed。"""

def restartService(name: str) -> dict:       # 风险: DANGEROUS
    """重启服务。systemctl restart。"""

def getServiceLogs(name: str, lines: int = 50) -> dict:
    """获取服务日志。journalctl -u <name>。"""
```

### 4.C.2 在 AgentSession 中注册新工具

```python
# integration/session.py — 扩展注册
from ndlmpanel_agent.plugins import disk, process, network, log, service

registry.register(disk.getDiskUsage, ToolRiskLevel.READ_ONLY)
registry.register(disk.findLargeFiles, ToolRiskLevel.READ_ONLY)
registry.register(process.listProcesses, ToolRiskLevel.READ_ONLY)
registry.register(process.findZombieProcesses, ToolRiskLevel.READ_ONLY)
registry.register(network.getListeningPorts, ToolRiskLevel.READ_ONLY)
registry.register(log.queryJournalctl, ToolRiskLevel.READ_ONLY)
registry.register(service.getServiceStatus, ToolRiskLevel.READ_ONLY)
registry.register(service.listFailedServices, ToolRiskLevel.READ_ONLY)
# ... 写/危险工具标记为 WRITE 或 DANGEROUS
```

### 4.C.3 AgentCore 集成 TraceRecorder

在 `agent_loop.py` 的关键节点插入 trace 记录：

```python
# 每个关键事件写入 TraceRecorder
# 注入检测
self._recorder.record(traceId, sessionId, "injection.check",
    {"input": userMessage[:200], "result": "safe"})

# LLM 调用
self._recorder.record(traceId, sessionId, "llm.request", 
    {"model": model, "messages_count": len(msgs)})
self._recorder.record(traceId, sessionId, "llm.response",
    {"finish_reason": response.finish_reason, 
     "usage": response.usage, "tool_calls_count": len(response.tool_calls)})

# 安全校验
self._recorder.record(traceId, sessionId, "safety.check",
    {"tool": name, "verdict": verdict.value, "reason": reason})

# 工具执行
self._recorder.record(traceId, sessionId, "tool.result",
    {"tool": name, "success": True, "output_len": len(output)})
```

需要将 `TraceRecorder` 实例传入 `AgentCore.__init__`。

### 4.C.4 上下文管理集成

AgentCore 在每轮循环中检查 token 预算，超出时调用 `compressHistory()`：

```python
# agent_loop.py 循环内
estimatedTokens = sum(len(str(m)) for m in msgs) // 2
if estimatedTokens > config.llm_max_tokens * 0.8:
    msgs = compressHistory(msgs)
```

### Phase C 验收标准

```bash
# 1. 新插件工具可调用
python -c "
from ndlmpanel_agent.plugins.disk import getDiskUsage, findLargeFiles
from ndlmpanel_agent.plugins.process import listProcesses, findZombieProcesses
from ndlmpanel_agent.plugins.network import getListeningPorts
from ndlmpanel_agent.plugins.log import queryJournalctl
from ndlmpanel_agent.plugins.service import getServiceStatus, listFailedServices

print('Disk:', getDiskUsage()['filesystems'][:1])
print('Processes:', len(listProcesses(limit=5)))
print('Ports:', len(getListeningPorts()))
print('Services:', len(listFailedServices()))
print('All plugins OK')
"

# 2. 场景 2 全链路 (Mock LLM)
python -c "
import asyncio, json
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.integration.session import AgentSession

async def test():
    config = AgentConfig(llm_endpoint='https://api.test.com')
    session = AgentSession(config)
    
    events = []
    async for ev in session.submit('帮我看看系统负载情况'):
        events.append(ev.type.value)
    
    # 至少应该有 SESSION_CREATED + 工具调用 + TEXT_DELTA + DONE
    assert 'tool.calling' in events or 'tool.result' in events
    assert 'done' in events
    print('OK: scenario 2 pipeline works')

asyncio.run(test())
"

# 3. 审计日志写入验证
python -c "
from ndlmpanel_agent.trace_log.recorder import TraceRecorder
recorder = TraceRecorder('runtime/sqlite/traces.db')
results = recorder.query(limit=5)
print(f'Trace entries: {len(results)}')
# 检查 hash chain
if results:
    assert results[0].get('entry_hash'), 'Missing hash'
    print(f'Latest hash: {results[0][\"entry_hash\"]}')
print('OK: trace recording works')
"
```

---

## 5. Phase D: Core 集成 + 策略配置化（预计 3-4 天）
> 合并原 Phase C 剩余「AgentCore 集成 TraceRecorder + Context」+ 原 Phase D「审批闭环 + 策略配置」

### 5.D.1 AgentSession 审批 API

```python
class AgentSession:
    # 新增字段
    _pendingApprovals: dict[str, asyncio.Event]
    _approvalDecisions: dict[str, dict]

    async def approve(self, actionId: str, userId: str = "") -> AgentEvent:
        """批准某个待审批的动作。"""
        if actionId not in self._pendingApprovals:
            return AgentEvent(type=EventType.ERROR, ...)
        self._approvalDecisions[actionId] = {"approved": True}
        self._pendingApprovals[actionId].set()
        # 记录 trace
        self._recorder.record(...)
        return AgentEvent(type=EventType.APPROVAL_RESOLVED, ...)

    async def reject(self, actionId: str, reason: str = "", 
                     userId: str = "") -> AgentEvent:
        """拒绝某个待审批的动作。"""
        ...

    async def cancel(self) -> None:
        """取消当前会话。"""
        ...

    def getTrace(self) -> list[dict]:
        """获取当前会话的全部 trace 记录。"""
        return self._recorder.query(sessionId=self._sessionId)

    def close(self) -> None:
        """关闭会话，释放资源。"""
        self._recorder.close()
```

### 5.D.2 Safety 策略配置化

创建 `conf/policies/default.json` 和 `conf/policies/strict.json`：

```json
{
    "_comment": "default safety policy",
    "version": "1.0",
    "rules": {
        "block_commands": [
            "rm -rf /", "mkfs.*", "dd if=/dev/zero of=/dev",
            "iptables -F", "curl | bash", "wget | sh",
            "python -c", "sudo su", ":(){ :|:& };:"
        ],
        "protected_paths": [
            "/etc/shadow", "/etc/passwd", "/etc/sudoers",
            "/boot", "/usr/lib", "/lib", "/proc", "/sys",
            "~/.ssh", "/root"
        ],
        "require_approval": [
            "systemctl restart", "systemctl stop",
            "kill", "chmod", "chown", "firewall-cmd"
        ],
        "allow_readonly_above_size_gb": 1
    },
    "risk_thresholds": {
        "safe": 20,
        "low": 40,
        "medium": 60,
        "high": 80
    }
}
```

### 5.D.3 AgentSession 直接构造 Toolkit 方法

提供 `AgentSession.fromConfigFile` 之外的便捷构造方法，便于快速测试：

```python
@classmethod
def createQuick(cls, endpoint: str = "", apiKey: str = "",
                model: str = "deepseek-chat") -> AgentSession:
    """快速创建测试用 AgentSession。"""
    config = AgentConfig(llm_endpoint=endpoint or "https://api.deepseek.com/v1")
    if apiKey:
        config.llm_api_key = apiKey
    return cls(config)
```

### Phase D 验收标准

```bash
# 1. 场景 3 全链路（需要真实 LLM）
export NDLM_LLM_API_KEY="sk-xxx"
python -c "
import asyncio
from ndlmpanel_agent.integration.session import AgentSession
from ndlmpanel_agent.shared.types import AgentConfig

async def test():
    config = AgentConfig(llm_endpoint='https://api.deepseek.com/v1')
    config.llm_api_key = 'sk-xxx'
    session = AgentSession(config)
    
    async for ev in session.submit('分析 /var/log 目录的磁盘占用'):
        if ev.type.value == 'approval.required':
            actionId = ev.data.get('action_id')
            print(f'[审批请求] {ev.data}')
            await session.approve(actionId)
        elif ev.type.value == 'text.delta':
            print(ev.data['content'], end='', flush=True)
        elif ev.type.value == 'done':
            break

asyncio.run(test())
"

# 2. 拒绝审批验证
# ... 同上但调用 session.reject() 而非 approve() ...
# 验证拒绝后相应的工具调用没有执行

# 3. Trace 完整性
python -c "
# 验证一次完整会话后 trace 记录包含完整链路
# session.created → llm.request → safety.check → tool.result → llm.request → done
"
```

---

## 6. Phase E: 高级能力 + 对接文档（预计 2-3 天）

### 6.E.1 agent_router/ — 意图路由 + 模式控制

这是连接用户意图和 Agent 行为的关键模块。不做完整实现，而是一个**轻量路由**：

```python
# agent_router/mode.py
class AgentMode(str, Enum):
    READ_ONLY = "read_only"    # 只采集分析，不执行修改
    PLAN = "plan"              # 生成方案但不执行
    AGENT = "agent"            # 交互执行（默认）
    BREAK_GLASS = "break_glass"  # 紧急模式，强审计

class AgentRouter:
    """轻量意图路由。"""
    
    def route(self, message: str, mode: AgentMode) -> dict:
        """
        根据用户消息和运行模式，返回路由决策:
        - intent: diagnosedisk / diagnose_process / operation / query / chat
        - mode: 最终生效的模式
        - requires_plan: 是否需要先生成计划
        - safety_override: 是否是 break_glass 模式
        """
```

### 6.E.2 skills/ — 预设运维技能（最少可用版本）

利用 Prompt Engineering 而非代码实现 Skill 编排。核心思路：**在 System Prompt 中预置几个标准诊断流程**。

```text
# conf/prompts/system/v1.1.0.txt 末尾追加

## 标准运维技能

当用户要求以下操作时，请按标准流程执行：

### 磁盘空间诊断
1. getDiskUsage("/") → 确认哪个分区满了
2. findLargeFiles(已满分区的挂载点) → 定位大文件
3. 分析是否可以安全清理
4. 生成清理建议，涉及删除操作时必须请求用户确认

### 服务故障诊断
1. getServiceStatus(服务名) → 确认服务状态
2. queryJournalctl(unit=服务名, priority="err") → 查找错误日志
3. getListeningPorts() → 检查端口冲突
4. 综合分析给出根因和修复建议

### 进程异常诊断
1. listProcesses(sortBy="cpu") → 找到 CPU/内存占用异常的进程
2. getProcessDetail(异常进程PID) → 获取详细信息
3. 分析进程行为，判断是否正常
```

### 6.E.3 后端对接文档 + 示例

创建 `docs/Backend-Integration.md`（放到 Phase E 任务清单），核心内容：

- FastAPI 集成最小示例（30 行代码）
- 环境变量配置说明
- SSE 流式输出格式说明
- 错误处理约定
- 部署脚本（systemd unit 文件）

### 6.E.4 测试补全

- 新插件的单元测试（每个插件 ≥ 3 个测试用例）
- Safety 规则库测试（每个危险模式 ≥ 1 个测试用例）
- 审批流程端到端测试（用 MockProvider）

### Phase E 验收标准

```bash
# 所有回归测试通过
.venv/bin/python -m unittest discover tests/ -v
# 预期: 70+ 项测试，全部通过

# 4 个演示场景全部可以跑通
# (需要真实 LLM API Key。离线时使用 MockProvider 验证流程正确性)
```

---

## 7. 实现顺序依赖图

```
Phase A (地基)
  ├── A.1 Bug修复 ────────────────────────────┐
  │   ├─ Bug1: 审批假闭环                      │
  │   ├─ Bug2: prompt_builder messages         │
  │   └─ Bug3: submit() 竞态                   │
  │                                            │
  ├── A.2 Safety规则补全                        │
  │   └─ _DANGEROUS_PATTERNS 从 6→15 组        │
  │                                            │
  ├── A.3 risk_scorer.py 独立模块              │
  │                                            │
  └── A.4 日志初始化                            │
      │                                        │
      ▼                                        │
Phase B (Provider + 真机测试) ← 依赖 A.1, A.4 │
  ├── B.1 Provider 工厂 (factory.py)          │
  ├── B.2 AgentConfig 扩展 (temperature/retry)│
  ├── B.3 重试逻辑 (HTTPError/URLError 处理)   │
  ├── B.4 真正的流式响应 (逐块读取)            │
  ├── B.5 真机 API 集成测试                    │
  └── B.6 API 调试验证脚本 (scripts/test_llm.py)│
      │                                        │
      ▼                                        │
Phase C (插件+审计) ← 依赖 A, B              │
  ├── C.1 plugins: disk/process/network/log/svc│
  ├── C.2 AgentSession 注册新工具              │
  ├── C.3 AgentCore 集成 TraceRecorder        │
  └── C.4 ContextManagement 集成到 AgentCore  │
      │                                        │
      ▼                                        │
Phase D (审批闭环) ← 依赖 A.1, B.0, C.3      │
  ├── D.1 AgentSession.approve/reject/cancel   │
  ├── D.2 策略 JSON 配置化                     │
  └── D.3 便捷构造方法                         │
      │                                        │
      ▼                                        │
Phase E (高级能力) ← 依赖 C, D                │
  ├── E.1 AgentRouter 轻量路由                 │
  ├── E.2 Skills 预设 (Prompt Engineering)     │
  ├── E.3 后端对接文档                         │
  └── E.4 测试补全                             │
```

---

## 8. 工作量估算

| Phase | 内容 | 新文件 | 修改文件 | 新增测试 | 人天 |
|-------|------|:--:|:--:|:--:|:--:|
| A | Bug修复 + Safety规则 + 日志 | 1 | 4 | 5 | 2-3 |
| B | Provider工厂 + 重试 + 真机API测试 | 4 | 2 | 10 | 3-4 |
| C | 5组插件 + 审计集成 + Context集成 | 5 | 3 | 18 | 3-4 |
| D | 审批闭环 + 策略配置 | 1 | 2 | 8 | 2-3 |
| E | Router + Skills + 文档 + 测试 | 3 | 4 | 12 | 2-3 |
| **合计** | | **14** | **15** | **53** | **12-17** |

---

## 9. 不做的事情（明确边界）

以下内容设计文档有描述，但在当前阶段明确**不做**：

| 内容 | 原因 |
|------|------|
| `sub_agents/` 子智能体 | 需要多 LLM 实例和多上下文窗口管理，复杂度高，非赛题核心 |
| `evaluation/` 评测框架 | 需要大量测试用例积累，赛题交付时不需要 |
| MCP Client 端 (`client/stdio_client/`, `client/http_client/`) | 当前是包导入模式，不需要远程调用外部 MCP Server |
| MCP `transports/streamable_http/` | 同上，不走 HTTP 传输 |
| `compat/pydantic_models/` | 后端如果不用 FastAPI 则不需要；即使用，dataclass 可直接用 |
| `execution/privilege/`, `execution/sandbox/` | 需要系统级配置（sudoers、cgroups），适合部署文档说明而非代码实现 |
| `execution/quarantine/`, `execution/rollback/` | 复杂度高，当前阶段用 `--dry-run` 提示代替 |

---

## 10. 关键风险

| 风险 | 缓解 |
|------|------|
| LLM API 不可用（无 API Key） | MockProvider 保证所有非 LLM 功能可独立开发测试；Phase B 新增真机 API 测试（需 key 时 skip）；Phase D 验收必须有真实 API |
| 麒麟 V11 上 /proc 格式差异 | 所有 /proc 解析增加 try/except 降级路径，返回 `"Unknown"` 而非崩溃 |
| `ss`/`df`/`ps` 等命令在最小安装系统中不存在 | 每个 subprocess 调用增加 `FileNotFoundError` 降级，并 docstring 注明依赖 |
| 评委对零依赖方案有疑问（"你们连 MCP SDK 都没用？"） | 在文档中明确说明：① 自实现的 JSON-RPC 完全符合 MCP 协议规范 ② 零依赖是为了 LoongArch/麒麟兼容 ③ 架构图展示标准 MCP 方法支持 |
