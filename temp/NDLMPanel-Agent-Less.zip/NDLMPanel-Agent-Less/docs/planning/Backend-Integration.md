---
type: reference
status: complete
created: 2026-06-02
tags:
  - backend-integration
  - fastapi
  - deployment
---

# NDLMPanel-Agent 后端对接指南

---

## 0. 部署前提

```bash
# 目标平台：LoongArch + 麒麟高级服务器版 V11, Python 3.10+
python3 -m venv /opt/ndlmpanel/.venv
source /opt/ndlmpanel/.venv/bin/activate
pip install -e /opt/ndlmpanel/agent/

# 环境变量 (生产建议用 systemd EnvironmentFile=)
export NDLM_LLM_API_KEY="sk-xxx"
export NDLM_LLM_ENDPOINT="https://api.deepseek.com/anthropic"
export NDLM_LLM_MODEL="deepseek-v4-pro"
```

---

## 1. FastAPI 最小集成 (30 行)

```python
# backend/app.py
import os
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

from ndlmpanel_agent import AgentSession, AgentConfig
from ndlmpanel_agent.compat.api_styles.openai_adapter import OpenAIAdapter

app = FastAPI()
config = AgentConfig(llm_endpoint=os.environ["NDLM_LLM_ENDPOINT"])
config.llm_api_key = os.environ["NDLM_LLM_API_KEY"]

@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    message = body.get("message", "")

    session = AgentSession(config, userId=body.get("user_id", "default"))

    async def generate():
        async for event in session.submit(message):
            yield OpenAIAdapter.formatSse(event)

    return StreamingResponse(generate(), media_type="text/event-stream")
```

---

## 2. 四种运行模式

```python
from ndlmpanel_agent.agent_router.router import AgentMode

# 只读模式 — 只分析不修改
session = AgentSession(config, mode=AgentMode.READ_ONLY)

# 计划模式 — 生成方案但不执行
session = AgentSession(config, mode=AgentMode.PLAN)

# Agent 执行模式 (默认) — 低风险自动，高风险审批
session = AgentSession(config, mode=AgentMode.AGENT)

# 紧急模式 — 审批降级，强审计
session = AgentSession(config, mode=AgentMode.BREAK_GLASS)
```

---

## 3. 审批流程 (高危操作人审闭环)

```python
# 后端 WebSocket / SSE 监听事件:
async for event in session.submit("清理 /var/log 大文件"):
    if event.type == "approval.required":
        # 将 action_id 存入缓存，推送审批请求给前端
        pending[event.data["action_id"]] = {
            "tool": event.data["tool_name"],
            "args": event.data["arguments"],
            "reason": event.data["reason"],
        }
        yield {"type": "approval_request", ...}

    elif event.type == "text.delta":
        yield {"type": "text", "content": event.data["content"]}

# 用户决策后:
session.approve(action_id)   # 批准 → 工具执行
session.reject(action_id)    # 拒绝 → 跳过
```

---

## 4. 审计查询

```python
# 查询某次会话的完整审计链
traces = session.getTrace()
# traces = [
#     {"trace_id": "...", "event_type": "session.created", "entry_hash": "a1b2..."},
#     {"trace_id": "...", "event_type": "llm.request",    "entry_hash": "c3d4..."},
#     ...
# ]
# 哈希链: 每条 entry_hash = SHA256(prev_hash || event_data)，防篡改
```

---

## 5. Systemd 部署 (生产环境)

```ini
# /etc/systemd/system/ndlmpanel-backend.service
[Unit]
Description=NDLMPanel Agent Backend
After=network.target

[Service]
Type=simple
User=osagent
WorkingDirectory=/opt/ndlmpanel

# 敏感配置不写命令行，用 EnvironmentFile
EnvironmentFile=/etc/ndlmpanel/env

ExecStart=/opt/ndlmpanel/.venv/bin/uvicorn backend.app:app \
    --host 127.0.0.1 --port 8080

Restart=on-failure

# 安全加固
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/var/lib/ndlmpanel

[Install]
WantedBy=multi-user.target
```

```bash
# /etc/ndlmpanel/env (权限 600)
NDLM_LLM_API_KEY=sk-xxx
NDLM_LLM_ENDPOINT=https://api.deepseek.com/anthropic
NDLM_LLM_MODEL=deepseek-v4-pro
NDLM_SAFETY_POLICY=strict
NDLM_EXECUTION_USER=osagent-exec
```

---

## 6. 事件流格式速查

| EventType | 含义 | data 关键字段 |
|------|------|------|
| `session.created` | 会话创建 | `user_id` |
| `thinking.start` | 开始推理 | `round` |
| `safety.checked` | 安全校验完成 | `tool`, `risk`, `verdict`, `reason` |
| `approval.required` | 需要审批 | `tool_name`, `arguments`, `action_id`, `reason` |
| `approval.resolved` | 审批完成 | `action_id`, `approved`, `reason` |
| `tool.result` | 工具执行结果 | `call_id`, `tool_name`, `success`, `output` |
| `text.delta` | 文本流片段 | `content` |
| `text.done` | 文本完成 | `{}` |
| `error` | 错误 | `message` |
| `done` | 会话结束 | `{}` |

---

## 7. Nginx 反向代理 (生产推荐)

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:8080;
    proxy_buffering off;              # SSE 必须关闭缓冲
    proxy_cache off;
    proxy_read_timeout 3600s;         # 长连接超时
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```
