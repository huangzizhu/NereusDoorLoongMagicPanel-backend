import asyncio, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.shared.types import AgentConfig, EventType
from ndlmpanel_agent.integration.session import AgentSession
from ndlmpanel_agent.integration.event_stream import EventStream
from ndlmpanel_agent.execution.executor import runCommand
from ndlmpanel_agent.compat.api_styles import OpenAIAdapter

# test1: EventStream
async def t1():
    es = EventStream("s1")
    es.emit(EventType.TEXT_DELTA, {"content": "hello"})
    es.emit(EventType.DONE)
    events = [ev async for ev in es]
    assert len(events) == 2
    assert events[0].type == EventType.TEXT_DELTA
    print("t1 EventStream: OK")

# test2: executor
def t2():
    ok, out, err = runCommand(["echo", "hello"])
    assert ok
    assert "hello" in out
    print("t2 executor echo: OK")

    # 黑名单
    ok, out, err = runCommand(["ls", "/etc/shadow"], deniedPaths=["/etc/shadow"])
    assert not ok
    assert "黑名单" in err
    print("t2 executor deny: OK")

    # 白名单
    ok, out, err = runCommand(["ls", "/tmp"], allowedPaths=["/tmp", "/usr"])
    assert ok
    print("t2 executor allowlist: OK")

# test3: AgentSession mock text response
async def t3():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    session = AgentSession(cfg)
    # Mock 默认返回空，手动注入有内容的响应
    session._llm.mockSetResponses([{"content": "系统负载正常，CPU 使用率 15%"}])
    events = [ev async for ev in session.submit("系统负载如何？")]
    assert any(ev.type == EventType.TEXT_DELTA for ev in events)
    assert any(ev.type == EventType.DONE for ev in events)
    print("t3 session text: OK")

# test4: AgentSession tool_calls
async def t4():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    session = AgentSession(cfg)
    session._llm.mockSetResponses([{
        "tool_calls": [{"id": "tc1", "name": "getCpuInfo", "arguments": {}}]
    }])
    events = [ev async for ev in session.submit("CPU?")]
    types = [ev.type for ev in events]
    assert EventType.TOOL_CALLING in types
    assert EventType.TOOL_RESULT in types
    print(f"t4 session tool_calls: OK ({len(events)} events)")

# test5: End-to-end → OpenAI SSE
async def t5():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    session = AgentSession(cfg)
    session._llm.mockSetResponses([{"content": "Hello from agent!"}])

    sseLines = []
    async for ev in session.submit("test"):
        line = OpenAIAdapter.formatSse(ev)
        if line:
            sseLines.append(line)

    assert any("[DONE]" in line for line in sseLines)
    assert any("Hello" in line for line in sseLines)
    print(f"t5 e2e SSE: OK ({len(sseLines)} SSE lines)")

asyncio.run(t1())
t2()
asyncio.run(t3())
asyncio.run(t4())
asyncio.run(t5())
print("\nS5 全部验收通过")
