import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.trace_log.sanitizer import sanitize
from ndlmpanel_agent.trace_log.hash_chain import HashChain
from ndlmpanel_agent.trace_log.storage import TraceStorage
from ndlmpanel_agent.trace_log.recorder import TraceRecorder

# test1: sanitize
d = sanitize({"api_key": "sk-secret123", "user": "admin", "nested": {"token": "x"}})
assert d["api_key"] == "***REDACTED***"
assert d["nested"]["token"] == "***REDACTED***"
assert d["user"] == "admin"
print("t1 sanitize: OK")

# test2: hash chain
hc = HashChain()
h1 = hc.hash({"a": 1})
h2 = hc.hash({"b": 2})
assert h1 != h2
assert len(h1) == 16
print("t2 hash chain: OK (%s -> %s)" % (h1, h2))

# test3: storage SQLite
st = TraceStorage("runtime/sqlite/test_traces.db")
st.insert("t1", "s1", "test.event", 123456.0, {"msg": "hello"}, "h1", None)
rows = st.query(traceId="t1", limit=1)
assert len(rows) == 1
assert rows[0]["event_type"] == "test.event"
st.close()
os.unlink("runtime/sqlite/test_traces.db")
print("t3 storage: OK")

# test4: recorder JSONL + SQLite
rec = TraceRecorder("runtime/sqlite/test2.db", "runtime/traces")
h = rec.record("trace_x", "sess_y", "tool.call", {"name": "getCpuInfo"})
assert len(h) == 16

# query
rows = rec.query(sessionId="sess_y", limit=10)
assert len(rows) >= 1
assert rows[0]["event_type"] == "tool.call"
rec.close()

# cleanup
import glob
for f in glob.glob("runtime/traces/*.jsonl"):
    os.unlink(f)
os.unlink("runtime/sqlite/test2.db")
print("t4 recorder: OK (hash=%s, %s rows)" % (h, len(rows)))

print("\nS8 全部验收通过")
