import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.context_mgmt.collectors import getSystemSnapshot
from ndlmpanel_agent.context_mgmt.compressor import compressHistory

# test1: snapshot
snap = getSystemSnapshot()
assert "cpu" in snap
assert snap["cpu"]["cores"] > 0
assert "memory" in snap
assert snap["memory"]["total_gb"] > 0
assert "disk" in snap
assert "uptime_seconds" in snap
assert snap["uptime_seconds"] > 0
print("t1 snapshot: OK (cpu_cores=%s, mem=%sGB, disk=%s, uptime=%ss)" % (
    snap["cpu"]["cores"], snap["memory"]["total_gb"],
    len(snap["disk"]), int(snap["uptime_seconds"])))

# test2: processes
assert "processes_top5" in snap
print("t2 top processes: %s procs" % len(snap["processes_top5"]))

# test3: compressor - short history
short = [{"role": "user", "content": "hi"}]
result = compressHistory(short)
assert len(result) == 1
print("t3 short no compress: OK")

# test4: compressor - long history
longMsgs = [{"role": "user", "content": "msg %s" % i} for i in range(20)]
result = compressHistory(longMsgs, maxRecent=4)
assert len(result) <= 6  # recent 4 + optional summary
print("t4 long compress: OK (%s msgs -> %s)" % (len(longMsgs), len(result)))

# test5: e2e with session
from ndlmpanel_agent.shared.types import AgentConfig, EventType
from ndlmpanel_agent.integration.session import AgentSession

async def t5():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    s = AgentSession(cfg)
    s._llm.mockSetResponses([{"content": "Snapshot loaded"}])
    events = [ev async for ev in s.submit("系统状态")]
    assert any(ev.type == EventType.DONE for ev in events)
    print("t5 session + snapshot: OK")

import asyncio
asyncio.run(t5())
print("\nS7 全部验收通过")
