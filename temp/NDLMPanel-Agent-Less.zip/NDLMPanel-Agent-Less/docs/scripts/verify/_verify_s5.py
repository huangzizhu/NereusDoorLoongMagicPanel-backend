import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.compat.api_styles import OpenAIAdapter, ClaudeAdapter
from ndlmpanel_agent.shared.types import AgentEvent, EventType

# OpenAI
ev = AgentEvent(type=EventType.TEXT_DELTA, session_id="s1", trace_id="t1", data={"content": "Hello"})
sse = OpenAIAdapter.formatSse(ev)
assert sse.startswith("data: ") and "Hello" in sse
print("t1 OpenAI text: OK")

ev = AgentEvent(type=EventType.DONE, session_id="s1", trace_id="t1")
assert OpenAIAdapter.formatSse(ev) == "data: [DONE]\n\n"
print("t2 OpenAI done: OK")

# Claude - reset state
ClaudeAdapter._blockIdx = 0
ClaudeAdapter._msgIdCounter = 0

ev = AgentEvent(type=EventType.THINKING_DELTA, session_id="s1", trace_id="t1", data={"content": "分析中..."})
sse = ClaudeAdapter.formatSse(ev)
assert "event: content_block_start" in sse
assert "thinking_delta" in sse
assert "分析中..." in sse
print("t3 Claude thinking: OK")

ev = AgentEvent(type=EventType.TEXT_DELTA, session_id="s1", trace_id="t1", data={"content": "磁盘满", "_block_start": True})
sse = ClaudeAdapter.formatSse(ev)
assert "text_delta" in sse
print("t4 Claude text: OK")

ev = AgentEvent(type=EventType.TOOL_CALLING, session_id="s1", trace_id="t1", data={"id": "tc1", "name": "disk.usage", "arguments": {}})
sse = ClaudeAdapter.formatSse(ev)
assert "tool_use" in sse
print("t5 Claude tool_use: OK")

ev = AgentEvent(type=EventType.DONE, session_id="s1", trace_id="t1")
sse = ClaudeAdapter.formatSse(ev)
assert "event: message_stop" in sse
print("t6 Claude done: OK")

print("\nAnthropic 格式兼容全部通过")
