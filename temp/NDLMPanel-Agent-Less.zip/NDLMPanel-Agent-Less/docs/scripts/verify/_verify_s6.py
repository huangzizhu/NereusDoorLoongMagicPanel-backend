import asyncio, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.shared.types import AgentConfig, EventType
from ndlmpanel_agent.integration.session import AgentSession

# test1: 文本回复
async def t1():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    s = AgentSession(cfg)
    s._llm.mockSetResponses([{"content": "系统一切正常"}])
    events = [ev async for ev in s.submit("系统状态？")]
    types = [e.type for e in events]
    assert EventType.TEXT_DELTA in types
    assert EventType.DONE in types
    print("t1 text response: OK")

# test2: 单工具调用
async def t2():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    s = AgentSession(cfg)
    s._llm.mockSetResponses([
        {"tool_calls": [{"id": "t1", "name": "getCpuInfo", "arguments": {}}]},
        {"content": "CPU 状态正常"},
    ])
    events = [ev async for ev in s.submit("CPU?")]
    types = [e.type for e in events]
    assert EventType.TOOL_CALLING not in types  # AgentCore 不直接 emit TOOL_CALLING
    assert EventType.SAFETY_CHECKED in types
    assert EventType.TOOL_RESULT in types
    assert EventType.TEXT_DELTA in types
    print(f"t2 single tool: OK ({len(events)} events)")

# test3: 多轮工具调用
async def t3():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    s = AgentSession(cfg)
    s._llm.mockSetResponses([
        {"tool_calls": [{"id": "t1", "name": "getCpuInfo", "arguments": {}}]},
        {"tool_calls": [{"id": "t2", "name": "getMemoryInfo", "arguments": {}}]},
        {"content": "综合分析完成"},
    ])
    events = [ev async for ev in s.submit("分析系统")]
    toolResults = [e for e in events if e.type == EventType.TOOL_RESULT]
    assert len(toolResults) >= 2, f"expected 2+ tool results, got {len(toolResults)}"
    thinkingRounds = [e for e in events if e.type == EventType.THINKING_START]
    assert len(thinkingRounds) >= 2
    print(f"t3 multi-round: OK ({len(events)} events, {len(toolResults)} tools, {len(thinkingRounds)} thinking rounds)")

# test4: Safety 阻断
async def t4():
    cfg = AgentConfig(llm_endpoint="https://mock.test")
    s = AgentSession(cfg)
    s._llm.mockSetResponses([
        {"tool_calls": [{"id": "t1", "name": "deleteFile", "arguments": {"targetPath": "/etc/shadow"}}]},
        {"content": "done"},
    ])
    events = [ev async for ev in s.submit("删文件")]
    safetyEvents = [e for e in events if e.type == EventType.SAFETY_CHECKED]
    assert len(safetyEvents) > 0
    verdicts = [e.data.get("verdict") for e in safetyEvents]
    print(f"t4 safety check: OK (verdicts={verdicts})")

asyncio.run(t1())
asyncio.run(t2())
asyncio.run(t3())
asyncio.run(t4())
print("\nS6 全部验收通过")
