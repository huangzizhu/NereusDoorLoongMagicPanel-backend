"""S1 验收测试"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.config_envs.loader import loadConfig, mergeConfigs
from ndlmpanel_agent.config_envs.schema import validateConfig

# 测试1: 加载开发配置
config = loadConfig('conf/profiles/development.json')
print(f'endpoint: {config.llm_endpoint}')
print(f'model:    {config.llm_model}')
print(f'rounds:   {config.max_tool_rounds}')
print(f'user:     {config.execution_user}')

# 测试2: validateConfig
issues = validateConfig(config)
assert issues == [], f'issues: {issues}'
print(f'validate: OK ({len(issues)} issues)')

# 测试3: mergeConfigs
merged = mergeConfigs({'a': 1, 'b': {'x': 1}}, {'b': {'y': 2}, 'c': 3})
assert merged == {'a': 1, 'b': {'x': 1, 'y': 2}, 'c': 3}
print(f'merge:   OK')

# 测试4: 环境变量覆盖
os.environ['NDLM_LLM_MODEL'] = 'qwen-max'
os.environ['NDLM_MAX_TOOL_ROUNDS'] = '5'
config2 = loadConfig('conf/profiles/development.json')
assert config2.llm_model == 'qwen-max', f'got {config2.llm_model}'
assert config2.max_tool_rounds == 5, f'got {config2.max_tool_rounds}'
print(f'env override: OK')

print('\nS1 全部验收通过 ✓')
