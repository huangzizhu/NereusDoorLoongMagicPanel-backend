import asyncio, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.llm_providers.mock import MockProvider
from ndlmpanel_agent.llm_providers.sse_parser import parseSseStream, mergeSseDeltas

# 测试1: Mock 非流式
async def t1():
    p = MockProvider([{"content": "Hello NDLM"}])
    r = await p.chat([{"role": "user", "content": "hi"}])
    assert r.content == "Hello NDLM"
    assert r.finish_reason == "stop"
    print("t1 Mock chat: OK")

# 测试2: Mock 流式
async def t2():
    p = MockProvider([{"content": "Streaming response test"}])
    chunks = []
    async for chunk in p.chatStream([{"role": "user", "content": "test"}]):
        if chunk.content:
            chunks.append(chunk.content)
    result = "".join(chunks)
    assert "Streaming" in result
    print(f"t2 Mock stream: OK ({len(chunks)} chunks)")

# 测试3: Mock tool_calls
async def t3():
    p = MockProvider([{"tool_calls": [{"id": "tc1", "name": "getCpuInfo", "arguments": {}}]}])
    r = await p.chat([{"role": "user", "content": "cpu?"}])
    assert len(r.tool_calls) == 1
    assert r.tool_calls[0]["name"] == "getCpuInfo"
    print("t3 Mock tool_calls: OK")

# 测试4: SSE 解析
def t4():
    sseBody = '''data: {"id":"1","choices":[{"delta":{"content":"Hello"}}]}
data: {"id":"2","choices":[{"delta":{"content":" World"}}]}
data: {"id":"3","choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"total_tokens":10}}
data: [DONE]'''
    events = parseSseStream(sseBody.split("\n"))
    assert len(events) == 3
    merged = mergeSseDeltas(events)
    assert merged["content"] == "Hello World"
    assert merged["finish_reason"] == "stop"
    assert merged["usage"]["total_tokens"] == 10
    print("t4 SSE parse+merge: OK")

# 测试5: SSE with tool_calls
def t5():
    sseBody = '''data: {"id":"1","choices":[{"delta":{"tool_calls":[{"index":0,"id":"tc1","function":{"name":"getCpuInfo"}}]}}]}
data: {"id":"2","choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{}"}}]}}]}
data: {"id":"3","choices":[{"delta":{},"finish_reason":"tool_calls"}]}
data: [DONE]'''
    events = parseSseStream(sseBody.split("\n"))
    merged = mergeSseDeltas(events)
    assert len(merged["tool_calls"]) == 1
    assert merged["tool_calls"][0]["name"] == "getCpuInfo"
    assert merged["finish_reason"] == "tool_calls"
    print("t5 SSE tool_calls: OK")

asyncio.run(t1())
asyncio.run(t2())
asyncio.run(t3())
t4()
t5()
print("\nS4 全部验收通过")
