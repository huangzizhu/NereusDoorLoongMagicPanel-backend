"""S3 验收测试 — MCP 协议引擎 + 工具插件"""
import os, sys, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.join(os.path.dirname(__file__), '..'))

from ndlmpanel_agent.mcp.protocol.json_rpc import encodeRequest, decodeRequest, encodeResult, encodeError
from ndlmpanel_agent.mcp.protocol.schemas import functionToToolSchema
from ndlmpanel_agent.mcp.server.registry import ToolRegistry
from ndlmpanel_agent.mcp.server.dispatcher import McpDispatcher
from ndlmpanel_agent.shared.types import ToolRiskLevel
from ndlmpanel_agent.plugins import os_observe, filesystem

# ── 测试1: JSON-RPC 编解码 ──
req = encodeRequest("tools/list", {}, 1)
decoded = decodeRequest(req)
assert decoded.method == "tools/list"
assert decoded.id == 1
resp = encodeResult(1, {"tools": ["t1"]})
assert "result" in resp
err = encodeError(1, -32601, "not found")
assert "error" in err
print("测试1 JSON-RPC: OK")

# ── 测试2: Schema 生成 ──
schema = functionToToolSchema(os_observe.getCpuInfo)
assert schema["function"]["name"] == "getCpuInfo"
assert "parameters" in schema["function"]
print("测试2 Schema生成: OK")

# ── 测试3: 工具注册 + tools/list ──
reg = ToolRegistry()
reg.register(os_observe.getCpuInfo, ToolRiskLevel.READ_ONLY)
reg.register(os_observe.getMemoryInfo, ToolRiskLevel.READ_ONLY)
reg.register(os_observe.getUptime, ToolRiskLevel.READ_ONLY)
reg.register(os_observe.getSystemVersion, ToolRiskLevel.READ_ONLY)
reg.register(filesystem.listDirectory, ToolRiskLevel.READ_ONLY)
reg.register(filesystem.createDirectory, ToolRiskLevel.WRITE)
reg.register(filesystem.deleteFile, ToolRiskLevel.DANGEROUS)

toolsList = reg.listTools()
assert len(toolsList) == 7
names = [t["function"]["name"] for t in toolsList]
assert names == sorted(names), f"not sorted: {names}"
print(f"测试3 tools/list: OK ({len(toolsList)} tools, alphabetically sorted)")

# ── 测试4: MCP Dispatcher — initialize ──
disp = McpDispatcher(reg)
initResp = disp.handle(encodeRequest("initialize", {"protocolVersion": "2024-11-05"}, 1))
initData = json.loads(initResp)
assert "result" in initData
assert initData["result"]["serverInfo"]["name"] == "ndlmpanel-agent"
print("测试4 initialize: OK")

# ── 测试5: tools/call — 调用实际工具 ──
callReq = encodeRequest("tools/call", {"name": "getCpuInfo", "arguments": {}}, 2)
callResp = disp.handle(callReq)
callData = json.loads(callResp)
assert "result" in callData
content = callData["result"]["content"][0]["text"]
cpuInfo = json.loads(content)
assert "modelName" in cpuInfo or cpuInfo.get("coreCount", 0) > 0
print(f"测试5 tools/call getCpuInfo: OK (cores={cpuInfo.get('coreCount')})")

# ── 测试6: tools/call — getUptime ──
callReq = encodeRequest("tools/call", {"name": "getUptime", "arguments": {}}, 3)
callResp = disp.handle(callReq)
callData = json.loads(callResp)
uptime = json.loads(callData["result"]["content"][0]["text"])
assert "uptime_seconds" in uptime
print(f"测试6 tools/call getUptime: OK ({uptime.get('uptime_formatted')})")

# ── 测试7: 风险等级 ──
assert reg.getRiskLevel("getCpuInfo") == ToolRiskLevel.READ_ONLY
assert reg.getRiskLevel("createDirectory") == ToolRiskLevel.WRITE
assert reg.getRiskLevel("deleteFile") == ToolRiskLevel.DANGEROUS
assert reg.getRiskLevel("nonexistent") == ToolRiskLevel.WRITE
print("测试7 风险等级: OK")

print("\nS3 全部验收通过 ✓")
