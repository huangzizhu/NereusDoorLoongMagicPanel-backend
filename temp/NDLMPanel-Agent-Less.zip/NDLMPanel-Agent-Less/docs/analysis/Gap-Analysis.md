---
type: analysis
status: complete
created: 2026-05-27
updated: 2026-05-27
tags:
  - gap-analysis
  - design-vs-implementation
---

# NDLMPanel-Agent 设计-实现差距分析

[[Design-1]] [[Design-2]] [[Skeleton-Design]]

---

## 0. 当前实现概况

已实现 **33 个源文件**，覆盖 **12 个模块**。全部 **54 项单元测试通过**。

| 模块 | 设计子模块数 | 已实现数 | 完成度 |
|------|:--:|:--:|:--:|
| `shared/` | 4 | 5（含 ops_types） | 100% |
| `config_envs/` | 3 | 3 | 100% |
| `trace_log/` | 4 | 4 | 100% |
| `safety/` | 8 | 3 | ~35% |
| `agent_core/` | 3 | 2 | ~60% |
| `context_mgmt/` | 2 | 2 | 70% |
| `mcp/` | 10+ | 5 | ~50% |
| `plugins/` | 8+ | 2 | ~20% |
| `llm_providers/` | 4 | 4 | 100% |
| `compat/` | 5+ | 2 | ~30% |
| `integration/` | 5 | 2 | ~40% |
| `execution/` | 5 | 1 | ~20% |
| **缺失模块** | — | — | — |
| `agent_router/` | 4 | 0 | 0% |
| `skills/` | 3 | 0 | 0% |
| `sub_agents/` | 5 | 0 | 0% |
| `evaluation/` | 6 | 0 | 0% |

---

## 1. 完整 Gap 清单

### 1.1 safety/ — 安全护栏（高优先级）

**设计目标（Design-2 §4.2.4）**：6 层安全防线 + 8 个子模块。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `injection_detector/` | ✅ | 已实现，13 条正则规则（中英双语） |
| `rule_engine/` | ⚠️ | 基础实现完成，但只含 6 组危险模式（设计含 13+ 组高危命令），缺少工具白名单检查 |
| `risk_scorer/` | ❌ | 未实现。设计要求的加权评分 (Intent + Command + Path + Privilege + Exfiltration + Injection) 缺失 |
| `intent_filter/` | ❌ | 未实现。用户自然语言意图风险分类未做 |
| `command_analyzer/` | ❌ | 未实现。命令级风险分析（`rm -rf /`, `dd if=`, `mkfs.*`等）未做，现在只检查参数值模式 |
| `path_policy/` | ❌ | 未实现。路径保护策略（禁止操作 /etc/shadow, /boot 等）缺失 |
| `privilege_policy/` | ❌ | 未实现。权限提升检测（`sudo`, `chmod 777`, `chown root`）缺失 |
| `exfiltration_policy/` | ❌ | 未实现。数据外传检测（`curl ... | bash`）缺失 |
| `approval_gate/` | ❌ | 未实现。AgentSession 缺少 `approve()` / `reject()` 方法 |
| `decision_engine/` | ❌ | 未实现。综合风险决策引擎（Safe/Low/Medium/High/Critical 5 级）缺失 |

**影响**：当前安全防护仅覆盖"参数模式匹配 + 注入检测"，对于真正的运维安全场景（sudo 滥用、路径保护、数据外传）防护不足。

**建议优先级**：
1. `path_policy` + `privilege_policy` — 最基础的生产安全
2. `approval_gate` — 使审批流程闭环
3. `command_analyzer` — 补充完整高危命令规则库
4. `risk_scorer` + `decision_engine` — 综合评分体系

### 1.2 agent_core/ — Agent 核心（高优先级）

**设计目标（Design-2 §4.2.6）**：Prompt 构造、LLM 调用循环、结构化输出解析、工具调用编排、Token 预算、上下文管理。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `agent_loop.py` | ⚠️ | 基础 ReAct 循环完成，但有以下 gap： |
| | | ① APPROVAL_REQUIRED 事件发出后**仍然执行了工具**（第 131-134 行），审批流程是假闭环 |
| | | ② 未集成 TraceRecorder（循环内无 trace 记录） |
| | | ③ 未调用 `compressHistory()` 做上下文压缩 |
| | | ④ 未检查 Token 预算（只检查轮次数） |
| | | ⑤ 未使用 `ContextManagement` 采集系统快照（依赖外部传入） |
| `prompt_builder.py` | ⚠️ | 4 层结构正确，但： |
| | | ① `self._messages` 属性从未赋值，访问会抛 `AttributeError` |
| | | ② L2 半静态层只支持 `policyProfile`，不支持 Skills 列表 |
| | | ③ L3 未自动集成 `ContextManagement` 快照 |
| `output_parser.py` | ❌ | 未实现。LLM 结构化输出（thinking/action JSON）解析逻辑缺失。当前依赖 LLM 原生 tool_calls 而非自定义格式 |

**关键 bug**：AgentCore.run() 第 129-135 行，`REQUIRE_CONFIRM` 分支在发出事件后直接调用了 `_executeTool()`，正确的行为应该是等待外部 `approve()` 调用。

### 1.3 agent_router/ — 意图路由（中等优先级）

**设计目标（Design-2 §4.2.8）**：4 种运行模式 + 意图分类 + Skill 选择 + SubAgent 分派。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `intent_classifier/` | ❌ | 完全未实现。无法区分诊断类/操作类/查询类/闲聊类意图 |
| `mode_controller/` | ❌ | 完全未实现。ReadOnly/Plan/Agent/BreakGlass 四种模式不存在 |
| `skill_selector/` | ❌ | 完全未实现。无法根据意图选择对应 Skill |
| `dispatch/` | ❌ | 完全未实现。SubAgent 分派逻辑缺失 |

**当前行为**：所有用户输入直接进入 AgentCore，无模式控制，无意图区分，无 Skill/SuperAgent 路由。

### 1.4 skills/ — 运维技能编排（中等优先级）

**设计目标（Design-2 §4.2.11）**：9 个预设 Skill（磁盘清理、僵尸进程诊断、服务 RCA 等），JSON 定义，多工具编排。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `registry/` | ❌ | 完全未实现 |
| `definitions/` | ❌ | 完全未实现（9 个 Skill JSON 定义不存在） |
| `executor/` | ❌ | 完全未实现 |

### 1.5 sub_agents/ — 子智能体（低优先级）

**设计目标（Design-2 §4.2.12）**：5 个 SubAgent（Observer, RCA, SafetyReview, Executor, Summarizer），权限隔离。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| 全部 5 个 | ❌ | 完全未实现 |

### 1.6 plugins/ — 运维工具插件（高优先级）

**设计目标（Design-2 §4.2.10）**：9 组插件，约 30+ 工具。

| 插件组 | 状态 | gap 说明 |
|--------|:--:|------|
| `os_observe/` | ✅ | 已实现：getCpuInfo(), getMemoryInfo(), getUptime(), getSystemVersion() |
| `filesystem/` | ⚠️ | 已实现 3 个基础函数 (list/delete/create)，但缺少：file.stat, file.hash, file.recent_modified, file.quarantine, file.truncate_log |
| `process/` | ❌ | 完全未实现：进程列表、僵尸进程检测、进程树、进程 kill |
| `disk/` | ❌ | 完全未实现：磁盘使用率、大文件查找、inode 使用率 |
| `network/` | ❌ | 完全未实现：监听端口、连接状态、网络接口 |
| `log/` | ❌ | 完全未实现：journalctl 查询、日志 tail、错误汇总 |
| `service/` | ❌ | 完全未实现：systemctl status/list/restart |
| `config_drift/` | ❌ | 完全未实现：配置快照、差异比较 |
| `security_check/` | ❌ | 完全未实现：开放端口检查、SUID 文件扫描 |

### 1.7 mcp/ — MCP 协议引擎（中等优先级）

**设计目标（Design-2 §4.2.9）**：完整的 MCP Server + MCP Client。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `protocol/json_rpc/` | ✅ | 已实现：encode/decode Request/Result/Error |
| `protocol/lifecycle/` | ❌ | 未作为独立模块实现（initialize 在 dispatcher 中硬编码） |
| `protocol/errors/` | ❌ | 未作为独立模块实现（错误码常量在 json_rpc.py 中） |
| `transports/stdio/` | ✅ | 已实现 |
| `transports/streamable_http/` | ❌ | 未实现（设计描述为 HTTP SSE 传输） |
| `server/tool_registry/` | ✅ | 已实现 |
| `server/tool_dispatcher/` | ✅ | 已实现 |
| `server/approval_bridge/` | ❌ | 未实现（审批流程与 MCP 的桥接） |
| `client/stdio_client/` | ❌ | 完全未实现 |
| `client/http_client/` | ❌ | 完全未实现 |

### 1.8 execution/ — 最小权限执行代理（中等优先级）

**设计目标（Design-2 §4.2.13）**：5 个子模块。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `executor/` | ✅ | 已实现：路径黑白名单 + shell=False + 超时控制 + 环境清洗 |
| `privilege/` | ❌ | 未实现：用户切换（setuid/sudoers 管理） |
| `sandbox/` | ❌ | 未实现：资源限制（resource.setrlimit）、路径限制 |
| `quarantine/` | ❌ | 未实现：隔离区管理（文件移至隔离区而非直接删除） |
| `rollback/` | ❌ | 未实现：操作回滚支持 |

### 1.9 integration/ — 后端对接层（中等优先级）

**设计目标（Design-2 §4.2.14）**：5 个子模块。

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `session.py` | ⚠️ | 基础实现完成，但缺少：`approve()`, `reject()`, `cancel()`, `get_trace()`, `get_state()`, `close()`, `submit_sync()` |
| `event_stream.py` | ✅ | 已实现：asyncio.Queue 生产者-消费者模式 |
| `session_manager/` | ❌ | 未实现：AgentManager（多会话生命周期管理） |
| `http_server/` | ❌ | 未实现：内置 HTTP Server |
| `unix_socket/` | ❌ | 未实现：Unix Domain Socket 接口 |
| `cli/` | ❌ | 未实现：命令行接口 + `__main__.py` |

### 1.10 compat/ — 兼容层（低优先级）

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `api_styles/openai_adapter/` | ✅ | 已实现 |
| `api_styles/claude_adapter/` | ✅ | 已实现 |
| `api_styles/native_adapter/` | ❌ | 未实现 |
| `pydantic_models/` | ❌ | 未实现（可选 FastAPI 兼容 Pydantic Model） |
| `serializers/` | ❌ | 未实现 |

### 1.11 context_mgmt/ — 上下文管理（低优先级）

| 子模块 | 状态 | gap 说明 |
|--------|:--:|------|
| `collectors/` | ⚠️ | 系统快照基本完成，但缺少：进程详情（/proc/<pid>/）、网络连接详情（/proc/net/tcp）、打开文件列表（lsof 降级） |
| `compressor/` | ⚠️ | 已实现规则摘要，但未集成 LLM 摘要（设计描述依赖 LLM 做语义压缩） |
| 自动采集与刷新 | ❌ | 未实现。快照在会话期间不会自动刷新，也没有 TTL 机制 |

### 1.12 trace_log/ — 日志系统（低优先级）

| gap | 说明 |
|------|------|
| `logging` 初始化 | `setupLogging()` 未在任何地方调用，StructuredFormatter 未注册到 root logger |
| AgentCore 集成 | `agent_loop.py` 未使用 `TraceRecorder`，循环内不产生 trace 事件 |
| 查询接口增强 | 当前只有按 trace_id/session_id 查询，不支持按时间范围、事件类型过滤 |
| 归档策略 | 无按保留天数自动归档的清理逻辑 |

### 1.13 config_envs/ — 配置系统（低优先级）

| gap | 说明 |
|------|------|
| 策略文件缺失 | `conf/policies/default.json` 和 `conf/policies/strict.json` 未创建 |
| 热加载 | 不支持 SIGUSR1/SIGHUP 信号触发的配置重载 |
| Profile 管理 | 仅支持 development/production 两个 profile |

### 1.14 缺失的模块（0% 实现）

| 模块 | 设计来源 | 说明 |
|------|------|------|
| `agent_router/` | Design-2 §4.2.8 | 意图路由、模式控制、Skill 选择 |
| `skills/` | Design-2 §4.2.11 | 运维技能编排（9 个预设 Skill） |
| `sub_agents/` | Design-2 §4.2.12 | 子智能体（5 个 SubAgent） |
| `evaluation/` | Design-2 §4.2.16 | 评测框架（功能/安全/注入/性能/回放） |

---

## 2. 关键 Bug & 设计缺陷

### 2.1 APPROVAL_REQUIRED 假闭环

**位置**：`agent_core/agent_loop.py:129-135`

```python
elif verdict.value == "require_confirm":
    stream.emit(EventType.APPROVAL_REQUIRED, {
        "tool_name": name, "arguments": args,
        "action_id": callId,
    })
    toolOutput = await self._executeTool(name, args)  # ← BUG: 应该等待 approve()
```

**修复方向**：AgentCore 需要等待一个 `asyncio.Event`，由 AgentSession.approve() 设置。

### 2.2 prompt_builder.py `messages` 属性崩溃

**位置**：`agent_core/prompt_builder.py:86-88`

```python
@property
def messages(self) -> list[dict]:
    return self._messages  # ← BUG: 从未赋值
```

### 2.3 AgentSession.submit() 不等待 AgentCore 完成

**位置**：`integration/session.py:101-102`

```python
asyncio.create_task(self._core.run(message, stream))  # fire-and-forget
async for ev in stream:  # stream 的生产者还没开始生产...
    yield ev
```

这是一个竞态条件：在 `stream.__aiter__` 开始迭代时，`AgentCore.run()` 可能尚未执行任何 `emit()`，导致迭代器立即收到 DONE 事件（如果 run 先 finish）或者正确收到事件（运气好）。

### 2.4 Safety 规则覆盖不足

当前 6 组危险模式 vs 设计中 13+ 组高危命令。缺失的关键模式：
- `rm -rf /`, `rm -rf /*`
- `mkfs.*`
- `dd if=/dev/zero of=/dev/*`
- `iptables -F`
- `curl ... | bash`
- `wget ... | sh`
- `python -c ...`
- `sudo su`

---

## 3. 实现优先级矩阵

按"赛题验收影响 × 实现工作量"排序：

| 优先级 | 任务 | 影响 | 工作量 |
|:--:|------|:--:|:--:|
| 🔴 P0 | 修复 APPROVAL_REQUIRED 假闭环 | 核心流程 bug | 小 |
| 🔴 P0 | 修复 prompt_builder messages 属性崩溃 | 运行时崩溃 | 小 |
| 🔴 P0 | 修复 AgentSession.submit() 竞态 | 流式输出不可靠 | 小 |
| 🔴 P0 | Safety 规则库补全（高危命令 + 路径保护 + 权限策略） | 安全赛题核心 | 中 |
| 🟡 P1 | plugins 补充（disk/process/network/log/service） | Agent 核心能力 | 大 |
| 🟡 P1 | AgentSession.approve()/reject() 审批闭环 | 安全交互流程 | 中 |
| 🟡 P1 | AgentCore 集成 TraceRecorder | 审计赛题核心 | 中 |
| 🟡 P1 | output_parser.py（结构化输出解析） | LLM 可靠性 | 小 |
| 🟢 P2 | agent_router/（意图路由 + 模式控制） | 整体架构 | 大 |
| 🟢 P2 | skills/（运维技能编排） | 差异化能力 | 大 |
| 🟢 P2 | execution 补全（privilege/sandbox/quarantine） | 安全执行 | 中 |
| 🔵 P3 | AgentManager 多会话管理 | 后端对接 | 中 |
| 🔵 P3 | compat pydantic_models | 后端对接 | 中 |
| 🔵 P3 | sub_agents/ | 架构亮点 | 大 |
| 🔵 P3 | evaluation/ | 赛题文档 | 大 |
| 🔵 P3 | logging 初始化 | 运维可观测性 | 小 |

---

## 4. 总结

**已实现核心链路**：Config → AgentSession → AgentCore → LLMProvider → MCPDispatcher → Plugin → 结果返回。这条链路基础可用。

**缺失最严重的三个方向**：
1. **安全纵深**（safety 子模块大量缺失，规则库不完整，审批流程未闭环）
2. **运维能力覆盖**（plugins 只完成了 2/9 组，关键技术栈缺失）
3. **架构完整性**（router/skills/sub_agents 三个整模块为零）

建议优先集中解决 P0 级 bug 和安全规则补全，它们是任何功能演示的前提。
