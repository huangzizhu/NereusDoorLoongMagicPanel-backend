---
type: analysis
status: complete
created: 2026-05-27
tags:
  - execution
  - executor
  - subprocess
  - security
  - deep-dive
---

# Execution 模块深度解析：最小权限命令执行器

[[Design-1]] [[Design-2]] [[Skeleton-Design]] [[Gap-Analysis]] [[Operational-Flow]] [[Project-File-Analysis]]

---

## 0. 前置背景知识

### 0.1 为什么 Agent 需要有独立的执行模块？

大模型 (LLM) 的本质是一个"文字预测器"——它只能输出文本，不能直接操作计算机。但在运维场景中，Agent 必须对 Linux 系统执行真实操作：查看进程、清理日志、重启服务。

问题来了：**LLM 输出的命令是不可信的**。一个被"越狱"的模型可能输出 `rm -rf /`，一个幻觉模型可能输出不存在的命令。所以必须有一层**确定性的、不可绕过**的代码防护，这就是 Execution 模块存在的根本原因。

```
为什么不能 LLM 输出什么就执行什么?

LLM 输出:  "执行 rm -rf /tmp/*"        ← 看起来无害
实际效果:  rm -rf /tmp /home /etc      ← 空格分隔被恶意利用
  
LLM 输出:  "用 python -c 'print(123)'"  ← 看起来像测试
实际效果:  python -c '__import__("os").system("rm -rf /")'  ← 代码注入

LLM 输出:  "sudo systemctl stop firewalld"  ← 可能是合理操作
实际效果:  打开了所有端口的防火墙         ← 但不符合安全策略
```

所以 Execution 模块的核心职责是：**把 LLM 的"想法"和"执行"之间加一道墙**。在这道墙上可以检查路径、限制用户、控制超时、截断输出。

### 0.2 前置知识：Linux 子进程执行

```python
# 方式A: shell=True (危险)
subprocess.run("ls -la /tmp", shell=True)
# ↑ 命令通过 /bin/sh 解释执行
# shell 会解析 $()、``、&&、||、;、| 等 shell 元字符
# 如果用户输入中包含 `; rm -rf /` 就会被执行

# 方式B: shell=False (安全)
subprocess.run(["ls", "-la", "/tmp"], shell=False)
# ↑ 以列表形式传递，第一个元素是可执行文件路径，后面是参数
# shell 元字符不会被解释，`; rm -rf /` 只是一个普通参数
```

**核心安全规则：永远用 `shell=False` + list 参数。**

### 0.3 前置知识：Linux 权限模型

Linux 是多用户系统，不同用户有不同的文件访问权限。

| 用户 | UID | 典型权限 |
|------|:---:|------|
| `root` | 0 | 所有文件/所有操作 |
| `nobody` | 65534 | 几乎无权限（只读公共文件，不能写任何地方） |
| `osagent-exec` | 自定义 | 通过 sudoers 白名单被授权执行少数特定命令 |

`nobody` 是系统内置的"无权限"用户。如果一个命令以 `nobody` 身份运行，即使 LLM 输出了 `rm -rf /etc`，也会因为权限不足而失败。

**为什么选择 nobody？** 这是"失败安全(fail-safe)"原则——宁可让正常操作因权限不足失败，也不能让恶意操作因权限充足成功。

### 0.4 前置知识：Python `subprocess.run()` 详解

```python
subprocess.run(
    argv,              # list[str]: 命令 + 参数，如 ["ls", "-la", "/"]
    capture_output=True,  # 捕获 stdout 和 stderr（否则打印到控制台）
    text=True,         # stdout/stderr 返回 str 而非 bytes
    timeout=30,        # 超时秒数，超时则抛出 TimeoutExpired 异常
    env=safeEnv,       # 环境变量字典，不传则继承父进程环境
    shell=False,       # 强制不使用 shell
)
```

返回值是一个 `CompletedProcess` 对象，包含：
- `proc.returncode`：0 表示成功，非 0 表示失败
- `proc.stdout`：标准输出文本（因为 `text=True`）
- `proc.stderr`：标准错误文本

### 0.5 前置知识：Python `run_in_executor`

在 `agent_loop.py` 和 `openai_compat.py` 中你会看到：

```python
raw = await loop.run_in_executor(None, self._dispatcher.handle, mcpReq)
```

这是 Python asyncio 的关键模式：**把阻塞的同步函数 (如 `subprocess.run()`、`urllib.request.urlopen()`) 放到线程池执行，不阻塞事件循环**。`None` 表示使用默认线程池。等价于"让阻塞操作在后台线程运行，当前协程等它完成但不卡住其他协程"。

---

## 1. 模块全貌

### 1.1 文件组成

```
execution/
├── __init__.py   ← 模块入口，导出 runCommand
└── executor.py   ← 核心：runCommand() 函数 (68 行)
```

**只有 1 个功能文件**，是整个项目中最小的模块。

### 1.2 当前模块的执行流程位置

```
AgentSession.submit()
  └── AgentCore.run()
      └── [LLM 返回 tool_calls]
          └── safety.checkToolCall()  ← 安全规则校验（参数/路径模式）
              └── [ALLOW]
                  └── McpDispatcher.handle("tools/call")
                      └── _handle_tools_call()
                          └── func(**args)  ← 调用 plugin 函数
                              │
                              │  ★ 注意: 当前流程中，executor 模块
                              │     完全没有被调用！
                              │
                              │  plugin 函数自己直接调用了 subprocess:
                              │  os_observe.py → subprocess.run(["df", ...])
                              │  filesystem.py → os.remove() / os.makedirs()
                              │
                              └── 返回结果 → 注入 LLM messages
```

**关键发现：executor 模块当前是"已实现但未被使用"的状态。** 所有 plugin 函数直接使用 `os.remove()`、`subprocess.run()` 等系统调用，没有经过 `execution/executor.py` 这道安全闸门。

---

## 2. 代码逐行详解

### 2.1 `executor.py` — 最小权限命令执行器 (68 行)

#### 2.1.1 模块级常量

```python
_SAFE_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
```

这是执行命令时会用到的 `PATH` 环境变量。`PATH` 决定了当用户输入 `ls` 时，系统在哪几个目录里查找 `ls` 这个可执行文件。

**为什么需要重写 PATH**：父进程的 PATH 可能包含用户自定义的目录（如 `~/bin`），这些目录可能含有恶意脚本。使用固定的安全 PATH 保证执行的命令一定是系统标准命令。

**这几个目录的作用**：

| 路径 | 内容 |
|------|------|
| `/usr/local/sbin` | 管理员安装的系统管理命令（优先级最高） |
| `/usr/local/bin` | 管理员安装的普通命令 |
| `/usr/sbin` | 发行版提供的系统管理命令 |
| `/usr/bin` | 发行版提供的普通命令 |
| `/sbin` | 核心系统管理命令（fdisk, mkfs, ifconfig） |
| `/bin` | 核心命令（ls, cp, mv, rm） |

#### 2.1.2 函数签名

```python
def runCommand(
    argv: list[str],                    # 命令 + 参数，如 ["ls", "-la", "/tmp"]
    timeout: int = 30,                  # 超时秒数，默认 30 秒
    runAs: str = "nobody",              # 以哪个用户执行，默认 nobody
    allowedPaths: list[str] | None = None,  # 路径白名单（可选）
    deniedPaths: list[str] | None = None,   # 路径黑名单（可选）
    maxOutputBytes: int = 65536,        # stdout 最大输出，默认 64KB
) -> tuple[bool, str, str]:            # (成功?, stdout内容, stderr内容)
```

**参数设计分析**：

- `argv: list[str]`：强制调用方以列表传参（不能用 string），这是安全设计的入口。列表形式保证了"命令"和"参数"的边界是清晰的。
- `timeout = 30`：30 秒超时对大多数运维命令够用（`df`、`ss`、`ps` 通常 < 1 秒），但 `find /` 这类扫描命令可能超时。
- `runAs = "nobody"`：参数叫 `runAs` 暗示它应该做用户切换，但**当前实现并没有真正使用这个参数**（详见下方分析）。
- `allowedPaths / deniedPaths`：路径黑白名单允许调用方控制命令可以/不可以操作哪些目录。
- `maxOutputBytes = 65536`：64KB 限制，防止 `cat /var/log/syslog` 这类命令产生几十 MB 输出塞爆 LLM 上下文窗口。

#### 2.1.3 路径安全检查 (第 27-40 行)

```python
# ── 黑名单检查 ──
if deniedPaths:
    for arg in argv:              # 遍历每个命令行参数
        argStr = str(arg)         # 确保是字符串
        for denied in deniedPaths:
            if argStr.startswith(denied) or denied in argStr:
                return False, "", f"拒绝: 参数 {argStr} 命中黑名单路径 {denied}"

# ── 白名单检查 ──
if allowedPaths:
    for arg in argv:
        argStr = str(arg)
        # 只检查以 / 开头的参数（路径参数），忽略选项参数如 "-la"
        if argStr.startswith("/") and not any(
            argStr.startswith(p) for p in allowedPaths
        ):
            return False, "", f"拒绝: 路径 {argStr} 不在白名单中"
```

**黑名单逻辑**：如果任何一个参数 `startswith(denied)` **或** `denied in argStr`，直接拒绝。

- `startswith` 检查：`arg="/etc/shadow"`，`denied="/etc"` → 命中
- `in` 检查：`arg="/home/user/../../etc/shadow"`，`denied="/etc"` → 命中（路径穿越）

**白名单逻辑**：如果参数以 `/` 开头（看起来是路径），检查它是否以白名单中的某个前缀开始。如果不是任何一个白名单前缀的子路径，拒绝。

**为什么要有 `<arg>.startswith("/")` 判断**：
- `arg = "/home/user/logs"` → 这是路径，需要检查是否在白名单
- `arg = "-la"` → 这是选项，跳过检查。不能用 `startswith("/")` 判断它

**`any()` 函数**：Python 内置函数，`any([False, False, True])` → `True`（列表中任意一个为 True 则返回 True）。

```python
# 等价展开
all_checks = []
for p in allowedPaths:
    all_checks.append(argStr.startswith(p))
if not any(all_checks):  # 如果所有检查都失败
    return False  # 拒绝
```

**黑名单 vs 白名单策略对比**：

| | 黑名单 (deniedPaths) | 白名单 (allowedPaths) |
|---|---|---|
| 原理 | "这些地方不能去" | "只能去这些地方" |
| 默认行为 | 默认允许 | 默认拒绝 |
| 安全性 | 中（容易遗漏） | 高（未授权全拒绝） |
| 灵活性 | 高 | 低 |
| 适用场景 | 阻止已知危险路径 | 严格限制操作范围 |

**安全分析**：当前黑名单检查用 `denied in argStr` 是**子字符串匹配**，有误报风险。例如 `denied="/etc"` 会错误拦截 `arg="--config=/my-etc-project/config"`（因为它包含 "etc"）。

#### 2.1.4 环境清洗 (第 43-47 行)

```python
safeEnv = {
    "PATH": _SAFE_PATH,
    "HOME": "/tmp",
    "LANG": os.environ.get("LANG", "C.UTF-8"),
}
```

为什么只传这 3 个环境变量？

- **不传父进程环境**：父进程的环境是 Agent 自己的运行环境，可能包含 `PYTHONPATH`、`LD_LIBRARY_PATH`、`API_KEY` 等敏感信息。子进程不需要也不应该获得这些。
- **`PATH`**：重写为安全路径，防止执行用户自定义脚本。
- **`HOME`**：设为 `/tmp`。许多程序会读写 `$HOME/`，设为 `/tmp` 防止读写真实用户的 home 目录。`/tmp` 是所有用户可写的临时目录。
- **`LANG`**：设置输出编码，`C.UTF-8` 表示纯英文 UTF-8 输出（避免某些命令输出非 ASCII 字符乱码）。

#### 2.1.5 子进程执行 (第 49-67 行)

```python
try:
    proc = subprocess.run(
        argv,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=safeEnv,
        shell=False,          # 严禁 shell 注入
    )

    # 输出截断
    stdout = proc.stdout[:maxOutputBytes] if proc.stdout else ""
    stderr = proc.stderr[:maxOutputBytes] if proc.stderr else ""
    success = proc.returncode == 0

    return success, stdout, stderr

# 三种异常分别处理
except subprocess.TimeoutExpired:
    return False, "", f"命令超时 ({timeout}s): {' '.join(argv)}"
except FileNotFoundError:
    return False, "", f"命令不存在: {argv[0]}"
except Exception as exc:
    return False, "", str(exc)
```

**设计要点**：

1. **所有异常都返回 `(False, "", errorMsg)` 而非抛出**。这很重要——如果 AgentCore 调用 `runCommand()` 时函数抛异常，整个 Agent Loop 可能中断。用统一的返回格式保证 Agent 可以优雅地告知 LLM "这个命令执行失败了，原因是什么"。

2. **三种异常区分处理**：
   - `TimeoutExpired`：命令跑了太久，被 SIGKILL 强制终止。告知具体命令和超时时间。
   - `FileNotFoundError`：命令本身不存在（如 `ls` 被拼成 `lss`）。告知是哪个命令。
   - 其他异常：兜底。返回异常消息。

3. **输出截断用 `[:maxOutputBytes]`**：Python 的切片语法，只取前 64KB。如果 stdout 是 `"hello world"`（11 字节），`[:65536]` 返回完整字符串。如果 stdout 是 1MB，只返回前 64KB。

4. **`' '.join(argv)`**：把命令数组拼接回字符串用于错误消息。`["ls", "-la", "/tmp"]` → `"ls -la /tmp"`。

5. **`proc.returncode == 0`**：Unix 约定，退出码 0 = 成功，非 0 = 失败。

#### 2.1.6 `runAs` 参数未实现

这是当前实现最关键的一个 gap。函数签名声明了 `runAs: str = "nobody"`，但整个函数体中**没有任何代码实际做用户切换**。

要真正以 `nobody` 用户执行命令，需要用 `subprocess.run()` 的 `user` / `group` 参数（Python 3.9+），或通过 `preexec_fn=os.setuid()`（有安全风险），或通过 `sudo -u nobody <cmd>`。这些在当前实现中都没有。

---

## 3. 模块当前实际作用分析

### 3.1 谁在用 executor？

**没有人。** 在当前项目中，`executor.py` 处于"已实现但未被引用"状态：

```
plugin 中直接调用 OS:
  os_observe.py  →  subprocess.run(["df", "-h", ...])  ← 没用 runCommand()
  os_observe.py  →  open("/proc/cpuinfo")              ← 没用 runCommand()
  filesystem.py  →  os.remove(path)                     ← 没用 runCommand()
  filesystem.py  →  os.makedirs(path)                   ← 没用 runCommand()

AgentCore 中的执行:
  agent_loop.py  →  dispatcher.handle()  →  func(**args)
                  ← 工具被直接当作 Python 函数调用，不走任何执行代理
```

**这意味着什么**：
1. `runCommand()` 中的路径黑白名单检查、环境清洗、超时控制在当前代码路径中**完全没有生效**
2. 安全防护完全依赖 `safety/rule_engine.py` 的参数模式匹配（只检查了 6 组正则）
3. 理论上 LLM 可以通过 `filesystem.deleteFile("/etc/passwd")` 直接删除系统文件（如果进程有 root 权限），因为 `os.remove()` 不需要经过 `runCommand()`

### 3.2 executor 的设计意图

`runCommand()` 是为**执行 shell 命令的 plugin** 设计的（如将来会实现的 `service_plugin` 调 `systemctl stop`，`log_plugin` 调 `journalctl`）。它不适合用于当前已经实现的纯 Python 函数 plugin（读 `/proc/`、`os.remove()`）。

设计中的"执行代理"应该是整个 tool 调用的统一出口，但当前的设计将它定位成了仅用于 shell 命令，而 Python 函数 plugin 绕过了它。

---

## 4. 与设计文档的对比

### 4.1 设计 (Design-2 §4.2.13) 中的 Execution 模块

```
Execution
├─ executor/           ← 核心执行器
├─ privilege/          ← 用户切换、sudoers 管理
├─ sandbox/            ← 资源限制、路径限制
├─ quarantine/         ← 隔离区管理
└─ rollback/           ← 回滚支持
```

**设计中还有一个 `ExecutionConstraints` dataclass**：

```python
@dataclass
class ExecutionConstraints:
    tool_name: str
    argv: list[str]
    cwd: str
    allowed_paths: list[str]
    denied_paths: list[str]
    env_whitelist: list[str]
    run_as_user: str
    timeout_seconds: int
    max_output_bytes: int
    risk_level: str
    approval_id: str | None
    trace_id: str
```

**设计中的执行流程**：

```
接收执行请求 → 校验 Constraints 完整性 → 切换用户 (setuid/sudo)
→ 设置资源限制 (resource.setrlimit) → 构造安全环境变量
→ subprocess.run(shell=False) → 退出码判断
→ 截断输出 (max_output_bytes) → TraceLog 记录
```

**设计中的系统账号体系**：

| 账号 | 用途 | 权限 |
|------|------|------|
| `osagent` | Agent 主进程 | 只读 + 有限写入 |
| `osagent-exec` | 执行代理 | sudoers 白名单内的命令 |
| `root` | 不直接运行 Agent | 仅通过 sudoers 白名单间接使用 |

### 4.2 逐子模块对比

| 子模块 | 设计 (Design-2) | 实现 (executor.py) | 差距 |
|--------|:--:|:--:|:--:|
| `executor/` | 完整执行器，接受 `ExecutionConstraints` | `runCommand()` 函数，68 行 | ⚠️ 基础版 |
| `privilege/` | 用户切换、sudoers 白名单管理 | 无（`runAs` 参数未实现） | ❌ 缺失 |
| `sandbox/` | `resource.setrlimit` 资源限制（CPU/内存/文件数） | 无 | ❌ 缺失 |
| `quarantine/` | 隔离目录管理、文件移至隔离区而非直接删除 | 无 | ❌ 缺失 |
| `rollback/` | 操作回滚支持（undo/redo 文件快照） | 无 | ❌ 缺失 |
| `ExecutionConstraints` | 结构化的执行约束 dataclass | 平铺的函数参数 | ⚠️ 简化 |
| 系统账号体系 | `osagent` / `osagent-exec` / `root` 三级分离 | `runAs="nobody"` 仅参数声明 | ❌ 未实现 |
| 环境变量白名单 | `env_whitelist` 字段控制传哪些 env | 硬编码 `{"PATH":..., "HOME":"/tmp", "LANG":...}` | ⚠️ 简化 |
| TraceLog 集成 | 执行结果写入 TraceLog | 无（返回值是 tuple，调用方负责记录） | ❌ 缺失 |

### 4.3 设计中的执行流程 vs 当前实际流程

```
设计中的流程:                          当前实际流程:

AgentCore                              AgentCore
  │                                      │
  ▼                                      ▼
Safety: 校验                             Safety: 校验 (只有参数模式匹配)
  │                                      │
  ▼                                      ▼
MCP: tools/call                         MCP: _handle_tools_call
  │                                      │
  ▼                                      ▼
ExecutionConstraints:                   直接 func(**args)
  构造约束对象                             │
  │                                    ┌─┼─────────────────────┐
  ▼                                    │ │                     │
executor.runCommand()                  │ os.remove()           │ subprocess.run()
  │                                    │ (无权限控制)          │ (无路径检查)
  ├── privilege: 切换用户              │ │                     │
  ├── sandbox: 资源限制               ┌┘ │                     │
  ├── validate: 路径检查              │   │                     │
  ├── env: 环境清洗                   │   │                     │
  ├── timeout: 超时控制               │   │                     │
  └── output: 截断                    │   │                     │
  │                                   │   │                     │
  ▼                                   ▼   ▼                     ▼
TraceLog 记录                         无 TraceLog 记录
```

### 4.4 对比总结

| 维度 | 设计 | 实现 | 差距评估 |
|------|:---:|:---:|:--:|
| 核心执行器框架 | 完整子模块 | 1 个函数 (68 行) | ⚠️ 基础功能存在 |
| 路径安全检查 | 白名单 + 黑名单 | 白名单 + 黑名单 | ✅ 一致 |
| shell 注入防护 | `shell=False` | `shell=False` | ✅ 一致 |
| 环境变量清洗 | 白名单控制 | 硬编码 3 个变量 | ⚠️ 够用但不灵活 |
| 超时控制 | `timeout_seconds` | `timeout=30` | ✅ 有 |
| 输出截断 | `max_output_bytes` | `maxOutputBytes` | ✅ 有 |
| 用户切换 | setuid/sudoers | `runAs` 参数未实现 | ❌ 核心 gap |
| 资源限制 | rlimit | 无 | ❌ 缺失 |
| 隔离区 | quarantine 目录 | 无 | ❌ 缺失 |
| 回滚 | undo/redo | 无 | ❌ 缺失 |
| 执行约束对象 | `ExecutionConstraints` dataclass | 平铺参数 | ⚠️ 简化 |
| 系统账号 | osagent/osagent-exec/root | 未实现 | ❌ 缺失 |
| TraceLog 集成 | 执行后自动记录 | 无 | ❌ 缺失 |
| **实际被调用** | — | **否** | ❌ **最严重 gap** |

---

## 5. 核心问题：为什么 executor 没有被使用？

原因在于项目采用了两条不同的执行路径：

**路径 A：MCP + 函数调用**（当前实际使用）
```
AgentCore → McpDispatcher.handle() → func(**args)  [Python 函数调用]
```
适用于纯 Python 实现的 plugin（读 `/proc/`、`os.remove()`），不需要 executor。

**路径 B：executor.runCommand()**（设计意图但未连接）
```
AgentCore → Safety → ExecutionConstraints → runCommand(argv)  [命令执行]
```
适用于调用外部命令的 plugin（`systemctl`、`journalctl`）。

**两条路径没有统一的闸门**。修复方向有两种：

1. **方案一（轻量）**：让 `_handle_tools_call` 在做 `func(**args)` 之前先检查路径参数，把 Python 函数调用也纳入安全管控
2. **方案二（完整）**：实现 `ExecutionConstraints` dataclass，让所有工具（无论是 Python 函数还是 shell 命令）都生成一个约束对象，通过统一的 `execute(constraints)` 出口

---

## 6. 附录：Python 技巧速查

| 技巧 | 出现位置 | 作用 |
|------|----------|------|
| `subprocess.run(argv, shell=False)` | executor.py:50 | 安全执行命令（不用 shell 解析） |
| `proc.returncode == 0` | executor.py:58 | 检查命令是否成功 |
| `proc.stdout[:maxOutputBytes]` | executor.py:56 | Python 切片截断字符串 |
| `' '.join(argv)` | executor.py:63 | 列表拼接回字符串 |
| `os.environ.get("LANG", "C.UTF-8")` | executor.py:46 | 读环境变量，不存在用默认值 |
| `argStr.startswith(p)` | executor.py:38 | 检查字符串是否以某前缀开头 |
| `any(iterable)` | executor.py:37 | 迭代器中任意 True 返回 True |
| `tuple[bool, str, str]` | executor.py:12 | Python 3.9+ 元组类型注解 |
| `list[str] \| None` | executor.py:10 | union 类型（可以是 list 或 None） |
