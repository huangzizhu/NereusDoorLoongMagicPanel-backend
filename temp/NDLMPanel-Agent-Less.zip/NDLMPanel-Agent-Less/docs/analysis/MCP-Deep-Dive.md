---
type: analysis
status: complete
created: 2026-05-27
tags:
  - mcp
  - protocol
  - architecture
  - deep-dive
---

# MCP 模块深度解析：从背景到实现的完整路线图

[[Design-1]] [[Design-2]] [[Skeleton-Design]] [[Gap-Analysis]] [[Operational-Flow]] [[Project-File-Analysis]]

---

## 0. 前置背景知识

### 0.1 什么是 MCP (Model Context Protocol)？

MCP 是 Anthropic 提出的一套**标准化通信协议**，解决大模型应用中的"工具调用"问题。

**没有 MCP 时的困境**：每个大模型厂商对工具调用的格式定义不同（OpenAI 用 `function_call` JSON inside message, Claude 用 `tool_use` content block）。每个运维工具的实现也不同（有的用类，有的用函数，有的用命令行）。结果是**N 个模型 × M 个工具 = N×M 种集成方式**，维护成本极高。

**MCP 的解决方案**：定义一套与模型无关、与语言无关的协议，所有工具都按统一标准暴露。这样模型只需要学习一次协议，就可以调用任何 MCP 兼容的工具。

```
没有 MCP:                      有 MCP:
                                
  LLM ──→ 自定义格式A ──→ 工具1    LLM ──→ JSON-RPC ──→ MCP Server ──→ 工具1
   │                                                        ├──→ 工具2
   ├──→ 自定义格式B ──→ 工具2                               └──→ 工具3
   │
   └──→ 自定义格式C ──→ 工具3
```

### 0.2 什么是 JSON-RPC 2.0？

JSON-RPC 是 MCP 使用的底层通信格式。它是一种用 JSON 编码的远程过程调用协议。一个概念类比：

```
本地函数调用:  result = getCpuInfo()
JSON-RPC:     发送 {"method": "getCpuInfo", "params": {}} → 收到 {"result": {...}}
```

JSON-RPC 定义了 4 种消息格式：

| 消息类型 | 方向 | 结构 |
|----------|------|------|
| **请求 (Request)** | 客户端 → 服务端 | `{"jsonrpc":"2.0", "id":1, "method":"tools/call", "params":{...}}` |
| **成功响应 (Result)** | 服务端 → 客户端 | `{"jsonrpc":"2.0", "id":1, "result":{...}}` |
| **错误响应 (Error)** | 服务端 → 客户端 | `{"jsonrpc":"2.0", "id":1, "error":{"code":-32601, "message":"..."}}` |
| **通知 (Notification)** | 双向 | `{"jsonrpc":"2.0", "method":"notifications/initialized"}`, 无 `id` 字段 |

关键规则：**每个 Request 中的 `id` 字段在 Response 中原样返回**。这样客户端可以匹配"某次请求收到了某个响应"，即使用户同时发了多个请求。

### 0.3 MCP 协议的生命周期

MCP 规定了客户端和服务端之间必须遵守的交互顺序：

```
Phase 1: 初始化握手
  客户端 → 服务端: {"method": "initialize", "params": {...}, "id": 1}
  服务端 → 客户端: {"result": {"protocolVersion": "2024-11-05", "serverInfo": {...}}, "id": 1}
  客户端 → 服务端: {"method": "notifications/initialized"}   ← 无 id，这是通知

Phase 2: 正常运行
  客户端 → 服务端: {"method": "tools/list", "id": 2}
  服务端 → 客户端: {"result": {"tools": [...]}, "id": 2}

  客户端 → 服务端: {"method": "tools/call", "params": {"name":"getCpuInfo", "arguments":{}}, "id": 3}
  服务端 → 客户端: {"result": {"content": [{"type":"text","text":"..."}]}, "id": 3}

  客户端 → 服务端: {"method": "ping", "id": 4}
  服务端 → 客户端: {"result": {}, "id": 4}

Phase 3: 关闭（本项目未实现）
  服务端 → 客户端: {"method": "notifications/cancelled", "params": {"reason": "..."}}
```

### 0.4 本项目为什么不直接用官方 MCP SDK？

官方 MCP Python SDK (`mcp`) 依赖链：

```
mcp → pydantic ≥ 2.0 → pydantic-core (Rust 编译)  
    → httpx → h11 → anyio  
    → uvicorn → uvloop (C 编译)
```

**但目标平台是 LoongArch + 麒麟 V11**，这些包要么没有预编译 wheel，要么 C 扩展无法在该架构编译。因此，本项目自己实现了一个**MCP 最小可用子集**，只用 Python 标准库，在任意平台上都是 `pip install` 即用。

### 0.5 本项目 MCP 在整体架构中的位置

```
浏览器 (Web UI)
  │
  ▼
后端 (FastAPI / Flask)
  │  import ndlmpanel_agent
  ▼
AgentSession  ──→ AgentCore   ──→ LLMProvider (LLM 对话)
                      │
                      │  LLM 返回 tool_calls 时
                      ▼
              safety/rule_engine    ← 安全校验 (决策前)
                      │
                      ▼ [ALLOW]
              McpDispatcher.handle("tools/call")
                      │
                      ▼
              ToolRegistry.getTool(name)   ← 找到对应函数
                      │
                      ▼
              func(**args)   ← 执行真正的 Python 函数
                (plugins/os_observe.py → 读 /proc/cpuinfo)
                (plugins/filesystem.py → os.remove())
                      │
                      ▼
              返回 dataclass 实例 (CpuInfo / MemoryInfo / ...)
                      │
                      ▼
              json.dumps() → 注入 messages → 送回 LLM 继续推理
```

---

## 1. 模块总览：8 个文件，3 个层级

```
mcp/                          ← 模块根
├── __init__.py               ← 模块说明 ("MCP 协议引擎")
│
├── protocol/                 ← 第1层: 协议定义 (编解码)
│   ├── __init__.py
│   ├── json_rpc.py           ← JSON-RPC 2.0 消息的编码与解码
│   └── schemas.py            ← 自动把 Python 函数转成 JSON Schema
│
├── transports/               ← 第2层: 传输方式 (管道)
│   ├── __init__.py
│   └── stdio.py              ← stdin/stdout 行协议 (仅供独立进程使用)
│
└── server/                   ← 第3层: 服务端逻辑 (分发)
    ├── __init__.py
    ├── registry.py           ← 工具注册中心 ("白名单")
    └── dispatcher.py         ← 请求路由器 ("接线员")
```

**依赖关系**（下层被上层引用）：

```
                    dispatcher.py
                    ├── json_rpc.py   (编解码)
                    └── registry.py   (查工具)
                         └── schemas.py  (生成工具描述)
                    stdio.py
                    └── json_rpc.py (handler 需要解析请求)
```

---

## 2. 逐文件详细解析

### 2.1 `protocol/json_rpc.py` — JSON-RPC 2.0 编解码

**文件职责**：把 Python 对象变成合法的 JSON-RPC 字符串，以及把字符串变回 Python 对象。

**为什么它是模块的基础**：MCP 协议规定所有通信必须用 JSON-RPC 2.0 格式。没有这个文件，本模块的"发消息"和"收消息"都无法标准化。

#### 2.1.1 模块级常量

```python
JSONRPC_VERSION = "2.0"        # 协议版本号，所有消息都会带这个字段

# 4个标准错误码 (负数表示服务端错误，正数或零留给自定义)
PARSE_ERROR      = -32700      # 收到非法 JSON 时返回
METHOD_NOT_FOUND = -32601      # 请求的方法未注册时返回
INVALID_PARAMS   = -32602      # 参数格式不合法时返回
INTERNAL_ERROR   = -32603      # 服务端内部异常时返回
```

这几个常量的值是 JSON-RPC 2.0 规范强制要求的，所有实现必须一致。数字范围的含义是规范制定的：`-32768` 到 `-32000` 是保留给协议本身的。

#### 2.1.2 `JsonRpcRequest` dataclass

```python
@dataclass
class JsonRpcRequest:
    jsonrpc: str = JSONRPC_VERSION     # "2.0"
    id: int | str | None = None        # 请求 ID (通知时为空)
    method: str = ""                   # 方法名，如 "tools/call"
    params: dict[str, Any] = field(default_factory=dict)  # 参数字典
```

这是一个"数据容器"。用 dataclass 而非普通 dict 的好处是：
- IDE 可以自动补全字段名
- 写错字段名会在运行时直接报错，而不是静默忽略
- 类型注解 (`int | str | None`) 告诉后来的开发者 `id` 可能是整数、字符串或空值

#### 2.1.3 `encodeRequest` — 把请求编码为 JSON 字符串

```python
def encodeRequest(method, params=None, reqId=None) -> str:
    req = {"jsonrpc": "2.0", "method": method, "params": params or {}}
    if reqId is not None:        # 如果有 id，加进去 (通知不应有 id)
        req["id"] = reqId
    return json.dumps(req, ensure_ascii=False)
```

使用示例：
```python
# 生成: {"jsonrpc":"2.0","method":"tools/list","params":{},"id":1}
encodeRequest("tools/list", {}, 1)
```

`ensure_ascii=False` 确保中文字符不会被转成 `\uXXXX`，直接输出原始字符。

#### 2.1.4 `decodeRequest` — 把 JSON 字符串解码为 Python 对象

```python
def decodeRequest(raw: str) -> JsonRpcRequest:
    try:
        data = json.loads(raw)            # 先解析 JSON
    except json.JSONDecodeError:
        return JsonRpcRequest(id=None, method="")  # 解析失败返回空请求
    return JsonRpcRequest(
        id=data.get("id"),
        method=data.get("method", ""),
        params=data.get("params", {}),
    )
```

`data.get("key", default)` 是安全取值方法：如果 "key" 不存在，返回 `default` 而不会报 KeyError。

#### 2.1.5 `encodeResult` / `encodeError` — 把响应编码为 JSON 字符串

```python
# 成功响应: {"jsonrpc":"2.0","id":1,"result":{"tools":[...]}}
encodeResult(1, {"tools": [...]})

# 错误响应: {"jsonrpc":"2.0","id":1,"error":{"code":-32601,"message":"未知方法: bad"}}
encodeError(1, -32601, "未知方法: bad")
```

成功响应用 `"result"` 字段，错误响应用 `"error"` 字段，两者互斥。这是 JSON-RPC 规范强制要求的：不能同时有 `result` 和 `error`。

#### 2.1.6 小结

```
┌────────────────────────────────────────────────────┐
│              json_rpc.py 的作用                     │
│                                                    │
│  encodeRequest(method, params, id)                  │
│      Python dict ───→ JSON 字符串                  │
│                                                    │
│  decodeRequest(raw_json)                           │
│      JSON 字符串 ───→ Python JsonRpcRequest 对象    │
│                                                    │
│  encodeResult(id, data)                            │
│      执行结果 ───→ JSON-RPC 成功响应字符串           │
│                                                    │
│  encodeError(id, code, msg)                        │
│      错误信息 ───→ JSON-RPC 错误响应字符串           │
└────────────────────────────────────────────────────┘
```

---

### 2.2 `protocol/schemas.py` — 函数签名 → JSON Schema

**文件职责**：自动分析一个 Python 函数的参数结构，生成 LLM 可以理解的 JSON Schema。

**为什么需要它**：LLM 需要知道每个工具"叫什么名字、做什么用、接受什么参数、参数是什么类型"。手写这些描述容易出错且与代码不同步。这个文件利用 Python 的**内省 (introspection)** 能力自动从函数源码中提取这些信息。

#### 2.2.1 背景知识: Python 的类型注解

```python
def listDirectory(targetPath: str, maxResults: int = 100) -> list[FileInfo]:
    """列出目录内容"""
    ...
```

这里 `targetPath: str` 就是**类型注解** (type annotation)。Python 3.10+ 允许用这些注解表达复杂类型：`list[FileInfo]` 表示"FileInfo 对象构成的一个列表"，`int | None` 表示"整数或空值"。

类型注解在运行时**不影响程序行为**，但它们可以被 `inspect` 和 `typing` 模块读取，这正是 `schemas.py` 要做的事。

#### 2.2.2 基础类型映射表 (第 6-7 行)

```python
_PRIMITIVE_MAP = {
    str:  {"type": "string"},
    int:  {"type": "integer"},
    float:{"type": "number"},
    bool: {"type": "boolean"},
}
```

这是 Python 基本类型到 JSON Schema 类型的直译表。例如：如果一个参数的注解是 `str`，就生成 `{"type": "string"}`。

#### 2.2.3 `annotationToJsonSchema` — 核心转换函数

这个函数接受任意 Python 类型注解，返回对应的 JSON Schema dict。它按优先级处理 6 种类型：

```python
def annotationToJsonSchema(annotation) -> dict:

    # 第1优先级: str/int/float/bool → 查表直接返回
    if annotation in _PRIMITIVE_MAP:
        return dict(_PRIMITIVE_MAP[annotation])

    # 第2优先级: Enum 子类 → 列出所有合法值
    # 例如: class Color(str, Enum): RED="red", BLUE="blue"
    #       → {"type": "string", "enum": ["red", "blue"]}
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        return {"type": "string", "enum": [m.value for m in annotation]}

    # 第3优先级: list 或 list[Something]
    # list        → {"type": "array", "items": {"type": "string"}}
    # list[int]   → {"type": "array", "items": {"type": "integer"}}
    # 递归: 通过 get_origin + get_args 获取泛型参数
    origin = get_origin(annotation)    # list[FileInfo] → 提取 list
    args   = get_args(annotation)      # list[FileInfo] → 提取 (FileInfo,)
    if origin is list:
        if args:
            item = annotationToJsonSchema(args[0])  # 递归处理 FileInfo
        return {"type": "array", "items": item}

    # 第4优先级: Optional[X] 即 X | None
    # X | None → 取 X 的 schema（去掉 None）
    # 兼容 Python 3.10 的 types.UnionType 和旧版 typing.Union
    if isUnion and args:
        nonNone = [a for a in args if a is not type(None)]
        if nonNone:
            return annotationToJsonSchema(nonNone[0])

    # 第5优先级: 兜底 → 当 string 处理
    return {"type": "string"}
```

**关键 Python 函数解释**：

| 函数 | 输入 | 输出 | 作用 |
|------|------|------|------|
| `get_origin(list[int])` | `list[int]` | `list` | 提取泛型的外层类型 |
| `get_args(list[int])` | `list[int]` | `(int,)` | 提取泛型的类型参数 |
| `issubclass(Color, Enum)` | Color 类 | `True` | 判断一个类是不是另一个类的子类 |
| `isinstance(Color, type)` | Color 类 | `True` | 判断一个对象是不是"类型本身"（和实例区分） |

**为什么需要 `types.UnionType` 和 `typing.Union` 两种判断**：
- Python 3.10+ 中 `str | None` 的内部类型是 `types.UnionType`
- 旧代码可能用 `typing.Union[str, None]`，内部类型是 `typing.Union`
- 两者语义相同但内部表示不同，所以需要同时检查

#### 2.2.4 `functionToToolSchema` — 生成 OpenAI Function Calling 格式的工具描述

```python
def functionToToolSchema(func) -> dict:

    # Step 1: 用 inspect.signature(func) 获取函数签名
    sig = inspect.signature(func)
    # 例如: (targetPath: str, maxResults: int = 100) -> list[FileInfo]

    props = {}     # 存放每个参数的 JSON Schema 类型
    required = []  # 存放没有默认值的参数名 (即为必填)

    # Step 2: 遍历每个参数
    for name, param in sig.parameters.items():
        if name == "self":          # 跳过类方法的 self
            continue
        props[name] = annotationToJsonSchema(param.annotation)
        if param.default is inspect.Parameter.empty:  # 无默认值 = 必填
            required.append(name)

    # Step 3: 组装成 OpenAI Function Calling 的嵌套格式
    return {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": (func.__doc__ or "").strip().split("\n")[0],  # 取文档字符串第一行
            "parameters": {
                "type": "object",
                "properties": props,
                "required": required,
            }
        }
    }
```

**实际转换示例**：

输入函数：
```python
def listDirectory(targetPath: str) -> list[FileInfo]:
    """列出目录内容"""
    ...
```

输出 JSON Schema:
```json
{
  "type": "function",
  "function": {
    "name": "listDirectory",
    "description": "列出目录内容",
    "parameters": {
      "type": "object",
      "properties": {
        "targetPath": {"type": "string"}
      },
      "required": ["targetPath"]
    }
  }
}
```

这个 JSON Schema 就是发送给 LLM 的工具描述。LLM 读完后就知道：有个叫 `listDirectory` 的工具，需要一个叫 `targetPath` 的 string 参数，可以列出目录内容。

---

### 2.3 `server/registry.py` — 工具注册中心

**文件职责**：维护一个"哪些工具可用"的登记表。这个类有四个核心功能：

1. **登记工具** (`register`)：把一个 Python 函数签入白名单
2. **列出工具** (`listTools`)：返回所有已注册工具的描述（按名字排序）
3. **查找工具** (`getTool`)：按名字找对应的函数
4. **查询风险** (`getRiskLevel`)：返回某工具的风险等级

#### 2.3.1 数据结构

```python
class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Callable] = {}       # {"getCpuInfo": <function>, ...}
        self._riskLevels: dict[str, ToolRiskLevel] = {}  # {"getCpuInfo": READ_ONLY, ...}
```

两个字典，以函数名为键：
- `_tools` 存实际的函数对象，调用时用 `括号()` 执行
- `_riskLevels` 存风险等级，供 Safety 模块查询

`Callable` 是"可调用对象"的泛称，包括普通函数、类方法、lambda 等。

#### 2.3.2 关键实现细节

```python
def register(self, func, riskLevel=ToolRiskLevel.WRITE):
    self._tools[func.__name__] = func          # 用函数的名字作为键
    self._riskLevels[func.__name__] = riskLevel
```

这里的 `func.__name__` 是 Python 函数对象的内部属性，保存定义时的函数名。例如 `getCpuInfo.__name__` 就是 `"getCpuInfo"`。

```python
def listTools(self) -> list[dict]:
    schemas = [functionToToolSchema(f) for f in self._tools.values()]
    schemas.sort(key=lambda s: s["function"]["name"])  # 按名字字母序排列
    return schemas
```

**为什么按字母序排列**：这是 KV Cache 优化的关键。LLM 推理服务会对 Prompt 的前缀做缓存——如果两次请求的 Prompt 开头完全相同，可以复用第一次的计算结果。如果工具列表按字母序排列，不管工具的注册顺序如何，生成的 Prompt 前缀始终一致，缓存命中率更高。

#### 2.3.3 使用示例

```python
reg = ToolRegistry()
reg.register(getCpuInfo, ToolRiskLevel.READ_ONLY)   # 只读 → 自动放行
reg.register(deleteFile, ToolRiskLevel.DANGEROUS)    # 危险 → 需审批

# 获取 LLM 可用的工具列表
llm_tools = reg.listTools()  # [{"type":"function","function":{"name":"deleteFile",...}}, ...]

# 获取风险等级
reg.getRiskLevel("deleteFile")  # ToolRiskLevel.DANGEROUS

# 查找函数
func = reg.getTool("getCpuInfo")  # <function getCpuInfo at 0x...>
```

---

### 2.4 `server/dispatcher.py` — JSON-RPC 请求分发器

**文件职责**：整个 MCP 模块的"前台接线员"。它接收原始的 JSON-RPC 字符串，判断是哪个方法，调用对应的处理函数，最后把结果打包成 JSON-RPC 格式返回。

#### 2.4.1 请求路由的核心逻辑

```python
def handle(self, raw: str) -> str:
    # Step 1: 解析 JSON-RPC 字符串 → JsonRpcRequest 对象
    req = decodeRequest(raw)

    # Step 2: 根据 method 名找到对应的 _handle_xxx 方法
    # 例如: method="tools/call" → 查找 self._handle_tools_call
    try:
        h = getattr(self, f"_handle_{req.method.replace('/', '_')}", None)
        if h is None:
            return encodeError(req.id, METHOD_NOT_FOUND, f"未知方法: {req.method}")

        # Step 3: 调用处理方法，得到结果
        result = h(req.params)

        # Step 4: 包装成 JSON-RPC 成功响应
        return encodeResult(req.id, result)

    except Exception as exc:
        # Step 5: 任何异常包装成 JSON-RPC 错误响应
        return encodeError(req.id, INTERNAL_ERROR, str(exc))
```

**路由表解析**：

| MCP 方法名 | 替换后 | 对应处理方法 |
|-----------|--------|-------------|
| `initialize` | `_handle_initialize` | 返回 server 信息 |
| `tools/list` | `_handle_tools_list` | 返回已注册工具列表 |
| `tools/call` | `_handle_tools_call` | 执行指定工具 |
| `ping` | `_handle_ping` | 返回空对象 |
| 任意其他方法 | — | 返回 METHOD_NOT_FOUND 错误 |

`getattr(obj, "name", default)` 是 Python 的通用属性访问方法：`obj.name` 等价于 `getattr(obj, "name")`。如果属性不存在返回 `default` 而不是报 AttributeError。

`req.method.replace('/', '_')` 把斜杠替换成下划线，因为方法名中不能包含 `/`：`"tools/call"` → `"tools_call"` → `_handle_tools_call`。

#### 2.4.2 `_handle_tools_call` — 工具执行

```python
def _handle_tools_call(self, params: dict) -> dict:
    name = params.get("name", "")
    args = params.get("arguments", {})
    func = self._reg.getTool(name)
    if func is None:
        raise ValueError(f"工具未注册: {name}")

    result = func(**args)              # 关键: 用 ** 把 dict 展开为关键字参数调用

    # 结果序列化: 根据返回类型选择不同的处理方式
    if hasattr(result, "__dataclass_fields__"):          # 返回 dataclass 实例
        output = json.dumps(dataclasses.asdict(result), ...)
    elif isinstance(result, list) and result \            # 返回 dataclass 列表
         and hasattr(result[0], "__dataclass_fields__"):
        output = json.dumps([dataclasses.asdict(r) for r in result], ...)
    else:                                                # 返回 dict 或其他
        output = json.dumps(result, ...)

    # 返回 MCP 标准格式: content 数组包含一个 text block
    return {"content": [{"type": "text", "text": output}], "isError": False}
```

**`**args` 展开运算符**：

```python
args = {"targetPath": "/home", "maxResults": 10}
func(**args)
# ↑ 等价于 ↓
func(targetPath="/home", maxResults=10)
```

**为什么需要三种序列化分支**：

```python
# 分支1: 返回 dataclass (如 CpuInfo)
getCpuInfo()  →  CpuInfo(modelName="Intel", coreCount=8, ...)
# 处理: dataclasses.asdict() → json.dumps()

# 分支2: 返回 dataclass 列表 (如 list[FileInfo])
listDirectory("/tmp")  →  [FileInfo(name="a.txt", ...), FileInfo(name="b.txt", ...)]
# 处理: [dataclasses.asdict(r) for r in result] → json.dumps()

# 分支3: 返回普通 dict
getUptime()  →  {"uptime_seconds": 12345, "uptime_formatted": "..."}
# 处理: 直接用 json.dumps(result)
```

`hasattr(obj, "__dataclass_fields__")` 是判断一个对象是否是 dataclass 实例的标准做法——`__dataclass_fields__` 属性是 `@dataclass` 装饰器自动创建的。

#### 2.4.3 MCP 工具结果的标准格式

MCP 规范要求 `tools/call` 的返回值必须是：

```json
{
  "content": [
    {"type": "text", "text": "结果文本"}
  ],
  "isError": false
}
```

`content` 是一个数组，可以包含多个 block（text、image、resource 等）。本项目目前只支持 text 类型。`isError: false` 表示工具执行成功（不是协议错误）。

---

### 2.5 `transports/stdio.py` — 标准输入输出传输层

**文件职责**：让 MCP 模块可以作为独立进程运行，通过 stdin/stdout 接收和发送 JSON-RPC 消息。

**但与当前实现的关系**：当前项目是作为 Python 包被后端导入，**不走 stdio 传输**。AgentCore 直接调用 `dispatcher.handle()`（函数调用，不经过文本）。这个文件是为 MCP 独立部署模式预留的——比如将来可以让 agent 作为一个独立子进程被其他系统调用。

```python
Handler = Callable[[str], str]

def stdioServe(handler: Handler) -> None:
    for line in sys.stdin:         # 逐行从标准输入读取
        line = line.strip()
        if not line:               # 跳过空行
            continue
        response = handler(line)   # 交由分发器处理
        sys.stdout.write(response + "\n")
        sys.stdout.flush()         # 立即输出，不缓冲
```

---

## 3. 完整执行流程演示

下面跟踪一次完整的 `tools/call getCpuInfo` 请求的全路径：

```
[调用方: AgentCore._executeTool()]
  │
  │  # Step 1: 构造 JSON-RPC 请求字符串
  │  mcpReq = encodeRequest("tools/call",
  │              {"name": "getCpuInfo", "arguments": {}})
  │
  │  mcpReq = '{"jsonrpc":"2.0","method":"tools/call",'
  │           '"params":{"name":"getCpuInfo","arguments":{}}}'
  │
  ├──→ dispatcher.handle(mcpReq)
  │
  │     # Step 2: 解析 JSON-RPC 请求
  │     req = decodeRequest(mcpReq)
  │     # req.method = "tools/call"
  │     # req.params = {"name":"getCpuInfo","arguments":{}}
  │
  │     # Step 3: 路由到处理方法
  │     h = getattr(self, "_handle_tools_call")
  │     result = h({"name":"getCpuInfo","arguments":{}})
  │
  │     ┌─────────────────────────────────────────────────┐
  │     │ _handle_tools_call(params):                     │
  │     │                                                 │
  │     │ name = "getCpuInfo"                             │
  │     │ args = {}                                       │
  │     │ func = registry.getTool("getCpuInfo")            │
  │     │ # func = <function getCpuInfo at 0x7f...>      │
  │     │                                                 │
  │     │ result = func()   # 等价于 plugins.os_observe.getCpuInfo()
  │     │                                  │               │
  │     │    ┌─────────────────────────────┘               │
  │     │    ▼                                            │
  │     │  [os_observe.getCpuInfo()]                      │
  │     │    │                                            │
  │     │    ├─ 读 /proc/cpuinfo → modelName, coreCount   │
  │     │    ├─ 读 /proc/stat (两次, 间隔 0.5s) → usage    │
  │     │    ├─ 读 /proc/loadavg → load1/5/15             │
  │     │    └─ return CpuInfo(                           │
  │     │         modelName="Intel(R) Core(TM) i7-...",   │
  │     │         coreCount=8, usagePercent=23.5,         │
  │     │         load1Min=1.2, load5Min=0.9,             │
  │     │         load15Min=0.7                            │
  │     │       )                                         │
  │     │                                                 │
  │     │ # 检测到是 dataclass，用 asdict 转换              │
  │     │ output = json.dumps(asdict(result), ...)        │
  │     │ # output = '{"modelName": "Intel...",           │
  │     │ #            "coreCount": 8, ...}'               │
  │     │                                                 │
  │     │ return {"content": [{"type":"text",             │
  │     │          "text": output}], "isError": False}    │
  │     └─────────────────────────────────────────────────┘
  │
  │     # Step 4: 包装为 JSON-RPC 成功响应
  │     return encodeResult(None, result)
  │     # → '{"jsonrpc":"2.0","id":null,"result":{...}}'
  │
  ├── 返回给 AgentCore
  │
  │  # Step 5: 解析响应，提取工具输出文本
  │  data = json.loads(raw)
  │  content = data["result"]["content"][0]["text"]
  │  # content = '{"modelName": "Intel...", "coreCount": 8, ...}'
  │
  │  # Step 6: 注入 LLM 的 messages，供下一轮推理使用
  │  messages.append({
  │      "role": "tool",
  │      "tool_call_id": tc_id,
  │      "content": content[:4000],   # 安全截断
  │  })
```

---

## 4. 与设计文档的对比分析

### 4.1 设计文档 (Design-2 §4.2.9) 中的 MCP 架构

```
MCP
├─ protocol/
│  ├─ json_rpc/        ✅ 已实现 — json_rpc.py
│  ├─ lifecycle/       ❌ 未独立 — initialize 硬编码在 dispatcher 中
│  ├─ errors/          ❌ 未独立 — 错误码常量混在 json_rpc.py 中
│  └─ schemas/         ✅ 已实现 — schemas.py
├─ transports/
│  ├─ stdio/           ✅ 已实现 — stdio.py
│  └─ streamable_http/ ❌ 未实现
├─ server/
│  ├─ tool_registry/   ✅ 已实现 — registry.py
│  ├─ tool_dispatcher/ ✅ 已实现 — dispatcher.py
│  └─ approval_bridge/ ❌ 未实现
└─ client/
   ├─ stdio_client/    ❌ 未实现
   └─ http_client/     ❌ 未实现
```

### 4.2 各 Gap 的实际影响

#### 4.2.1 `lifecycle/` 未独立 — 影响：低

**设计**：独立的 lifecycle 模块专门管理 MCP 协议的初始化握手流程（initialize → initialized → 可正常通信）。

**现状**：`_handle_initialize` 硬编码在 dispatcher 中，没有状态管理（比如检测是否已经初始化过、是否不允许在未初始化时调用 tools/list）。

```python
# 当前实现: 任何人都可以在任何时间调 initialize
def _handle_initialize(self, params):
    return {"protocolVersion": "2024-11-05", ...}
# 缺少: 是否有 _initialized 状态标记? 是否拒绝了不按顺序的请求?
```

**当前无影响的原因**：本项目不是作为独立 MCP Server 运行，而是作为 Python 包被导入。AgentSession 初始化时就完成了所有组件装配，不存在"未初始化就收到 tools/call"的问题。**但如果将来想用 stdio 对外暴露为独立 MCP Server，就需要这个模块。**

#### 4.2.2 `errors/` 未独立 — 影响：低

**设计**：独立的 error 模块管理所有标准 MCP 错误码和错误消息模板。

**现状**：4 个错误码常量 (`PARSE_ERROR`, `METHOD_NOT_FOUND` 等) 定义在 `json_rpc.py` 顶部，简单粗暴。缺少 MCP 规范中更细粒度的错误码（如 `-32000` 服务定义错误、`-32001` 缺少能力等）。

**当前无影响的原因**：调度器只用到了 `METHOD_NOT_FOUND` 和 `INTERNAL_ERROR` 两个错误码，目前够用。

#### 4.2.3 `streamable_http/` 未实现 — 影响：中低

**设计**：支持通过 HTTP + SSE 作为 MCP 传输方式（除了 stdio 之外），允许远程调用 MCP Server。

**现状**：只有 stdio 传输层。AgentCore 是直接函数调用 `dispatcher.handle()`，不经过任何传输层。

**什么场景需要它**：当 Agent 内核和一个远程 MCP Server（比如第三方提供的运维工具服务）通信时。当前所有工具都是本地 Python 函数，不需要远程调用。

#### 4.2.4 `approval_bridge/` 未实现 — 影响：中

**设计**：当 Safety 模块返回 `REQUIRE_CONFIRM` 时，approval_bridge 负责暂停 MCP 执行、向上层发出审批请求、等待用户决策、然后继续或拒绝执行。

**现状**：dispatcher 的 `_handle_tools_call` 直接执行工具，没有审批暂停机制。审批逻辑写在 dispatcher 的上游（AgentCore 的 `run()` 方法中），但有一个 bug（`APPROVAL_REQUIRED` 事件发出后，工具仍然被无条件执行）。

**具体差异**：

```
设计中的流程:                        当前实现的流程:

LLM → tools/call                    LLM → tools/call
  ↓                                   ↓
Safety: 校验                         Safety: 校验  
  ↓                                   ↓
MCP → approval_bridge.await()       AgentCore: emit(APPROVAL_REQUIRED)
  ║                                   ↓  (不等待)
  ║ (暂停，等用户决定)                MCP → 直接执行工具 ← BUG
  ║
  ↓ (用户批准/拒绝)
MCP → 执行或拒绝
```

#### 4.2.5 `client/` 完全未实现 — 影响：低（当前阶段）

**设计**：MCP Client 可以连接外部 MCP Server，允许本 Agent 调用其他 MCP 兼容的工具服务。

**现状**：完全不存在。所有工具都在本地注册。

**什么场景需要它**：如果将来想让 Agent 调用第三方提供的 MCP 工具（比如远程监控平台暴露的查询接口），就需要 Client。当前只实现了一个闭环的 Server 端。

### 4.3 架构层面的根本区别

设计文档中的 MCP 定位是**协议引擎**——它假定 MCP 是整个系统的通信骨架，所有工具调用都走 MCP 协议。但当前实现中，MCP 更像一个**函数调用适配层**：

```
设计中的 MCP:                          当前实现的 MCP:

外部系统 (CLI, HTTP)                   AgentCore (asyncio 协程)
  │ JSON-RPC 消息                       │ 函数调用 (不经过传输层)
  ▼                                     ▼
MCP Transport Layer                   McpDispatcher.handle(raw_str)
  │                                     │
  ▼                                     ▼
MCP Server ↔ Lifecycle                _handle_tools_call
  │                                     │
  ▼                                     ▼
Tool Registry → Plugin → OS           func → Plugin → OS
```

**关键差异**：
1. **设计假设了一个传输层** (stdio / HTTP)，当前实现绕过了它
2. **设计有完整的生命周期管理**，当前只在 dispatcher 初始化时一次性装配
3. **设计中的 Safety 和 MCP 是分开的**，当前 Safety 在 AgentCore 层（dispatcher 上游），dispatcher 本身不做安全检查

### 4.4 对比总结

| 维度 | 设计 (Design-2) | 实现 | 差距评估 |
|------|:---:|:---:|:--:|
| JSON-RPC 编解码 | `protocol/json_rpc/` | `json_rpc.py` 完整 | ✅ 一致 |
| 工具 Schema 生成 | `protocol/schemas/` | `schemas.py` 完整 | ✅ 一致 |
| 工具注册 | `server/tool_registry/` | `registry.py` 完整 | ✅ 一致 |
| 工具分发 | `server/tool_dispatcher/` | `dispatcher.py` 完整 | ✅ 一致 |
| stdio 传输 | `transports/stdio/` | `stdio.py` 完整 | ✅ 一致 |
| 生命周期管理 | `protocol/lifecycle/` | 无(硬编码在 dispatcher) | ⚠️ 简化为无状态 |
| 标准错误码 | `protocol/errors/` | 无(常量在 json_rpc.py) | ⚠️ 简化 |
| HTTP 传输 | `transports/streamable_http/` | 无 | ❌ 缺失 |
| 审批桥接 | `server/approval_bridge/` | 无(在 AgentCore 层) | ❌ 缺失 |
| MCP Client | `client/` | 无 | ❌ 缺失 |

---

## 5. 当前 MCP 模块的数据流全图

```
                 ┌───────────────────────────────────────┐
                 │         AgentSession.__init__          │
                 │                                       │
                 │  registry = ToolRegistry()            │
                 │  registry.register(getCpuInfo, R)     │← 注册 7 个工具
                 │  registry.register(deleteFile, D)     │  到 registry
                 │  ...                                  │
                 │                                       │
                 │  dispatcher = McpDispatcher(registry) │← 分发器持有 registry
                 │  promptBuilder = PromptBuilder(       │
                 │      ..., registry.listTools()         │← 工具列表→ LLM 描述
                 │  )                                    │
                 │                                       │
                 │  agentCore = AgentCore(               │
                 │      ..., registry, dispatcher, ...   │← 注入到 AgentCore
                 │  )                                    │
                 └───────────────────────────────────────┘

                 ┌───────────────────────────────────────┐
                 │        AgentCore.run() 循环内          │
                 │                                       │
                 │  1. LLM 返回 tool_calls                │
                 │  2. registry.getRiskLevel(name)       │← 查询风险
                 │  3. safety.checkToolCall(name,risk)   │← 安全校验
                 │  4. [ALLOW] →                         │
                 │     mcpReq = encodeRequest(           │← 构造 JSON-RPC
                 │         "tools/call",                  │   请求字符串
                 │         {"name":...,"arguments":...}) │
                 │     raw = dispatcher.handle(mcpReq)   │← === 进入 MCP 模块 ===
                 │                                       │
                 │     ┌─────────────────────────┐       │
                 │     │ dispatcher.handle():    │       │
                 │     │  req = decodeRequest()  │       │← 解析请求
                 │     │  handler = getattr(     │       │← 路由到处理方法
                 │     │    self, "_handle_      │       │
                 │     │    tools_call")         │       │
                 │     │  result = handler()     │       │← 调用 _handle_tools_call
                 │     │  return encodeResult()  │       │← 包装响应
                 │     └─────────┬───────────────┘       │
                 │               │                       │
                 │     ┌─────────▼───────────────┐       │
                 │     │ _handle_tools_call():   │       │
                 │     │  func = registry.getTool│       │← 查找函数
                 │     │  result = func(**args)  │       │← === 执行真实函数 ===
                 │     │  output = json.dumps(   │       │← 序列化结果
                 │     │    asdict(result))      │       │
                 │     │  return {"content":     │       │← MCP 标准格式
                 │     │    [{"type":"text",     │       │
                 │     │      "text":output}]}   │       │
                 │     └─────────────────────────┘       │
                 │                                       │
                 │  5. 解析 raw → 提取工具输出文本        │
                 │  6. messages.append(tool_msg)          │← 注入 LLM 上下文
                 │  7. 回到 THINKING 状态继续循环          │
                 └───────────────────────────────────────┘
```

---

## 6. 附录：MCP 模块中使用的 Python 技巧速查

| 技巧 | 出现位置 | 作用 |
|------|----------|------|
| `@dataclass` | `json_rpc.py:JsonRpcRequest` | 自动生成 `__init__/__repr__/__eq__`，减少样板代码 |
| `field(default_factory=dict)` | `json_rpc.py:JsonRpcRequest.params` | 为可变默认值 (dict/list) 提供正确的默认工厂 |
| `getattr(obj, name, default)` | `dispatcher.py:19` | 动态获取对象属性，不存在时返回默认值而非抛出异常 |
| `func(**args)` 关键字展开 | `dispatcher.py:42` | 把 dict 展开为函数的关键字参数 |
| `func.__name__` | `registry.py:13`, `schemas.py:42` | 获取函数定义时的名称字符串 |
| `func.__doc__` | `schemas.py:43` | 获取函数的文档字符串 (docstring) |
| `inspect.signature()` | `schemas.py:32` | 反射获取函数的完整参数签名 |
| `typing.get_origin()` / `get_args()` | `schemas.py:14-15` | 提取泛型类型的外层容器和类型参数 |
| `hasattr(obj, "__dataclass_fields__")` | `dispatcher.py:43` | 运行时判断对象是否是 dataclass 实例 |
| `dataclasses.asdict()` | `dispatcher.py:45` | 递归转换 dataclass 为普通字典 |
| `json.dumps(ensure_ascii=False)` | 多处 | 保留 UTF-8 中文字符，不转义为 `\uXXXX` |
