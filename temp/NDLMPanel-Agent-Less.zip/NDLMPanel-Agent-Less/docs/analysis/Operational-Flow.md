---
type: reference
status: complete
created: 2026-05-27
updated: 2026-05-27
tags:
  - operational-flow
  - architecture
---

# NDLMPanel-Agent 运作流程详解

[[Design-1]] [[Design-2]] [[Skeleton-Design]] [[Gap-Analysis]]

---

## 0. 整体架构回顾

```
backend (FastAPI / Flask / etc.)
  └── AgentSession.submit(message) → AsyncIterator[AgentEvent]
       └── AgentCore.run()  [asyncio 状态机 ReAct 循环]
            ├── checkPromptInjection()
            ├── PromptBuilder.build()  → 4层 KV-Cache 优化 Prompt
            ├── LLMProvider.chat()    → OpenAI-compat API (urllib)
            ├── RuleEngine.checkToolCall() → 安全校验
            ├── McpDispatcher.handle(tools/call) → 工具分发
            │    └── plugins/*  [纯 /proc + subprocess]
            └── TraceRecorder.record() → JSONL + SQLite + SHA-256 哈希链
```

---

## 1. 完整请求生命周期

### 1.1 流程图

```
POST /api/chat {"message": "帮我查看系统 CPU 使用率"}
  │
  ▼
┌─────────────────────────────────────────────────────────────┐
│ AgentSession.submit(message)                                │
│                                                             │
│  1. 创建 EventStream(sessionId)    → asyncio.Queue 事件队列 │
│  2. emit(SESSION_CREATED)                                   │
│  3. record trace: session.created                           │
│  4. asyncio.create_task(AgentCore.run())                    │
│  5. async for event in stream: yield event                  │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│ AgentCore.run(userMessage, stream, systemInfo, history)     │
│                                                             │
│  STATE: IDLE → THINKING → EXECUTING → THINKING → ... → DONE│
│                                                             │
│  Step 1: checkPromptInjection(message)                      │
│          ├─ 命中  → emit(ERROR) → DONE                      │
│          └─ 安全  → 继续                                    │
│                                                             │
│  Step 2: PromptBuilder.build(message, sysinfo, history)     │
│          ├─ L1 静态: System Prompt + Tools + Safety Rules   │
│          ├─ L2 半静态: Policy Profile + Skills              │
│          ├─ L3 会话: OS Snapshot + 对话历史                  │
│          └─ L4 当前: 用户消息                                │
│                                                             │
│  Step 3: [LOOP START] round=1..maxRounds                    │
│          ├─ THINKING:                                       │
│          │   ├─ llm.chat(messages) → LLMResponse             │
│          │   ├─ [纯文本] → emit(TEXT_DELTA) → DONE           │
│          │   └─ [工具调用] → 进入 EXECUTING                   │
│          │                                                  │
│          └─ EXECUTING:                                      │
│              for each tool_call in response.tool_calls:     │
│                ├─ registry.getRiskLevel(name)                │
│                ├─ safety.checkToolCallWithReason(name, risk)│
│                ├─ emit(SAFETY_CHECKED)                       │
│                ├─ [ALLOW] → dispatcher.handle(tools/call)    │
│                ├─ [BLOCK] → emit(ERROR)                      │
│                ├─ [REQUIRE_CONFIRM] → emit(APPROVAL_REQUIRED)│
│                │       → 执行工具（BUG: 应等待 approve）      │
│                ├─ emit(TOOL_RESULT)                          │
│                └─ 结果追加到 messages                        │
│              → 回到 THINKING                                 │
│                                                             │
│  Step 4: emit(DONE)                                         │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 时序图

```
User          Backend       AgentSession    AgentCore      LLMProvider    Safety         MCP/Plugin     Linux OS
 │               │               │               │               │             │               │               │
 │ POST /chat    │               │               │               │             │               │               │
 ├──────────────>│               │               │               │             │               │               │
 │               │ submit(msg)   │               │               │             │               │               │
 │               ├──────────────>│               │               │             │               │               │
 │               │               │ create_task() │               │             │               │               │
 │               │               ├──────────────>│               │             │               │               │
 │               │               │               │ checkInjection│             │               │               │
 │               │               │               │ (no LLM call) │             │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ build(messages)              │               │               │
 │               │               │               │──────┐        │             │               │               │
 │               │               │               │      │ L1+L2+L3+L4            │               │               │
 │               │               │               │<─────┘        │             │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ chat(msgs)    │             │               │               │
 │               │               │               ├──────────────>│             │               │               │
 │               │               │               │               │ HTTP POST   │               │               │
 │               │               │               │               │ /chat/comp..│               │               │
 │               │               │               │               │─────────    │               │               │
 │               │               │               │               │<────────    │               │               │
 │               │               │               │ LLMResponse   │             │               │               │
 │               │               │               │<──────────────┤             │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ [has tool_calls]              │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ for each TC:  │             │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ checkToolCall │             │               │               │
 │               │               │               ├──────────────>│             │               │               │
 │               │               │               │ verdict,reason│             │               │               │
 │               │               │               │<──────────────┤             │               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ [ALLOW] → tools/call         │               │               │
 │               │               │               ├──────────────────────────────>│               │               │
 │               │               │               │               │             │ subprocess    │               │
 │               │               │               │               │             ├──────────────>│               │
 │               │               │               │               │             │ output        │               │
 │               │               │               │               │             │<──────────────┤               │
 │               │               │               │ tool_result   │             │               │               │
 │               │               │               │<──────────────────────────────┤               │               │
 │               │               │               │               │             │               │               │
 │               │               │               │ [append result to messages → loop back to THINKING]     │
 │               │               │               │               │             │               │               │
 │               │               │               │ [最终: text_response → emit TEXT_DELTA]                 │
 │               │               │               │               │             │               │               │
 │               │               │ emit(TEXT_DELTA)              │             │               │               │
 │               │<──────────────┤               │               │             │               │               │
 │               │ yield SSE     │               │               │             │               │               │
 │<──────────────┤               │               │               │             │               │               │
 │               │               │ emit(DONE)    │               │             │               │               │
 │               │<──────────────┤               │               │             │               │               │
 │               │ yield [DONE]  │               │               │             │               │               │
 │<──────────────┤               │               │               │             │               │               │
```

---

## 2. 各层详细流程

### 2.1 Config 加载（应用启动时）

```
环境变量 NDLM_LLM_API_KEY, NDLM_LLM_ENDPOINT ...
    │
    ▼
loadConfig("conf/profiles/development.json")
    │
    ├── 读取 JSON 文件                      → dict
    ├── _deepMerge(BUILTIN_DEFAULTS, file)  → merged dict
    ├── _loadEnvOverrides()                 → merged dict (覆盖)
    │   ├── NDLM_LLM_ENDPOINT → llm_endpoint
    │   ├── NDLM_LLM_MODEL    → llm_model
    │   ├── NDLM_MAX_TOOL_ROUNDS → int(max_tool_rounds)
    │   └── ...
    ├── mergeConfigs(runtime_overrides)     → merged dict
    ├── AgentConfig(**merged)               → dataclass 实例
    │   └── __post_init__: 校验必填字段
    └── getSecret("llm_api_key", "NDLM_LLM_API_KEY") → config.llm_api_key
```

### 2.2 AgentSession 初始化（每次请求）

```
AgentSession(config, userId, sessionId?)
    │
    ├── gen_session_id()                    → "sess_<12 hex>"
    ├── 加载 Prompt 模板
    │   ├── conf/prompts/system/v1.0.0.txt    → sysPrompt
    │   └── conf/prompts/safety/rules_summary.txt → safetyRules
    │
    ├── ToolRegistry()
    │   ├── register(getCpuInfo,     READ_ONLY)
    │   ├── register(getMemoryInfo,  READ_ONLY)
    │   ├── register(getUptime,      READ_ONLY)
    │   ├── register(getSystemVersion, READ_ONLY)
    │   ├── register(listDirectory,  READ_ONLY)
    │   ├── register(createDirectory, WRITE)
    │   └── register(deleteFile,     DANGEROUS)
    │
    ├── RuleEngine()
    ├── McpDispatcher(registry)
    ├── PromptBuilder(sysPrompt, safetyRules, registry.listTools())
    │
    ├── OpenAIProvider(endpoint, apiKey, model, maxTokens)
    │   └── 或 MockProvider (当无 apiKey 时)
    │
    ├── TraceRecorder(dbPath)
    └── AgentCore(llm, registry, dispatcher, safety, promptBuilder, maxRounds)
```

### 2.3 Prompt 组装（PromptBuilder）

```
PromptBuilder.build(userMessage, systemInfo, conversationHistory, policyProfile)
    │
    ├── messages[0]: system  ───────────────────── L1 静态前缀
    │   ├── System Prompt (conf/prompts/system/v1.0.0.txt)
    │   ├── 工具定义 (字母序排列，canonical_json 序列化)
    │   └── 安全规则 (conf/prompts/safety/rules_summary.txt)
    │
    ├── messages[1]: system  ───────────────────── L2 半静态层
    │   └── Policy Profile (canonical_json 序列化)
    │
    ├── messages[2]: system  ───────────────────── L3 会话上下文
    │   └── OS Snapshot (CPU/Mem/Disk/Proc/Net/Uptime)
    │
    ├── messages[3..N]: (conversationHistory) ──── L3 对话历史
    │   ├── {"role": "user", "content": "之前的消息"}
    │   ├── {"role": "assistant", "content": null, "tool_calls": [...]}
    │   └── {"role": "tool", "tool_call_id": "...", "content": "..."}
    │
    └── messages[N+1]: user ────────────────────── L4 当前请求
        └── 用户当前消息
```

### 2.4 LLM 调用链

```
AgentCore.run() → LLMProvider.chat(messages)
    │
    ├── OpenAIProvider.chat()
    │   ├── json.dumps({"model": ..., "messages": ..., "stream": false})
    │   ├── urllib.request.Request(POST /chat/completions)
    │   │   ├── Content-Type: application/json
    │   │   └── Authorization: Bearer <api_key>
    │   ├── urllib.request.urlopen(req, timeout=120)
    │   └── _parseResponse(raw_json)
    │       ├── json.loads(raw)
    │       ├── choice["message"]["content"] → LLMResponse.content
    │       ├── choice["message"]["tool_calls"] → LLMResponse.tool_calls
    │       └── choice["finish_reason"] → LLMResponse.finish_reason
    │
    └── MockProvider.chat()
        └── 返回预设响应序列中的下一个
```

### 2.5 安全校验链

```
RuleEngine.checkToolCallWithReason(toolName, riskLevel, arguments)
    │
    ├── Layer 1: READ_ONLY 快速通道
    │   └── riskLevel == READ_ONLY → (ALLOW, "只读操作，自动放行")
    │
    ├── Layer 2: 高危参数模式匹配
    │   ├── 遍历 arguments 中所有 str 值
    │   ├── 匹配正则模式:
    │   │   ├── /^\/$/       → "操作根目录 / 极其危险"
    │   │   ├── /^\/(etc|boot|usr|lib|sbin|bin|proc|sys)\b/ → "操作系统关键目录"
    │   │   ├── /\.\./       → "路径包含 .. 可能导致目录穿越"
    │   │   ├── /\b777\b/    → "chmod 777 权限过于宽松"
    │   │   ├── /\b000\b/    → "chmod 000 会导致文件不可访问"
    │   │   └── /\b(SIGKILL|9)\b/ → "SIGKILL 无法被进程捕获"
    │   └── 命中 → (REQUIRE_CONFIRM, reason)
    │
    └── Layer 3: DANGEROUS 级别
        └── riskLevel == DANGEROUS → (REQUIRE_CONFIRM, "高危操作需要人工确认")
```

### 2.6 MCP tools/call 执行链

```
McpDispatcher.handle(raw_json_rpc)
    │
    ├── decodeRequest(raw) → JsonRpcRequest(id, method, params)
    ├── method → "_handle_tools_call"
    │
    ├── _handle_tools_call(params)
    │   ├── name = params["name"]     # e.g. "getCpuInfo"
    │   ├── args = params["arguments"] # e.g. {}
    │   ├── func = registry.getTool(name)
    │   ├── result = func(**args)
    │   │   ├── [dataclass] → dataclasses.asdict() → json.dumps()
    │   │   ├── [list[dataclass]] → [dataclasses.asdict()] → json.dumps()
    │   │   └── [dict] → json.dumps()
    │   └── return {"content": [{"type": "text", "text": output}], "isError": false}
    │
    └── encodeResult(id, result) → JSON string
```

### 2.7 Plugin 执行（以 getCpuInfo 为例）

```
getCpuInfo()
    │
    ├── /proc/cpuinfo → model name + processor count
    ├── /proc/stat (两次采样，间隔 0.5s)
    │   ├── cpu  line → total_ticks(t1), idle(t1)
    │   ├── sleep(0.5)
    │   ├── cpu  line → total_ticks(t2), idle(t2)
    │   └── usage = 100 * (1 - (idle2-idle1)/(total2-total1))
    ├── /proc/loadavg → load1, load5, load15
    └── return CpuInfo(modelName, coreCount, usage, load1, load5, load15)
```

### 2.8 审计追踪（TraceLog）

```
TraceRecorder.record(traceId, sessionId, eventType, data)
    │
    ├── sanitize(data) ── 脱敏 API Key/Token/Password
    │
    ├── HashChain.hash(entry)
    │   ├── canonical_json(entry, sort_keys=True)
    │   ├── H_n = SHA256(H_{n-1} || canonical_entry)  [:16]
    │   └── return H_n
    │
    ├── SQLite INSERT
    │   └── traces(trace_id, session_id, event_type,
    │              timestamp, data, entry_hash, prev_hash)
    │
    └── JSONL APPEND
        └── runtime/traces/YYYY-MM-DD.jsonl
            {"timestamp":"...","trace_id":"...","session_id":"...",
             "event":"...","data":{...},"entry_hash":"...","prev_hash":"..."}
```

---

## 3. 事件流协议

### 3.1 AgentEvent → SSE 转换

```
AgentCore                          Backend                         Browser
   │                                  │                                │
   │ emit(THINKING_START, {round:1})  │                                │
   ├─────────────────────────────────>│                                │
   │                                  │ OpenAIAdapter.formatSse()      │
   │                                  │ data: {"type":"thinking.start",│
   │                                  │        "round":1}\n\n          │
   │                                  ├───────────────────────────────>│
   │                                  │                                │
   │ emit(TEXT_DELTA, {content:"CPU"})│                                │
   ├─────────────────────────────────>│                                │
   │                                  │ data: {"type":"text.delta",    │
   │                                  │        "delta":{"content":     │
   │                                  │        "CPU"}}\n\n             │
   │                                  ├───────────────────────────────>│
   │                                  │                                │
   │ emit(DONE)                       │                                │
   ├─────────────────────────────────>│                                │
   │                                  │ data: [DONE]\n\n               │
   │                                  ├───────────────────────────────>│
```

### 3.2 事件类型速查

| EventType | 触发时机 | data 内容 |
|------|------|------|
| `session.created` | AgentSession.submit() 入口 | `{"user_id": "..."}` |
| `thinking.start` | 每轮 LLM 调用前 | `{"round": N}` |
| `thinking.delta` | （预留，未实现） | `{"content": "..."}` |
| `thinking.end` | （预留，未实现） | `{"round": N}` |
| `safety.checked` | 工具调用安全校验后 | `{"tool":"...", "risk":"...", "verdict":"...", "reason":"..."}` |
| `tool.calling` | 工具执行前（AgentCore 未 emit） | `{"name":"...", "arguments":{...}}` |
| `tool.result` | 工具执行后 | `{"call_id":"...", "tool_name":"...", "success":true, "output":"..."}` |
| `approval.required` | 需要人工审批 | `{"tool_name":"...", "arguments":{...}, "action_id":"..."}` |
| `approval.resolved` | （预留，未实现） | `{"action_id":"...", "approved":true}` |
| `text.delta` | LLM 文本输出（每行） | `{"content": "..."}` |
| `text.done` | 文本输出完成 | `{}` |
| `error` | 任何错误 | `{"message": "..."}` |
| `done` | 会话结束 | `{}` |

---

## 4. 与后端对接模式

### 4.1 包导入模式（推荐）

```python
# 后端 app.py
from ndlmpanel_agent import AgentSession
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.compat.api_styles import OpenAIAdapter

config = AgentConfig(llm_endpoint="https://api.deepseek.com/v1")
config.llm_api_key = os.environ["DEEPSEEK_API_KEY"]

@app.post("/api/chat")
async def chat(request: ChatRequest):
    session = AgentSession(config, userId=request.user_id)

    async def generate():
        async for event in session.submit(request.message):
            yield OpenAIAdapter.formatSse(event)

    return StreamingResponse(generate(), media_type="text/event-stream")
```

### 4.2 配置文件模式

```python
session = AgentSession.fromConfigFile(
    "conf/profiles/production.json",
    userId="admin-01"
)
```

---

## 5. 数据流全链路（一次完整请求示例）

以"帮我看看磁盘为什么满了"为例：

```
1. 用户输入到达
   "帮我看看磁盘为什么满了" → AgentSession.submit()

2. 注入检测
   checkPromptInjection(message) → False (通过)

3. Prompt 组装 (PromptBuilder.build)
   messages = [
     {"role": "system", "content": "你是一个专业的智能运维助手...\n## 可用工具\n..."},
     {"role": "system", "content": "## 当前系统信息\n{\"cpu\":{...},\"memory\":{...}}"},
     {"role": "user", "content": "帮我看看磁盘为什么满了"}
   ]

4. LLM 推理 (round 1)
   LLM.chat(messages) → LLMResponse:
     content: null
     tool_calls: [{"id": "tc_abc", "name": "getMemoryInfo", "arguments": {}}]

5. 安全校验
   RuleEngine.checkToolCall("getMemoryInfo", READ_ONLY, {})
   → (ALLOW, "只读操作，自动放行")

6. 工具执行
   McpDispatcher.handle(tools/call getMemoryInfo)
   → getMemoryInfo() → MemoryInfo(totalBytes=..., usedBytes=..., ...)
   → {"content": [{"type":"text", "text":"{\"totalBytes\":...}"}]}

7. 工具结果注入 messages
   messages.append({"role":"tool", "tool_call_id":"tc_abc", "content":"..."})

8. LLM 推理 (round 2)
   LLM.chat(messages) → LLMResponse:
     content: "当前内存使用率为 67%，swap 使用正常。需要进一步分析磁盘使用情况，建议使用 df -h 查看分区使用率..."

9. 流式输出
   emit(TEXT_DELTA: "当前内存使用率为 67%...")
   emit(TEXT_DONE)
   emit(DONE)
```

---

## 6. 附录：运行示例

### 6.1 使用 MockProvider 的离线测试

```python
import asyncio
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.integration.session import AgentSession

config = AgentConfig(llm_endpoint="https://api.test.com")  # 无 api_key → 自动用 MockProvider

async def main():
    session = AgentSession(config)
    async for event in session.submit("测试消息"):
        print(f"[{event.type}] {event.data}")

asyncio.run(main())
```

### 6.2 使用真实 LLM

```bash
export NDLM_LLM_API_KEY="sk-xxx"
python -c "
import asyncio
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.integration.session import AgentSession

async def main():
    session = AgentSession(AgentConfig(llm_endpoint='https://api.deepseek.com/v1'))
    async for ev in session.submit('系统负载怎么样？'):
        if ev.type == 'text.delta':
            print(ev.data['content'], end='', flush=True)

asyncio.run(main())
"
```
