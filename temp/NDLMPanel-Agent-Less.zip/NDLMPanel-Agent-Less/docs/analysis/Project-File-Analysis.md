---
type: reference
status: complete
created: 2026-05-27
updated: 2026-05-27
tags:
  - project-structure
  - module-analysis
  - dependency-graph
---

# NDLMPanel-Agent 项目目录与文件作用完整分析

[[Design-1]] [[Design-2]] [[Skeleton-Design]] [[Gap-Analysis]] [[Operational-Flow]]

---

## 0. 项目概览

```
NDLMPanel-Agent-Less/
├── src/ndlmpanel_agent/      # 源码 — 49 个 .py 文件，12 个模块
├── conf/                     # 配置 — 4 个文件（profiles + prompt 模板）
├── tests/                    # 测试 — 16 个 .py 文件，54 项用例，全部通过
├── runtime/                  # 运行时数据 — logs/traces/sqlite
├── docs/                     # 文档 — 5 个设计文档 + 10 个构建/验证脚本
├── pyproject.toml            # 零外部依赖
├── AGENTS.md                 # 项目上下文文档
└── README.md
```

---

## 一、源码层 `src/ndlmpanel_agent/`（12 个模块，49 个 .py 文件）

### 📦 1.1 `shared/` — 公共类型与工具（6 文件）

整个项目的数据基础层，所有模块的公共类型定义和工具函数均在此。替代了原项目对 pydantic 的依赖，全部基于 Python 3.10+ stdlib 的 `dataclasses` + `enum` + `json`。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `shared/__init__.py` | 41 | 模块入口，统一 re-export 全部公有类型到 `ndlmpanel_agent.shared` 命名空间 | `EventType`, `AgentConfig`, `AgentError`, `canonical_json` 等 |
| `shared/types.py` | 147 | **核心 dataclass 类型定义**。替代原 8 个 pydantic Model 文件。枚举类继承 `(str, Enum)` 保证 JSON 序列化输出字符串值 | `AgentEvent` (事件流基本单元), `ToolDefinition` (工具元信息), `ToolCall` (LLM 发起的调用), `ToolResult` (执行结果含截断标记), `TraceEntry` (审计日志哈希链节点), `LLMResponse` (兼容 OpenAI 格式), `AgentConfig` (运行时配置 + `__post_init__` 校验), `EventType/ToolRiskLevel/SafetyVerdict` 三组枚举, `dataclass_to_dict`, `dict_to_dataclass` |
| `shared/errors.py` | 37 | **统一错误码体系** | `ErrorCode` 枚举：E0001-E5002 共 18 个（通用 E0/配置 E1/LLM E2/安全 E3/工具 E4/执行 E5）。`AgentError` 异常基类带 `code`, `message`, `detail` 字段 |
| `shared/ops_types.py` | 81 | **运维工具返回类型 dataclass 定义**。替代原 `models/ops/` 下的 pydantic models | `CpuInfo`, `MemoryInfo`, `ProcessInfo`, `ProcessKillResult`, `FileInfo`, `FileOperationResult`, `OperationResult`, `ProcessSortBy` 枚举 |
| `shared/serialization.py` | 25 | 序列化工具 | `canonical_json(obj) → str`：确定性 JSON（键排序、紧凑格式），**保证 Prompt 前缀可缓存**。`safe_truncate(text, max_chars) → (str, bool)`：截断文本保首尾 |
| `shared/id_gen.py` | 17 | ID 生成工具 | `gen_session_id()` → `"sess_<12 hex>"`, `gen_trace_id()` → `"trace_<16 hex>"`, `gen_tool_call_id()` → `"tc_<12 hex>"` |

**依赖**：无外部模块依赖，所有文件只依赖 `stdlib`（`dataclasses`, `enum`, `json`, `uuid`, `secrets`, `time`）。

---

### ⚙️ 1.2 `config_envs/` — 配置管理（4 文件）

负责配置加载、校验、合并和密钥管理。**零 pydantic**，使用 dataclass 定义结构 + JSON 文件 + 环境变量覆盖。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `config_envs/__init__.py` | 9 | 模块入口，导出公有 API | `loadConfig`, `mergeConfigs`, `getSecret`, `validateConfig` |
| `config_envs/loader.py` | 92 | **配置加载核心**。合并优先级：内置默认 → JSON 文件 → `NDLM_*` 环境变量 → 运行时 overrides。自动从环境变量注入 API Key | `loadConfig(path?, overrides?) → AgentConfig`, `mergeConfigs(*configs) → dict`。`_ENV_MAP` 映射 8 个环境变量到配置字段，`_INT_FIELDS` 标记需 int 转换的字段 |
| `config_envs/schema.py` | 19 | 配置校验规则 | `validateConfig(config) → list[str]`：检查 endpoint 格式、max_tool_rounds 范围(1-50)、timeout 范围(1-300)、max_tokens 范围(256-131072)、execution_user 非空 |
| `config_envs/secrets.py` | 8 | 密钥管理 | `getSecret(key, envVar?) → str`：从环境变量读取，不直接放 AgentConfig 实例中，运行时从环境变量注入到 `config.llm_api_key` |

**合并优先级**：
```
内置默认 (_BUILTIN)
  → JSON 配置文件 (conf/profiles/development.json)
    → NDLM_* 环境变量 (_ENV_MAP 8 个映射)
      → 运行时 overrides (loadConfig 参数)
        → secrets.getSecret("NDLM_LLM_API_KEY") 注入
```

**依赖**：`shared/types`, `shared/errors`。

---

### 🪵 1.3 `trace_log/` — 审计日志系统（5 文件）

三层日志架构：Python logging → JSONL 文件 → SQLite 索引。每 session 维护独立 SHA-256 哈希链防篡改。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `trace_log/__init__.py` | 1 | 模块入口 | — |
| `trace_log/recorder.py` | 74 | **事件记录器**。双写：JSONL（`runtime/traces/YYYY-MM-DD.jsonl`）+ SQLite + 哈希链。按 session 维护独立 HashChain 实例 | `TraceRecorder.__init__(dbPath, jsonlDir)`, `.record(traceId, sessionId, eventType, data) → entry_hash`, `.query(traceId?, sessionId?, limit) → list[dict]`, `.close()` |
| `trace_log/storage.py` | 67 | **SQLite 存储层** | `TraceStorage`：建表 `traces` (含 trace_id/session_id/event_type/timestamp/data/entry_hash/prev_hash)，3 个索引。`.insert()`, `.query()` |
| `trace_log/hash_chain.py` | 32 | **SHA-256 哈希链** | `HashChain`: 公式 `H₀=SHA256(E₀)`, `Hₙ=SHA256(Hₙ₋₁∥Eₙ)`，截取前 16 位 hex。`.hash(entry) → hex_hash`, `.prevHash` 属性, `.reset()` |
| `trace_log/sanitizer.py` | 32 | **敏感信息脱敏** | `sanitize(data) → dict`：递归脱敏 api_key/apikey/secret/token/password/passwd 字段值为 `***REDACTED***`，正则匹配 `key=value` 格式 |

**三层架构**：
```
Layer 1: Python logging (stdout INFO + file DEBUG JSON Lines)
    → runtime/logs/agent.log
Layer 2: JSONL 事件日志 (审计追踪，每行一个 JSON)
    → runtime/traces/YYYY-MM-DD.jsonl
Layer 3: SQLite 索引 (结构化查询)
    → runtime/sqlite/traces.db
```

**依赖**：`shared/` (无直接导入，通过 recorder 导入 shared 类型)。

---

### 🛡️ 1.4 `safety/` — 安全护栏（3 文件）

两层防护：Prompt 内嵌规则（LLM 自我约束）+ 代码侧规则引擎（确定性拦截）。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `safety/__init__.py` | 1 | 模块入口 | — |
| `safety/rule_engine.py` | 76 | **3 层安全检查**。Layer 1: READ_ONLY 直接放行。Layer 2: 高危参数模式匹配（6 组正则）。Layer 3: DANGEROUS 级别需确认 | `RuleEngine.checkToolCall(toolName, riskLevel, arguments) → SafetyVerdict`, `.checkToolCallWithReason(...,) → (SafetyVerdict, reason)` |
| `safety/injection_detector.py` | 37 | **Prompt Injection 检测**，基于正则模式匹配，不依赖 LLM | `checkPromptInjection(text) → bool`。13 条中英双语规则：`ignore previous instructions` / `forget everything` / `忽略之前的指令` / `关闭安全检查` / `假装你是` 等 |

**6 组危险参数模式**：

| 正则 | 匹配 | 原因 |
|------|------|------|
| `(^\|[/\\])\.\.\s*$` | 路径包含 `..` | 目录穿越 |
| `^/$` | 操作根目录 `/` | 极其危险 |
| `^/(etc\|boot\|usr\|lib\|sbin\|bin\|proc\|sys)\b` | 系统关键目录 | 不可逆损坏 |
| `^/home$` | 操作 `/home` 根目录 | 影响所有用户 |
| `\b777\b` | `chmod 777` | 权限过于宽松 |
| `\b(SIGKILL\|9)\b` | `kill -9` | 无法被进程捕获 |

**依赖**：`shared/types` (ToolRiskLevel, SafetyVerdict)。

---

### 🧠 1.5 `agent_core/` — Agent 核心引擎（3 文件）

**项目心脏**。实现了完整的 ReAct 循环和 4 层 KV Cache 优化的 Prompt 组装。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `agent_core/__init__.py` | 1 | 模块入口 | — |
| `agent_core/agent_loop.py` | 180 | **Agent ReAct 主循环**。纯 asyncio 状态机替代 LangGraph。状态: IDLE → THINKING → EXECUTING → DONE。注入检测 → Prompt 组装 → LLM 调用 → 工具执行 → 结果注入 → 循环 | `AgentCore.__init__(llmProvider, registry, dispatcher, safety, promptBuilder, maxRounds)`, `.run(userMessage, stream, systemInfo?, conversationHistory?)`, `LoopState` 枚举 |
| `agent_core/prompt_builder.py` | 88 | **4 层 Prompt 组装器**。KV Cache 优化：L1 静态前缀(跨用户共享) + L2 半静态(同 Profile 共享) + L3 会话上下文 + L4 当前请求。Tool Definitions 按 name 字母序排列，canonical_json 序列化保证前缀稳定 | `PromptBuilder.__init__(systemPrompt, safetyRules, toolSchemas)`, `.build(userMessage, systemInfo?, conversationHistory?, policyProfile?) → messages: list[dict]` |

**ReAct 循环详细流程**：

```
用户消息到达
  │
  ├── checkPromptInjection() ── 命中 → emit(ERROR) → DONE
  │
  ├── PromptBuilder.build() ── 4层 messages 数组
  │
  └── [LOOP: round=1..maxRounds]
       │
       ├── THINKING:
       │    ├── emit(THINKING_START, round)
       │    ├── llm.chat(messages) → LLMResponse
       │    ├── [只有 content 无 tool_calls] → emit(TEXT_DELTA) × N → TEXT_DONE → DONE
       │    ├── [空响应] → emit(TEXT_DELTA: "空响应") → DONE
       │    └── [有 tool_calls] → 封入 messages → 进入 EXECUTING
       │
       └── EXECUTING:
            for each tc in response.tool_calls:
              ├── registry.getRiskLevel(name)
              ├── safety.checkToolCallWithReason(name, risk, args)
              ├── emit(SAFETY_CHECKED)
              ├── [ALLOW] → dispatcher.handle(tools/call) → 执行
              ├── [BLOCK] → emit(ERROR)
              ├── [REQUIRE_CONFIRM] → emit(APPROVAL_REQUIRED) → 执行 (BUG: 应等待 approve)
              ├── emit(TOOL_RESULT)
              └── 结果 append 到 messages
            → 回到 THINKING
```

**4 层 Prompt 结构**：

```
messages = [
    # L1: 静态前缀 (所有会话共享，KV Cache 命中率最高)
    {"role": "system", "content": "<System Prompt> + <Tools(字母序)> + <Safety Rules>"},

    # L2: 半静态层 (同 Policy Profile 共享)
    {"role": "system", "content": "## 当前策略\n{canonical_json(policy)}"},

    # L3: 会话上下文 (同会话复用)
    {"role": "system", "content": "## 当前系统信息\n{canonical_json(snapshot)}"},
    ...conversationHistory...

    # L4: 当前请求 (每轮不同)
    {"role": "user", "content": currentMessage},
]
```

**依赖**：`shared/types`, `integration/event_stream`, `safety/injection_detector`, `safety/rule_engine`, `mcp/server/registry`, `mcp/server/dispatcher`, `mcp/protocol/json_rpc`, `llm_providers/base`。

---

### 📡 1.6 `context_mgmt/` — 上下文管理（3 文件）

负责采集 Linux 系统实时状态供 Prompt 使用，以及对话历史超 token 预算时的压缩。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `context_mgmt/__init__.py` | 1 | 模块入口 | — |
| `context_mgmt/collectors.py` | 163 | **系统快照采集器**。纯 `/proc` 读取 + subprocess 命令，**无 psutil 依赖**。覆盖 CPU/内存/磁盘/进程/网络/uptime/uname | `getSystemSnapshot() → {cpu, memory, disk[], processes_top5[], network, uptime_seconds, uname}`。内部 7 个 `_collect*()` 私有函数 |
| `context_mgmt/compressor.py` | 76 | **对话历史压缩器**。策略：保留 system 消息 + 最近 N 条消息 + 更早消息替换为规则摘要 | `compressHistory(messages, maxRecent=6, maxTokens=40000) → list[dict]`。`_buildSummary()` 纯规则提取主题不调 LLM |

**8 个数据源采集方式**：

| 数据 | 采集方式 | 采集内容 |
|------|----------|----------|
| CPU | `/proc/cpuinfo` + `/proc/stat` (2次采样间隔0.3s) | model, cores, usage_pct, load1/5/15 |
| 内存 | `/proc/meminfo` | total/used/available/swap (GB) |
| 磁盘 | `df -h` subprocess | 分区 filesystem/size/used/avail/mount/use% |
| 进程 | `ps aux --sort=-%cpu` subprocess | top5 CPU 进程 user/pid/cpu/mem/command |
| 网络 | `ss -tunap` subprocess | connections 计数 |
| Uptime | `/proc/uptime` | uptime_seconds |
| 系统版本 | `uname -a` + `/etc/os-release` | uname + os_release |

**依赖**：纯 stdlib (`os`, `subprocess`, `time`)，无项目内部依赖。

---

### 🔌 1.7 `mcp/` — MCP 协议引擎（8 文件）

自实现 MCP (Model Context Protocol) 最小子集。仅依赖 stdlib JSON，无需官方 MCP SDK。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `mcp/__init__.py` | 1 | 模块入口 | — |
| `mcp/protocol/__init__.py` | 1 | 协议子模块入口 | — |
| `mcp/protocol/json_rpc.py` | 49 | **JSON-RPC 2.0 编解码** | `JSONRPC_VERSION`, `PARSE_ERROR(-32700)/METHOD_NOT_FOUND(-32601)/INVALID_PARAMS(-32602)/INTERNAL_ERROR(-32603)`, `JsonRpcRequest` dataclass, `encodeRequest/decodeRequest/encodeResult/encodeError` |
| `mcp/protocol/schemas.py` | 45 | **函数签名 → JSON Schema 自动生成**。反射 Python 类型注解生成 OpenAI Function Calling 格式的 JSON Schema | `annotationToJsonSchema(annotation) → {"type": "..."}`, `functionToToolSchema(func) → {"type": "function", "function": {...}}`。支持 str/int/float/bool/Enum/list/Union 七种类型 |
| `mcp/transports/__init__.py` | 1 | 传输层入口 | — |
| `mcp/transports/stdio.py` | 15 | **stdio 传输层** | `stdioServe(handler: Callable[[str], str])`: 逐行读 stdin → handler → 写 stdout。`Handler` 类型别名 |
| `mcp/server/__init__.py` | 1 | Server 子模块入口 | — |
| `mcp/server/registry.py` | 31 | **工具注册中心** | `ToolRegistry.register(func, riskLevel)`, `.registerMany(funcs, riskLevel)`, `.listTools() → schemas(字母序)`, `.getTool(name) → func`, `.getRiskLevel(name) → ToolRiskLevel` |
| `mcp/server/dispatcher.py` | 57 | **MCP 请求分发器**。支持 4 个标准 MCP 方法 | `McpDispatcher.handle(raw_jrpc_str) → result_jrpc_str`。`_handle_initialize` (返回 serverInfo), `_handle_tools_list` (字母序工具列表), `_handle_tools_call` (调用 + dataclass 自动序列化), `_handle_ping` |

**MCP 方法路由**：`method.replace('/', '_')` → `_handle_{method_name}`。未知方法返回 JSON-RPC 错误。

**依赖**：`mcp/protocol/json_rpc`, `mcp/protocol/schemas`, `shared/types`。

---

### 🔧 1.8 `plugins/` — 运维工具插件（3 文件）

纯 stdlib 实现的 Linux 运维工具集。当前仅完成 2/9 组插件。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `plugins/__init__.py` | 1 | 模块入口 | — |
| `plugins/os_observe.py` | 122 | **系统观察工具**。纯 `/proc` + subprocess，无 psutil | `getCpuInfo() → CpuInfo`: modelName, coreCount, usagePercent, load1/5/15Min (2 次 /proc/stat 采样差值得 CPU 使用率)。`getMemoryInfo() → MemoryInfo`: totalBytes/usedBytes/availableBytes/usagePercent + swap (解析 /proc/meminfo)。`getUptime() → dict`: 格式化运行时间。`getSystemVersion() → dict`: uname + /etc/os-release |
| `plugins/filesystem.py` | 50 | **文件系统操作工具** | `listDirectory(targetPath) → list[FileInfo]`: 名称/路径/大小/目录/权限/修改时间。`createDirectory(targetPath) → FileOperationResult`: 递归创建(makedirs)。`deleteFile(targetPath) → FileOperationResult`: 删除文件/不存在报错 |

**依赖**：`shared/ops_types` (CpuInfo, MemoryInfo, FileInfo, FileOperationResult)，`os`, `subprocess`, `shutil`, `time`。

---

### 🤖 1.9 `llm_providers/` — LLM 适配层（5 文件）

抽象 LLM 调用接口。核心实现使用 stdlib `urllib.request`，完全无 openai SDK 依赖。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `llm_providers/__init__.py` | 1 | 模块入口 | — |
| `llm_providers/base.py` | 25 | **LLM Provider 抽象基类** | `LLMProvider(ABC)`: `chat(messages) → LLMResponse`, `chatStream(messages) → AsyncIterator[LLMResponse]` |
| `llm_providers/openai_compat.py` | 107 | **OpenAI-compatible Provider**。stdlib `urllib.request` 实现，零外部依赖。延迟在 `run_in_executor` 执行 HTTP 以避免阻塞事件循环 | `OpenAIProvider.__init__(endpoint, apiKey, model, maxTokens, temperature)`. `chat(messages) → LLMResponse`: POST `/chat/completions`, 解析 content + tool_calls。`chatStream(messages) → AsyncIterator[LLMResponse]`: SSE 流式解析。`_httpPost(body)`: urllib.request.Request 同步调用 |
| `llm_providers/sse_parser.py` | 93 | **SSE 流式解析器**。逐行解析 `data:` 行，不依赖外部库 | `parseSseStream(lines) → list[dict]`: 解析 `data: {"choices":[...]}` → `[{"delta":{...}, "finish_reason":"..."}]`。`mergeSseDeltas(events) → dict`: 合并增量 tool_calls (按 index 聚合 function.name + arguments 片段) |
| `llm_providers/mock.py` | 52 | **Mock Provider**。可预设响应序列，不依赖外部 API。用于离线测试和 CI | `MockProvider.__init__(responses?)`, `chat() → 返回预设序列中的下一个`, `chatStream() → 每5字符 yield 一个增量`, `mockSetResponses()` |

**依赖**：`llm_providers/base`, `llm_providers/sse_parser`, `shared/types` (LLMResponse), `json`, `urllib.request`, `asyncio`。

---

### 🔗 1.10 `integration/` — 后端对接层（3 文件）

对外的唯一接口层。后端通过 `AgentSession` 与整个 Agent 内核交互。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `integration/__init__.py` | 1 | 模块入口 | — |
| `integration/session.py` | 106 | **对外唯一入口**。组装全栈组件：ToolRegistry + Safety + McpDispatcher + PromptBuilder + LLM Provider (OpenAI 或 Mock fallback) + TraceRecorder + AgentCore | `AgentSession.__init__(config, userId, sessionId?)`, `.fromConfigFile(path, **kwargs) → AgentSession`, `.submit(message) → AsyncIterator[AgentEvent]` |
| `integration/event_stream.py` | 49 | **事件流**。基于 asyncio.Queue 的生产者-消费者模式 | `EventStream.__init__(sessionId)`. `.emit(type, data?)`: 同步放入队列。`.aEmit(type, data?)`: 异步放入。`async __aiter__()`: 消费事件直到 DONE/ERROR。`.close()`: 发送 DONE 并关闭 |

**AgentSession 初始化流程**：
```
1. gen_session_id()
2. 加载 Prompt 模板 (conf/prompts/system/v1.0.0.txt + safety/rules_summary.txt)
3. ToolRegistry → 注册 7 个工具 (os_observe ×4, filesystem ×3)，分配风险等级
4. RuleEngine()
5. McpDispatcher(registry)
6. PromptBuilder(sysPrompt, safetyRules, registry.listTools())
7. LLM Provider: 有 apiKey → OpenAIProvider / 无 → MockProvider fallback
8. TraceRecorder(dbPath)
9. AgentCore(llm, registry, dispatcher, safety, promptBuilder, maxRounds)
```

**依赖**：几乎所有模块 — `shared/*`, `config_envs/loader`, `safety/rule_engine`, `mcp/server/*`, `agent_core/*`, `llm_providers/*`, `plugins/*`, `trace_log/recorder`, `integration/event_stream`。

---

### 🔄 1.11 `compat/` — API 风格兼容层（3 文件）

将内部 AgentEvent 转换为主流 LLM API 的 SSE 格式，供后端直接流式输出。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `compat/api_styles/__init__.py` | 1 | 模块入口 | — |
| `compat/api_styles/openai_adapter.py` | 50 | **OpenAI Chat Completions 风格 SSE 格式化** | `OpenAIAdapter.formatSse(event) → "data: {...}\n\n"`. 映射: TEXT_DELTA → delta.content, TOOL_CALLING → tool_call{id,name,args}, TOOL_RESULT → tool_result, APPROVAL_REQUIRED → approval, DONE → `data: [DONE]` |
| `compat/api_styles/claude_adapter.py` | 123 | **Claude Messages 风格 SSE 格式化** | `ClaudeAdapter.formatSse(event) → "event: content_block_start\ndata: {...}\n\n..."`. 映射: TEXT_DELTA → content_block_delta (text_delta), THINKING_DELTA → content_block_delta (thinking_delta), TOOL_CALLING → content_block_start (tool_use), TOOL_RESULT → content_block_start (tool_result), DONE → message_stop。带内部计数器维持 block index |

**依赖**：`shared/types` (AgentEvent, EventType), `json`。

---

### ⚡ 1.12 `execution/` — 最小权限执行代理（2 文件）

安全执行 OS 命令。虽然 AgentCore 当前绕过了它（通过 dispatcher 直接调用 plugin 函数），但它是设计中执行层的基础组件。

| 文件 | 行数 | 作用 | 关键导出 |
|------|:--:|------|----------|
| `execution/__init__.py` | 1 | 模块入口 | — |
| `execution/executor.py` | 68 | **安全命令执行器**。路径黑白名单 + shell=False 防注入 + 环境清洗(PATH重写) + 超时控制 + 输出截断 | `runCommand(argv, timeout=30, runAs="nobody", allowedPaths?, deniedPaths?, maxOutputBytes=65536) → (success, stdout, stderr)`。安全 PATH: `/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin` |

**依赖**：纯 stdlib (`subprocess`, `os`)，无项目内部依赖。

---

### 📄 1.13 `__init__.py` — 包根入口

| 位置 | 行数 | 作用 |
|------|:--:|------|
| `__init__.py` | 8 | 包级别入口，声明 `__version__ = "0.1.0"` 和包 docstring |

---

## 二、配置层 `conf/`（4 文件）

| 文件 | 行数 | 所属模块 | 作用 |
|------|:--:|----------|------|
| `conf/profiles/development.json` | 10 | `config_envs` | 开发环境配置：`llm_endpoint: "https://api.deepseek.com/v1"`, `llm_model: "deepseek-chat"`, `safety_policy: "default"`, `execution_user: "nobody"`, `max_tool_rounds: 10` |
| `conf/profiles/production.json` | 10 | `config_envs` | 生产环境配置：`safety_policy: "strict"`, `execution_user: "osagent-exec"`, `trace_db_path: "/var/lib/ndlmpanel/traces.db"` |
| `conf/prompts/system/v1.0.0.txt` | 14 | `agent_core` | **System Prompt 模板**（版本化）。角色定义 + 5 条核心规则。文本固定不插入动态变量，保证 L1 静态前缀可缓存 |
| `conf/prompts/safety/rules_summary.txt` | 17 | `safety` | **安全规则摘要**。嵌入 Prompt L1 让 LLM 知晓边界。9 条禁止规则 + 4 类注入特征检测描述 |

---

## 三、测试层 `tests/`（15 个 .py 测试文件，54 项用例，全部通过）

### 3.1 `tests/unit/` — 单元测试（13 文件）

| 测试文件 | 行数 | 测试对象 | 用例 |
|----------|:--:|----------|:--:|
| `unit/__init__.py` | 1 | 使 unit 成为包 | — |
| `unit/test_shared_types.py` | 55 | `shared/types.py` | **9 项**：EventType/DONE=done、ToolRiskLevel/DANGEROUS=dangerous、SafetyVerdict/BLOCK=block、AgentEvent 默认值、ToolDefinition 默认风险、ToolCall 字段、ToolResult.truncated、LLMResponse 默认值、AgentConfig 空 endpoint 抛 ValueError、dataclass_to_dict、dict_to_dataclass |
| `unit/test_shared_errors.py` | 14 | `shared/errors.py` | **2 项**：ErrorCode 值校验、AgentError 异常字段 |
| `unit/test_shared_serialization.py` | 14 | `shared/serialization.py` | **3 项**：canonical_json 键排序、safe_truncate 短文不截断、safe_truncate 长文截断含标记 |
| `unit/test_shared_id_gen.py` | 12 | `shared/id_gen.py` | **2 项**：前缀检查(sess_/trace_/tc_)、100 个 ID 唯一性 |
| `unit/test_config_loader.py` | 44 | `config_envs/loader.py` | **5 项**：mergeConfigs 浅层/深层/覆盖、loadConfig 有效文件/不存在文件/环境变量覆盖/运行时覆盖 |
| `unit/test_config_secrets.py` | 9 | `config_envs/secrets.py` | **2 项**：getSecret 获取已设环境变量、获取不存在变量返回 "" |
| `unit/test_config_schema.py` | 15 | `config_envs/schema.py` | **4 项**：合法配置无错误、空 endpoint 报错、非 http 协议报错、max_tool_rounds 超限报错 |
| `unit/test_mcp_json_rpc.py` | 21 | `mcp/protocol/json_rpc.py` | **4 项**：encodeRequest method 字段、decodeRequest round-trip、encodeResult 含 result、encodeError 含 error code |
| `unit/test_mcp_schemas.py` | 23 | `mcp/protocol/schemas.py` | **3 项**：str→string/int→integer、Enum→{type:string,enum:["red","blue"]}、函数→含 name 和 parameters.properties |
| `unit/test_mcp_registry.py` | 29 | `mcp/server/registry.py` | **5 项**：listTools 字母序 2 个、getTool 获取存在/不存在、getRiskLevel READ_ONLY vs DANGEROUS |
| `unit/test_mcp_dispatcher.py` | 30 | `mcp/server/dispatcher.py` | **4 项**：initialize 返回 serverInfo、tools/list 返回 1 工具、tools/call echo 返回 {"echo":"hi"}、unknown method 返回 error |
| `unit/test_plugins_os_observe.py` | 20 | `plugins/os_observe.py` | **4 项**：getCpuInfo > 0 cores、getMemoryInfo > 0 totalBytes、getUptime > 0 seconds、getSystemVersion uname 非空 |
| `unit/test_plugins_filesystem.py` | 26 | `plugins/filesystem.py` | **4 项**：创建目录成功、列出目录含新子目录、删除文件成功且不存在、删除不存在的文件返回失败 |

### 3.2 `tests/smoke/` — 冒烟测试（1 文件，1 项全链路用例）

| 测试文件 | 行数 | 覆盖链 | 验证步骤 |
|----------|:--:|--------|----------|
| `smoke/__init__.py` | 1 | 使 smoke 成为包 | — |
| `smoke/test_smoke.py` | 41 | **Config → ToolRegistry → McpDispatcher → Plugin 全链路** | ① loadConfig(临时 JSON) → endpoint 正确。② 注册 3 个工具(READ_ONLY)。③ tools/list → 返回 3 项。④ tools/call getCpuInfo → coreCount > 0。⑤ tools/call getMemoryInfo → totalBytes > 0 |

---

## 四、文档层 `docs/`（15 个文件）

### 4.1 设计文档

| 文件 | 行数 | 说明 |
|------|:--:|------|
| `docs/Design-1.md` | 350 | **项目技术规划**：整体架构 mermaid 图、Agent Loop 核心流程、技术栈选型(零依赖)、模块划分、安全护栏 4 层架构、MCP 插件化架构、B/S 对接设计 |
| `docs/Design-2.md` | 1892 | **完整技术设计文档**：两种集成模式、SDK 入口设计、15 种 EventType、Pydantic 兼容层、OpenAI/Claude API 风格适配、Prompt 4 层 KV Cache 优化、16 个子模块详细设计、数据流全景、10 阶段实现计划、安全纵深防御 6 层模型 |
| `docs/Skeleton-Design.md` | 840 | **重构骨架设计**：S0-S8 分阶段规划、零外部依赖边界清单、Shared/Config/TraceLog/Safety/Prompt 各模块具体设计、命名约定、验收标准 |

### 4.2 分析文档

| 文件 | 行数 | 说明 |
|------|:--:|------|
| `docs/Gap-Analysis.md` | 312 | **设计-实现差距分析**：14 个模块的 Gap 清单（按子模块列出)、3 个 P0 bug、4 级优先级矩阵(P0-P3)、总结 |
| `docs/Operational-Flow.md` | 500 | **运作流程详解**：完整请求生命周期流程图 + 时序图、8 个子流程分解(Config/Session/Prompt/LLM/Safety/MCP/Plugin/TraceLog)、EventType 速查、后端对接示例、运行示例 |
| `docs/Project-File-Analysis.md` | — | 本文件 |

### 4.3 构建脚本

| 文件 | 对应阶段 | 生成内容 |
|------|----------|----------|
| `_build_s0.py` | S0 | shared/ 全部文件 (types, errors, serialization, id_gen, __init__) + 包根 __init__.py |
| `_build_s1.py` | S1 | config_envs/ 全部文件 (loader, secrets, schema) + development.json + production.json |
| `_build_s3.py` | S3 | mcp/ 全部文件 (json_rpc, schemas, stdio, registry, dispatcher) + plugins/ (os_observe, filesystem) + ops_types.py |
| `_build_tests.py` | 测试 | 全部 13 个单元测试 + 冒烟测试 |

### 4.4 验收脚本

| 文件 | 验证内容 |
|------|----------|
| `_verify_s1.py` | Config 系统：加载 development.json、validateConfig、mergeConfigs、环境变量覆盖 |
| `_verify_s2.py` — `_verify_s8.py` | 后续阶段验收（S2 Prompt+Safety, S3 MCP+Plugin, S4 AgentCore, S5 Context, S6 集成, S7 全部插件, S8 Integration） |

---

## 五、模块间完整依赖关系图

```
┌─────────────────────────────────────────────────────────────┐
│                    向后端暴露的公共 API                       │
│  AgentSession, AgentConfig, AgentEvent, OpenAIAdapter, etc. │
└───────────────────────┬─────────────────────────────────────┘
                        │
        ┌───────────────┴───────────────┐
        │                               │
   AgentSession (integration/session)   OpenAIAdapter/ClaudeAdapter (compat/api_styles)
        │                               │
        ├── config_envs/loader ─────────┤
        │   ├── config_envs/secrets     │
        │   └── shared/types            │
        │                               │
        ├── agent_core/agent_loop ──────┤
        │   ├── safety/injection_detector
        │   ├── safety/rule_engine ─────┤
        │   │   └── shared/types        │
        │   ├── mcp/server/registry ────┤
        │   │   └── mcp/protocol/schemas
        │   ├── mcp/server/dispatcher ──┤
        │   │   └── mcp/protocol/json_rpc
        │   ├── agent_core/prompt_builder
        │   │   └── shared/serialization
        │   ├── integration/event_stream
        │   │   └── shared/types + shared/id_gen
        │   └── llm_providers/base ─────┤
        │       ├── llm_providers/openai_compat
        │       │   └── llm_providers/sse_parser
        │       └── llm_providers/mock
        │                               │
        ├── plugins/os_observe ─────────┤
        │   └── shared/ops_types        │
        ├── plugins/filesystem ─────────┤
        │   └── shared/ops_types        │
        │                               │
        ├── trace_log/recorder ─────────┤
        │   ├── trace_log/storage       │
        │   ├── trace_log/hash_chain    │
        │   └── trace_log/sanitizer     │
        │                               │
        └── execution/executor ─────────┘  (纯 stdlib, 无项目依赖)

非直接依赖，但存在于项目中:
  context_mgmt/collectors  (纯 stdlib)
  context_mgmt/compressor  (纯 stdlib)
```

---

## 六、文件统计总表

| 层级 | 目录 | 文件数 | 总行数 (估) |
|------|------|:--:|:--:|
| 源码 | `src/ndlmpanel_agent/shared/` | 6 | ~360 |
| 源码 | `src/ndlmpanel_agent/config_envs/` | 4 | ~140 |
| 源码 | `src/ndlmpanel_agent/trace_log/` | 5 | ~210 |
| 源码 | `src/ndlmpanel_agent/safety/` | 3 | ~115 |
| 源码 | `src/ndlmpanel_agent/agent_core/` | 3 | ~270 |
| 源码 | `src/ndlmpanel_agent/context_mgmt/` | 3 | ~240 |
| 源码 | `src/ndlmpanel_agent/mcp/` | 8 | ~240 |
| 源码 | `src/ndlmpanel_agent/plugins/` | 3 | ~175 |
| 源码 | `src/ndlmpanel_agent/llm_providers/` | 5 | ~285 |
| 源码 | `src/ndlmpanel_agent/integration/` | 3 | ~160 |
| 源码 | `src/ndlmpanel_agent/compat/` | 3 | ~175 |
| 源码 | `src/ndlmpanel_agent/execution/` | 2 | ~70 |
| 源码 | 包根 `__init__.py` | 1 | ~10 |
| **源码合计** | | **49** | **~2450** |
| 配置 | `conf/` | 4 | ~50 |
| 测试 | `tests/` | 15 | ~430 |
| **总计** | | **68** | **~2930** |
