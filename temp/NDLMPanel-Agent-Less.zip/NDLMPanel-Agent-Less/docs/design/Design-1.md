---
type: project
status: active
created: 2026-05-25
updated: 2026-05-25
tags:
  - project
---
[[Design-2]]
# 智能运维 Agent 项目技术规划

## 一、整体架构概览

```mermaid
graph TB
    subgraph "用户层"
        UI[B/S 前端]
    end

    subgraph "接入层"
        API[API Gateway / WebSocket Server]
    end

    subgraph "核心引擎"
        Router[Agent Router<br/>意图路由与会话调度]
        Loop[Agent Loop<br/>推理-行动循环]
        LLM[LLM Core<br/>模型调用与流式处理]
        CTX[Context Manager<br/>上下文窗口管理]
    end

    subgraph "安全层"
        Intent[Intent Guard<br/>意图风险分类]
        Param[Param Filter<br/>高危参数拦截]
        Perm[Permission Proxy<br/>最小权限代理]
        Anti[Anti-Injection<br/>提示词注入检测]
    end

    subgraph "执行层"
        MCP[MCP Protocol Engine<br/>JSON-RPC 通信]
        Plugins[MCP Plugins<br/>运维工具集]
        Sandbox[Sandbox Executor<br/>隔离执行环境]
    end

    subgraph "可观测层"
        Trace[Trace Logger<br/>思维链日志]
        Audit[Audit Store<br/>审计存储]
    end

    UI -->|HTTP/WS| API
    API --> Router
    Router --> Loop
    Loop --> LLM
    Loop --> CTX
    Loop -->|生成指令| Intent
    Intent -->|通过| Param
    Param -->|通过| Perm
    Perm --> MCP
    MCP --> Plugins
    Plugins --> Sandbox
    Sandbox -->|结果| Loop
    Anti -.->|拦截| Router
    Loop -->|每步记录| Trace
    Trace --> Audit
```

## 二、Agent Loop（Agent 循环）核心流程

参考 Claude Code 的 agentic loop 设计：

```mermaid
flowchart LR
    A[接收用户输入] --> B[上下文组装]
    B --> C[LLM 推理]
    C --> D{输出类型?}
    D -->|文本回复| E[返回用户]
    D -->|工具调用| F[安全校验链]
    F -->|拒绝| G[生成拒绝说明]
    G --> E
    F -->|通过| H[MCP 工具执行]
    H --> I[结果注入上下文]
    I --> C
    E --> J[写入 Trace Log]
```

## 三、技术栈选型

### 核心原则

- 优先使用 Python 标准库（Standard Library），确保 LoongArch + 麒麟 V11 兼容
- 外部依赖仅选用纯 Python（Pure Python）实现的包，无 C 扩展编译需求
- 环境管理使用 `venv` + `pip`（不使用 uv）

### 技术栈总表

| 层级 | 技术选型 | 说明 |
|------|----------|------|
| 异步运行时 | `asyncio`（stdlib） | Agent Loop 主循环驱动 |
| 系统命令执行 | `asyncio.subprocess` / `subprocess`（stdlib） | 非阻塞执行 OS 命令 |
| LLM API 通信 | `urllib.request`（stdlib）+ 自封装异步 HTTP | 兼容 DeepSeek/Qwen3 OpenAI-compatible API |
| 流式响应解析 | `SSE 手动解析`（stdlib `http.client`） | Server-Sent Events 逐行读取 |
| 数据序列化 | `json` / `dataclasses`（stdlib） | 替代 pydantic，零依赖 |
| 配置管理 | `tomllib`（Python 3.11+ stdlib）/ `configparser` | TOML 或 INI 配置 |
| 审计存储 | `sqlite3`（stdlib） | 思维链日志持久化 |
| 日志系统 | `logging`（stdlib） | 结构化日志输出 |
| MCP 协议 | 自实现 JSON-RPC 2.0 over stdio/HTTP | 参考官方规范，轻量实现 |
| 进程隔离 | `os.setuid` / `subprocess` 用户切换 | 最小权限执行 |
| 正则匹配 | `re`（stdlib） | 安全规则匹配引擎 |
| 模板引擎 | `string.Template`（stdlib） | Prompt 模板渲染 |
| B/S 对接接口 | 暴露 Unix Socket / HTTP JSON API | 供前端 WebSocket 网关调用 |

### 可选纯 Python 外部包（按需引入）

| 包名 | 用途 | 纯 Python |
|------|------|-----------|
| `httpx` | 更优雅的异步 HTTP（如需） | ✓（h11 纯 Python） |
| `prompt_toolkit` | TUI 交互调试界面 | ✓ |
| `rich` | 终端美化输出（调试用） | ✓ |
| `PyYAML` | YAML 配置（纯 Python 模式） | ✓（禁用 LibYAML） |

## 四、子模块划分

```mermaid
graph LR
    subgraph 项目根
        A[agent_core] --- B[safety]
        A --- C[mcp_engine]
        A --- D[context]
        A --- E[trace]
        C --- F[plugins]
        A --- G[llm]
        A --- H[router]
        A --- I[config]
        A --- J[interface]
        A --- K[sandbox]
    end
```

### 各模块职责

| 模块 | 职责 | 关键技术点 |
|------|------|-----------|
| `agent_core` | Agent Loop 主循环、状态机、生命周期管理 | asyncio Task 调度，参考 Claude Code 的 turn-based loop |
| `safety` | 安全护栏总成：意图分类、参数过滤、注入检测 | 规则引擎 + LLM 二次判定（dual-check） |
| `mcp_engine` | MCP 协议实现：JSON-RPC server/client、tool 注册与发现 | 自实现 JSON-RPC 2.0，stdio transport |
| `plugins` | 运维工具插件集：进程管理、磁盘分析、网络诊断、日志分析等 | 每个 plugin 为独立模块，声明式注册 |
| `context` | 上下文窗口管理：消息历史、token 预算、摘要压缩 | 滑动窗口 + 重要性评分 |
| `trace` | 推理链路溯源：全链路日志、结构化事件记录 | sqlite3 存储 + JSON 结构化 |
| `llm` | LLM 适配层：多模型支持、流式处理、重试策略 | 适配 DeepSeek/Qwen3 的 OpenAI-compatible 接口 |
| `router` | 会话路由：多轮对话管理、意图预分类、任务编排 | 状态机 + 意图识别快速路径 |
| `config` | 配置与环境：全局配置、密钥管理、运行时参数 | TOML 配置 + 环境变量覆盖 |
| `interface` | 对外接口层：HTTP API、Unix Socket、事件推送 | 供 B/S 前端网关对接 |
| `sandbox` | 隔离执行：用户切换、资源限制、超时控制 | setuid + cgroups + timeout |

## 五、项目目录结构

```
ops-agent/
├── src/
│   ├── agent_core/          # Agent Loop 主引擎
│   ├── safety/              # 安全护栏
│   │   ├── intent_guard/    # 意图风险分类器
│   │   ├── param_filter/    # 高危参数拦截
│   │   ├── permission/      # 最小权限代理
│   │   └── anti_injection/  # Prompt Injection 检测
│   ├── mcp_engine/          # MCP 协议引擎
│   │   ├── transport/       # stdio/HTTP 传输层
│   │   ├── registry/        # Tool 注册与发现
│   │   └── protocol/       # JSON-RPC 编解码
│   ├── plugins/             # MCP 运维插件
│   │   ├── process/         # 进程管理（ps, kill, top）
│   │   ├── disk/            # 磁盘分析（df, du, lsof）
│   │   ├── network/         # 网络诊断（netstat, ss, ping）
│   │   ├── logs/            # 日志分析（journalctl, tail）
│   │   ├── service/         # 服务管理（systemctl）
│   │   └── filesystem/      # 文件操作（安全受限）
│   ├── context/             # 上下文管理
│   ├── trace/               # 推理链路追踪
│   ├── llm/                 # LLM 适配层
│   │   ├── providers/       # 模型提供商适配
│   │   ├── streaming/       # 流式响应处理
│   │   └── prompts/         # System Prompt 模板
│   ├── router/              # 会话路由与调度
│   ├── config/              # 配置管理
│   ├── interface/           # 对外 API 接口
│   └── sandbox/             # 隔离执行环境
├── tests/                   # 测试
├── docs/                    # 文档（赛题要求的各类文档）
├── scripts/                 # 部署与运维脚本
└── pyproject.toml           # 项目元数据与依赖声明
```

## 六、安全护栏架构（Safety Guardrail）

这是赛题核心差异化点，设计为多级拦截链：

```mermaid
flowchart TD
    Input[用户自然语言输入] --> L1

    subgraph "Level 1: 输入层防护"
        L1[Anti-Injection 检测]
        L1 -->|正常| L2
        L1 -->|注入攻击| REJECT1[拒绝 + 告警]
    end

    subgraph "Level 2: 意图层防护"
        L2[Intent Guard 意图风险分类]
        L2 -->|低风险| L3
        L2 -->|高风险| CONFIRM[人工确认]
        CONFIRM -->|批准| L3
        CONFIRM -->|拒绝| REJECT2[拒绝]
    end

    subgraph "Level 3: 参数层防护"
        L3[Param Filter 参数审查]
        L3 -->|安全| L4
        L3 -->|危险参数| REWRITE[参数改写/降级]
        REWRITE --> L4
    end

    subgraph "Level 4: 执行层防护"
        L4[Permission Proxy 权限检查]
        L4 -->|合规| EXEC[Sandbox 执行]
        L4 -->|越权| REJECT3[拒绝 + 日志]
    end

    EXEC --> TRACE[写入 Trace Log]
```

### 安全规则示例

| 规则类别 | 检测内容 | 处置方式 |
|----------|----------|----------|
| 危险命令 | `rm -rf /`, `mkfs`, `dd if=/dev/zero` | 直接拦截 |
| 权限提升 | `chmod 777`, `chown root`, `sudo` 滥用 | 人工确认 |
| 信息泄露 | `cat /etc/shadow`, 访问私钥文件 | 拦截 + 告警 |
| 批量操作 | 通配符删除、递归修改 | 降级为逐一确认 |
| 注入检测 | "ignore previous instructions"、编码绕过 | 拦截 + 记录攻击样本 |

## 七、MCP 插件化架构

```mermaid
flowchart LR
    subgraph "MCP Engine"
        REG[Plugin Registry<br/>插件注册表]
        DISC[Tool Discovery<br/>工具发现]
        DISPATCH[Dispatcher<br/>调用分发]
    end

    subgraph "Plugin Interface"
        SCHEMA[Tool Schema<br/>参数声明]
        EXEC_F[Execute<br/>执行函数]
        VALID[Validator<br/>前置校验]
    end

    subgraph "具体插件"
        P1[process_plugin]
        P2[disk_plugin]
        P3[network_plugin]
        P4[log_plugin]
        P5[service_plugin]
    end

    LLM_OUT[LLM Tool Call] --> DISPATCH
    DISPATCH --> REG
    REG --> SCHEMA
    SCHEMA --> VALID
    VALID --> EXEC_F
    P1 & P2 & P3 & P4 & P5 -->|注册| REG
```

每个插件遵循统一接口协议：

```python
# 插件声明式注册（伪代码示意）
@mcp_tool(
    name="disk.analyze_usage",
    description="分析磁盘使用情况，找出大文件",
    risk_level="low",
    required_permission="read"
)
async def analyze_disk_usage(path: str = "/", top_n: int = 10):
    ...
```

## 八、环境管理方案

```bash
# 使用标准 venv（不依赖 uv）
python3 -m venv .venv
source .venv/bin/activate

# 依赖管理
pip install -e .                    # 开发模式安装
pip freeze > requirements.lock      # 锁定版本

# 多环境配置
# config/dev.toml   - 开发环境
# config/prod.toml  - 生产环境（麒麟 V11）
```

项目元数据使用 `pyproject.toml`（PEP 621 标准），构建后端用 `setuptools`：

```toml
[project]
name = "ops-agent"
requires-python = ">=3.10"
dependencies = []  # 核心零外部依赖

[project.optional-dependencies]
dev = ["pytest", "rich"]  # 开发辅助
```

## 九、与 B/S 前端的对接设计

虽然不实现前端，但需提供清晰的接口边界：

```mermaid
sequenceDiagram
    participant FE as B/S 前端
    participant GW as WebSocket Gateway
    participant Agent as Agent Core

    FE->>GW: WebSocket 连接
    FE->>GW: {"type": "message", "content": "帮我清理系统垃圾"}
    GW->>Agent: Unix Socket / HTTP POST
    Agent->>Agent: Agent Loop 执行
    Agent-->>GW: SSE 流式事件推送
    Note over Agent,GW: {"event": "thinking", "data": "正在分析磁盘..."}<br/>{"event": "tool_call", "data": {...}}<br/>{"event": "safety_check", "data": {...}}<br/>{"event": "result", "data": "..."}
    GW-->>FE: WebSocket 逐帧转发
```

接口层暴露的协议：
- HTTP JSON API：`/api/chat`、`/api/sessions`、`/api/trace`
- Unix Domain Socket：本地高性能通信
- SSE 事件流：实时推送 Agent 执行过程

## 十、关键设计决策总结

| 决策点 | 选择 | 理由 |
|--------|------|------|
| 异步模型 | asyncio 单线程事件循环 | 避免 GIL 问题，适配 I/O 密集的运维场景 |
| 序列化 | dataclasses + json | 零依赖，LoongArch 完全兼容 |
| MCP 实现 | 自实现轻量版 | 官方 SDK 依赖 pydantic/httpx/anyio，编译风险 |
| 安全模型 | 规则引擎 + LLM 双重判定 | 规则保底确定性，LLM 补充语义理解 |
| 存储 | sqlite3 | stdlib 内置，无需安装数据库 |
| 进程隔离 | subprocess + setuid | 纯 OS 原语，无需容器 |
| LLM 调用 | urllib + 手动 SSE 解析 | 零依赖，LoongArch 无编译问题 |

这套方案的核心思路是：用 Python 标准库撑起骨架，通过架构设计而非重型框架来解决复杂度，确保在 LoongArch + 麒麟 V11 上开箱即用。