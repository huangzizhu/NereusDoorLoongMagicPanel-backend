---
type: reference
status: complete
created: 2026-06-05
tags:
  - api-reference
  - backend-integration
---

# NDLMPanel-Agent API 参考手册

[[Backend-Integration]](planning/Backend-Integration.md) · [[Operational-Flow]](analysis/Operational-Flow.md)

---

## 0. 安装与导入

```bash
# 安装（零外部依赖）
pip install -e /opt/ndlmpanel/agent/

# 验证
python -c "from ndlmpanel_agent import AgentSession; print('OK')"
```

```python
from ndlmpanel_agent import (
    AgentSession,   # 会话入口
    AgentConfig,    # 运行时配置
    AgentEvent,     # 事件流单元
    EventType,      # 事件类型枚举
    loadConfig,     # 配置加载器
    setupLogging,   # 日志初始化
)
from ndlmpanel_agent.agent_router.router import AgentMode  # 运行模式
from ndlmpanel_agent.compat.api_styles.openai_adapter import OpenAIAdapter   # SSE 格式化
from ndlmpanel_agent.compat.api_styles.claude_adapter import ClaudeAdapter   # SSE 格式化
```

---

## 1. AgentConfig — 运行时配置

### 1.1 字段速查

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `llm_provider` | `str` | `"deepseek"` | 供应商: `deepseek` / `qwen` / `openai_compat` |
| `llm_endpoint` | `str` | `""` | API 端点 URL（必填） |
| `llm_model` | `str` | `"deepseek-v4-pro"` | 模型名称 |
| `llm_max_tokens` | `int` | `65536` | 单次响应最大 token 数 |
| `llm_temperature` | `float` | `0.1` | 温度 (0-2)，运维推荐 0.1 |
| `llm_retry_count` | `int` | `3` | 失败重试次数 |
| `llm_retry_delay` | `float` | `2.0` | 重试间隔秒（指数退避基数） |
| `safety_policy` | `str` | `"default"` | 安全策略: `default` / `strict` |
| `execution_user` | `str` | `"osagent"` | 工具执行用户 |
| `max_tool_rounds` | `int` | `15` | 单次会话最大工具调用轮次 |
| `tool_timeout_seconds` | `int` | `60` | 工具执行超时秒数 |
| `trace_db_path` | `str` | `"runtime/sqlite/traces.db"` | 审计数据库路径 |
| `llm_api_key` | `str` | `""` | API Key（`repr=False`，不进日志） |

### 1.2 构造方式

```python
# 方式 1: 代码构造（后端动态配置）
config = AgentConfig(
    llm_endpoint="https://api.deepseek.com/anthropic",
    llm_model="deepseek-v4-pro",
    llm_max_tokens=65536,
    llm_temperature=0.1,
    safety_policy="strict",
)

# 敏感字段独立注入（不写配置文件）
config.llm_api_key = os.environ["NDLM_LLM_API_KEY"]

# 方式 2: 配置文件 + .env
# loadConfig 自动加载 .env → JSON → 环境变量
config = loadConfig("conf/profiles/production.json")

# 方式 3: 配置文件 + 运行时覆盖
config = loadConfig("conf/profiles/development.json",
                    overrides={"max_tool_rounds": 20},
                    envFile=".env")
```

### 1.3 环境变量映射

所有 `NDLM_*` 环境变量自动覆盖配置值（优先级: 运行时 > 环境变量 > JSON 文件 > 内置默认）。

| 环境变量 | 对应字段 |
|------|------|
| `NDLM_LLM_PROVIDER` | `llm_provider` |
| `NDLM_LLM_ENDPOINT` | `llm_endpoint` |
| `NDLM_LLM_MODEL` | `llm_model` |
| `NDLM_LLM_MAX_TOKENS` | `llm_max_tokens` |
| `NDLM_LLM_TEMPERATURE` | `llm_temperature` |
| `NDLM_SAFETY_POLICY` | `safety_policy` |
| `NDLM_EXECUTION_USER` | `execution_user` |
| `NDLM_MAX_TOOL_ROUNDS` | `max_tool_rounds` |
| `NDLM_TOOL_TIMEOUT_SECONDS` | `tool_timeout_seconds` |
| `NDLM_LLM_RETRY_COUNT` | `llm_retry_count` |
| `NDLM_LLM_RETRY_DELAY` | `llm_retry_delay` |
| `NDLM_LLM_API_KEY` | `llm_api_key`（机密，不进日志） |
| `NDLM_TRACE_DB_PATH` | `trace_db_path` |

---

## 2. AgentSession — 会话入口

### 2.1 构造

```python
class AgentSession:
    def __init__(
        self,
        config: AgentConfig,
        userId: str = "default",
        sessionId: str | None = None,  # None = 自动生成
        mode: AgentMode = AgentMode.AGENT,
    ):
```

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `config` | `AgentConfig` | (必填) | 运行时配置 |
| `userId` | `str` | `"default"` | 用户标识（审计用） |
| `sessionId` | `str \| None` | 自动生成 | 会话 ID（`sess_<12 hex>`） |
| `mode` | `AgentMode` | `AGENT` | 运行模式 |

### 2.2 运行模式

| 模式 | 枚举值 | 行为 |
|------|--------|------|
| 只读 | `AgentMode.READ_ONLY` | 只能查询，拒绝所有修改 |
| 计划 | `AgentMode.PLAN` | 查询 + 生成方案，不执行 |
| 执行 | `AgentMode.AGENT` | 低风险自动，高风险审批（默认） |
| 紧急 | `AgentMode.BREAK_GLASS` | 审批降级，强审计记录 |

```python
# 只读巡检
session = AgentSession(config, mode=AgentMode.READ_ONLY)

# 变更前评审
session = AgentSession(config, mode=AgentMode.PLAN)

# 事故应急
session = AgentSession(config, mode=AgentMode.BREAK_GLASS)
```

### 2.3 核心方法

```python
class AgentSession:
    # ── 消息提交 ──
    async def submit(self, message: str) -> AsyncIterator[AgentEvent]:
        """提交用户消息，返回异步事件流。

        使用方式:
            async for event in session.submit("查看系统状态"):
                yield formatSse(event)

        事件流保证以 DONE 或 ERROR 终止，不会永久挂起。
        调用方可随时 break，后台任务自动取消。
        """

    # ── 审批控制 ──
    def approve(self, actionId: str) -> bool:
        """批准待审批的高危操作。

        actionId 来自 APPROVAL_REQUIRED 事件的 data['action_id']。
        Returns: True = 放行成功, False = 无此动作（已超时或已处理）
        """

    def reject(self, actionId: str, reason: str = "") -> bool:
        """拒绝待审批的高危操作。"""

    # ── 生命周期 ──
    def getTrace(self) -> list[dict]:
        """获取当前会话的全部审计记录（SHA-256 哈希链）。
        Returns: [{"trace_id":"...","event_type":"...","entry_hash":"...","data":{...}}, ...]
        """

    def close(self) -> None:
        """关闭会话，取消后台任务，释放 SQLite 连接。"""

    # ── 静态工厂 ──
    @classmethod
    def fromConfigFile(cls, path: str, **kwargs) -> AgentSession:
        """从 JSON 配置文件创建 AgentSession。"""
```

---

## 3. AgentEvent — 事件流协议

### 3.1 数据结构

```python
@dataclass
class AgentEvent:
    type: str          # EventType 枚举值
    session_id: str    # 会话 ID
    trace_id: str      # 审计追溯 ID
    timestamp: float   # Unix 时间戳
    data: dict         # 事件载荷
```

### 3.2 EventType 完整列表

| EventType | 值 | data 字段 | 说明 |
|------|------|------|------|
| `SESSION_CREATED` | `session.created` | `user_id` | 会话创建 |
| `THINKING_START` | `thinking.start` | `round` | LLM 推理开始 |
| `THINKING_DELTA` | `thinking.delta` | `content` | 推理流片段（预留） |
| `THINKING_END` | `thinking.end` | — | 推理结束（预留） |
| `SAFETY_CHECKED` | `safety.checked` | `tool`, `risk`, `verdict`, `reason` | 安全校验完成 |
| `TOOL_CALLING` | `tool.calling` | `name`, `arguments` | 工具调用前（预留） |
| `TOOL_RESULT` | `tool.result` | `call_id`, `tool_name`, `success`, `output` | 工具执行结果 |
| `APPROVAL_REQUIRED` | `approval.required` | `tool_name`, `arguments`, `action_id`, `reason` | 需要审批 |
| `APPROVAL_RESOLVED` | `approval.resolved` | `action_id`, `approved`, `reason` | 审批已决议 |
| `TEXT_DELTA` | `text.delta` | `content` | 文本流片段 |
| `TEXT_DONE` | `text.done` | — | 本轮文本完成 |
| `ERROR` | `error` | `message` | 错误 |
| `DONE` | `done` | — | 会话结束 |

### 3.3 典型事件流

```
session.created → thinking.start → safety.checked → tool.result
     → thinking.start → text.delta {×N} → text.done → done
```

危险操作分支:
```
... → safety.checked → approval.required → [等待] → approval.resolved
     → tool.result → ...
```

---

## 4. 审批流程

### 4.1 状态机

```
用户消息 → LLM 推理 → LLM 返回 tool_call
                            ↓
                      Safety RuleEngine
                      ┌─────┼─────┐
                    ALLOW  REQUIRE  BLOCK
                      ↓    _CONFIRM   ↓
                   执行工具    ↓     拒绝
                             ↓
                      发出 APPROVAL_REQUIRED
                      挂起等待（默认 300s 超时）
                      ┌──────┼──────┐
                    approve  reject  timeout
                      ↓       ↓        ↓
                   执行工具  跳过    跳过+记录
```

### 4.2 后端集成示例

```python
pending_approvals: dict[str, asyncio.Queue] = {}

@app.post("/api/chat")
async def chat(request: Request):
    session = AgentSession(config, userId=user_id)

    async def generate():
        async for event in session.submit(message):
            if event.type == "approval.required":
                action_id = event.data["action_id"]
                # 推送审批请求给前端
                yield json.dumps({
                    "type": "approval_required",
                    "action_id": action_id,
                    "tool": event.data["tool_name"],
                    "reason": event.data["reason"],
                }) + "\n"
                # 等待用户决策（通过另一个接口传入）
                queue = asyncio.Queue()
                pending_approvals[action_id] = queue
                decision = await queue.get()
                if decision["approved"]:
                    session.approve(action_id)
                else:
                    session.reject(action_id, decision.get("reason", ""))
            else:
                yield OpenAIAdapter.formatSse(event)
    return StreamingResponse(generate(), media_type="text/event-stream")

@app.post("/api/approve")
async def approve(request: Request):
    """用户审批决策接口。"""
    body = await request.json()
    action_id = body["action_id"]
    if action_id in pending_approvals:
        await pending_approvals[action_id].put({"approved": True})
        return {"status": "ok"}
    return {"status": "not_found"}, 404
```

---

## 5. SSE 格式化

### 5.1 OpenAI 风格

```python
from ndlmpanel_agent.compat.api_styles.openai_adapter import OpenAIAdapter

# 输出格式:
#   data: {"id":"trace_...","object":"agent.event","created":...,"type":"...","delta":{"content":"..."}}
#   data: [DONE]

async for event in session.submit(message):
    yield OpenAIAdapter.formatSse(event)
```

### 5.2 Claude/Anthropic 风格

```python
from ndlmpanel_agent.compat.api_styles.claude_adapter import ClaudeAdapter

# 输出格式:
#   event: content_block_delta
#   data: {"type":"content_block_delta","index":1,"delta":{"type":"text_delta","text":"..."}}
#   event: message_stop
#   data: {"type":"message_stop"}

async for event in session.submit(message):
    yield ClaudeAdapter.formatSse(event)
```

---

## 6. FastAPI 集成完整示例

```python
# backend/app.py
import os, json, asyncio
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import StreamingResponse

from ndlmpanel_agent import AgentSession, AgentConfig, loadConfig
from ndlmpanel_agent.agent_router.router import AgentMode
from ndlmpanel_agent.compat.api_styles.openai_adapter import OpenAIAdapter

app = FastAPI(title="NDLMPanel Agent API")
config: AgentConfig | None = None

# 应用启动时加载配置
@app.on_event("startup")
async def startup():
    global config
    # 优先从环境变量，fallback 到配置文件
    config = loadConfig("conf/profiles/production.json")
    print(f"Agent ready: {config.llm_endpoint} / {config.llm_model}")


@app.post("/api/chat")
async def chat(request: Request):
    """提交运维指令，返回 SSE 事件流。

    Request Body:
        {"message": "查看系统负载", "mode": "agent", "user_id": "admin-01"}

    Response:  SSE (text/event-stream)
    """
    body = await request.json()
    message = body.get("message", "")
    if not message:
        raise HTTPException(400, "message 不能为空")

    mode = AgentMode(body.get("mode", "agent"))
    user_id = body.get("user_id", "default")

    session = AgentSession(config, userId=user_id, mode=mode)

    async def generate():
        async for event in session.submit(message):
            yield OpenAIAdapter.formatSse(event)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # Nginx 禁用缓冲
        },
    )


@app.post("/api/approve/{action_id}")
async def approve(action_id: str, request: Request):
    """批准/拒绝高危操作审批。

    Request Body: {"approved": true, "reason": ""}
    """
    body = await request.json()
    approved = body.get("approved", True)
    reason = body.get("reason", "")

    # 注意：实际应用中需要从 session 存储中查找对应的 session
    # 这里简化为伪代码
    if approved:
        ok = session.approve(action_id)
    else:
        ok = session.reject(action_id, reason)
    return {"action_id": action_id, "resolved": ok}


@app.get("/api/trace/{session_id}")
async def get_trace(session_id: str):
    """获取会话审计记录。"""
    traces = session.getTrace()
    return {"session_id": session_id, "traces": traces}


@app.get("/api/health")
async def health():
    """健康检查。"""
    return {"status": "ok", "version": "0.1.0"}
```

---

## 7. Flask 集成示例

```python
# backend/app.py
from flask import Flask, request, Response, stream_with_context
import asyncio, json
from ndlmpanel_agent import AgentSession, AgentConfig, loadConfig

app = Flask(__name__)
config = loadConfig("conf/profiles/production.json")

@app.route("/api/chat", methods=["POST"])
def chat():
    body = request.get_json()
    message = body.get("message", "")
    session = AgentSession(config, userId=body.get("user_id", "default"))

    def generate():
        loop = asyncio.new_event_loop()
        async def _collect():
            async for event in session.submit(message):
                if event.type == "text.delta":
                    yield f"data: {json.dumps({'type':'text','content':event.data.get('content','')}, ensure_ascii=False)}\n\n"
                elif event.type == "done":
                    yield "data: [DONE]\n\n"

        async def _run():
            async for chunk in _collect():
                yield chunk
        # 不推荐这种混合写法，FastAPI 的 async 支持更好
        ...

    return Response(stream_with_context(generate()), mimetype="text/event-stream")
```

---

## 8. 错误处理

### 8.1 事件流错误

AgentCore 保证所有异常都被捕获，事件流终以 `ERROR` 事件终止：

```python
async for event in session.submit(message):
    if event.type == "error":
        print(f"Agent error: {event.data['message']}")
        # 可向用户展示错误
        break
    elif event.type == "done":
        break
```

### 8.2 异常码速查

| ErrorCode | 值 | 含义 |
|------|------|------|
| `LLM_CONNECTION_FAILED` | E2001 | API 连接失败（401/5xx） |
| `LLM_RESPONSE_MALFORMED` | E2002 | 响应非合法 JSON |
| `LLM_RATE_LIMITED` | E2003 | API 限流 (429) |
| `SAFETY_BLOCKED` | E3001 | 安全规则阻断 |
| `INJECTION_DETECTED` | E3003 | 注入攻击检测 |
| `TOOL_NOT_FOUND` | E4001 | 工具未注册 |
| `TOOL_EXECUTION_FAILED` | E4002 | 工具执行失败 |
| `EXEC_PERMISSION_DENIED` | E5001 | 权限不足 |

---

## 9. 部署配置

### 9.1 systemd 服务单元

```ini
# /etc/systemd/system/ndlmpanel-backend.service
[Unit]
Description=NDLMPanel Agent Backend
After=network.target

[Service]
Type=simple
User=osagent
EnvironmentFile=/etc/ndlmpanel/env
ExecStart=/opt/ndlmpanel/.venv/bin/uvicorn backend.app:app --host 127.0.0.1 --port 8080
Restart=on-failure
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/var/lib/ndlmpanel

[Install]
WantedBy=multi-user.target
```

### 9.2 Nginx 反向代理

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:8080;
    proxy_buffering off;           # SSE 核心：禁止缓冲
    proxy_cache off;
    proxy_read_timeout 3600s;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

### 9.3 安全环境文件

```bash
# /etc/ndlmpanel/env (chmod 600, chown osagent:osagent)
NDLM_LLM_API_KEY=sk-xxx
NDLM_LLM_ENDPOINT=https://api.deepseek.com/anthropic
NDLM_LLM_MODEL=deepseek-v4-pro
NDLM_SAFETY_POLICY=strict
NDLM_EXECUTION_USER=osagent-exec
NDLM_TRACE_DB_PATH=/var/lib/ndlmpanel/traces.db
```

---

## 10. 附录: 完整请求示例

### curl

```bash
# 流式对话
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"查看系统负载","mode":"agent","user_id":"admin"}' \
  --no-buffer

# 查询审计
curl http://localhost:8080/api/trace/sess_abc123
```

### JavaScript (前端)

```javascript
const response = await fetch("/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    message: "查看系统负载",
    mode: "agent",
    user_id: "admin-01",
  }),
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  const lines = decoder.decode(value).split("\n");
  for (const line of lines) {
    if (line.startsWith("data: ")) {
      const payload = line.slice(6);
      if (payload === "[DONE]") break;
      const event = JSON.parse(payload);
      if (event.type === "text.delta") {
        console.log(event.delta.content); // 流式打字效果
      } else if (event.type === "approval.required") {
        // 弹出审批对话框
        const decision = await showApprovalDialog(event.approval);
        await fetch(`/api/approve/${event.approval.action_id}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(decision),
        });
      }
    }
  }
}
```
