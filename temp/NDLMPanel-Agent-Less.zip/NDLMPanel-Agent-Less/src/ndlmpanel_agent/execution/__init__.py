"""Execution 代理 — 最小权限 subprocess 执行。"""
from ndlmpanel_agent.execution.executor import runCommand
__all__ = ["runCommand"]
