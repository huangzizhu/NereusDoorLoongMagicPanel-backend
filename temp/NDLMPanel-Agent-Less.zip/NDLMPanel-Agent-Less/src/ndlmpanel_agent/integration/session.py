"""AgentSession — 对外唯一入口。

后端（FastAPI）通过 AgentSession 与 Agent 内核交互：
    session = AgentSession(config)
    async for event in session.submit("帮我看看磁盘") :
        yield formatSSE(event)

S6 更新：AgentCore 替换 Worker 模式。
"""
from __future__ import annotations
from collections.abc import AsyncIterator
from ndlmpanel_agent.shared.types import AgentConfig, AgentEvent, EventType
from ndlmpanel_agent.shared.id_gen import gen_session_id, gen_trace_id
from ndlmpanel_agent.config_envs.loader import loadConfig
from ndlmpanel_agent.integration.event_stream import EventStream
from ndlmpanel_agent.safety.rule_engine import RuleEngine
from ndlmpanel_agent.mcp.server.registry import ToolRegistry
from ndlmpanel_agent.mcp.server.dispatcher import McpDispatcher
from ndlmpanel_agent.agent_core.prompt_builder import PromptBuilder
from ndlmpanel_agent.agent_core.agent_loop import AgentCore
from ndlmpanel_agent.trace_log.recorder import TraceRecorder
from ndlmpanel_agent.llm_providers.factory import createProvider
from ndlmpanel_agent.agent_router.router import AgentMode, getModePrompt
from ndlmpanel_agent.plugins import registerAll


class AgentSession:
    """Agent 会话 — 一次对话的生命周期。"""

    def __init__(self, config: AgentConfig,
                 userId: str = "default",
                 sessionId: str | None = None,
                 mode: AgentMode = AgentMode.AGENT):
        self._config = config
        self._userId = userId
        self._sessionId = sessionId or gen_session_id()
        self._mode = mode

        # 初始化日志体系（幂等，多 session 共享同一套 handler）
        from ndlmpanel_agent.trace_log.logging_setup import setupLogging
        setupLogging()

        # 加载 Prompt 模板
        import os as _os
        root = _os.path.dirname(_os.path.dirname(_os.path.dirname(
            _os.path.dirname(_os.path.abspath(__file__)))))
        sysPromptPath = _os.path.join(root, "conf", "prompts", "system", "v1.1.0.txt")
        safetyRulesPath = _os.path.join(root, "conf", "prompts", "safety", "rules_summary.txt")

        try:
            with open(sysPromptPath) as f:
                sysPrompt = f.read()
        except FileNotFoundError:
            sysPrompt = "你是一个智能运维助手。"

        # 注入模式约束 (ReadOnly/Plan/Agent/BreakGlass)
        sysPrompt += getModePrompt(mode)
        try:
            with open(safetyRulesPath) as f:
                safetyRules = f.read()
        except FileNotFoundError:
            safetyRules = ""

        # 工具注册 — 通过 TOOLS dict 自动发现全部插件
        registry = ToolRegistry()
        registerAll(registry)

        # 核心组件
        safety = RuleEngine()
        dispatcher = McpDispatcher(registry)
        promptBuilder = PromptBuilder(sysPrompt, safetyRules, registry.listTools())

        # LLM Provider — 由工厂按 config.llm_provider 选择，
        # 无 api_key 时自动回退 MockProvider
        self._llm = createProvider(config)
        # Anthropic 格式需要把工具列表作为 tools 参数发送
        if hasattr(self._llm, "setTools"):
            self._llm.setTools(registry.listTools())

        self._recorder = TraceRecorder(config.trace_db_path)
        self._core = AgentCore(
            llmProvider=self._llm, registry=registry,
            dispatcher=dispatcher, safety=safety,
            promptBuilder=promptBuilder,
            maxRounds=config.max_tool_rounds,
            maxTokens=config.llm_max_tokens,
        )
        self._core.setRecorder(self._recorder)
        self._runTask: "asyncio.Task | None" = None

    @classmethod
    def fromConfigFile(cls, path: str, **kwargs) -> AgentSession:
        config = loadConfig(path)
        return cls(config, **kwargs)

    async def submit(self, message: str) -> AsyncIterator[AgentEvent]:
        """提交用户消息，返回事件流。"""
        import asyncio
        stream = EventStream(self._sessionId)
        stream.emit(EventType.SESSION_CREATED, {"user_id": self._userId})
        self._recorder.record(stream.traceId, self._sessionId,
                              EventType.SESSION_CREATED, {"user_id": self._userId})

        # 运行 AgentCore 循环。run() 内部保证无论成功/异常都会向 stream
        # 发出终止事件（DONE / ERROR），因此消费端 async for 不会永久挂起。
        self._runTask = asyncio.create_task(self._core.run(message, stream))

        try:
            async for ev in stream:
                yield ev
        finally:
            # 消费提前结束（如调用方 break）时，确保后台任务被妥善取消
            if self._runTask and not self._runTask.done():
                self._runTask.cancel()

    def approve(self, actionId: str) -> bool:
        """批准一个待审批的高危动作。

        Returns:
            True = 成功放行；False = 无此 action_id（已超时或已处理）
        """
        ok = self._core.approve(actionId)
        if ok:
            self._recorder.record(gen_trace_id(), self._sessionId,
                                  EventType.APPROVAL_RESOLVED,
                                  {"action_id": actionId, "approved": True})
        return ok

    def reject(self, actionId: str, reason: str = "") -> bool:
        """拒绝一个待审批的高危动作。"""
        ok = self._core.reject(actionId, reason)
        if ok:
            self._recorder.record(gen_trace_id(), self._sessionId,
                                  EventType.APPROVAL_RESOLVED,
                                  {"action_id": actionId, "approved": False,
                                   "reason": reason})
        return ok

    def getTrace(self) -> list[dict]:
        """获取当前会话的全部审计记录。"""
        return self._recorder.query(sessionId=self._sessionId)

    def close(self) -> None:
        """关闭会话，释放资源。"""
        if self._runTask and not self._runTask.done():
            self._runTask.cancel()
        self._recorder.close()
