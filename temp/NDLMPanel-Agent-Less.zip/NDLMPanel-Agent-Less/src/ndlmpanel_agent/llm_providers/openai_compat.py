"""
OpenAI-compatible Provider。

使用 stdlib urllib.request 发送请求，零外部依赖。
支持流式(stream=True，逐行读取)和非流式调用，含指数退避重试与结构化错误。
"""
from __future__ import annotations
import asyncio
import json
import urllib.error
import urllib.request
from collections.abc import AsyncIterator

from ndlmpanel_agent.llm_providers.base import LLMProvider
from ndlmpanel_agent.shared.errors import AgentError, ErrorCode
from ndlmpanel_agent.shared.types import LLMResponse


class OpenAIProvider(LLMProvider):
    """OpenAI Compatible API Provider — urllib 实现。"""

    def __init__(self, endpoint: str, apiKey: str = "",
                 model: str = "deepseek-chat", maxTokens: int = 4096,
                 temperature: float = 0.7, retryCount: int = 2,
                 retryDelay: float = 1.0, timeout: float = 120.0):
        self._endpoint = endpoint.rstrip("/")
        self._apiKey = apiKey
        self._model = model
        self._maxTokens = maxTokens
        self._temperature = temperature
        self._retryCount = retryCount
        self._retryDelay = retryDelay
        self._timeout = timeout

    # ── 非流式 ──

    async def chat(self, messages: list[dict]) -> LLMResponse:
        body = self._buildBody(messages, stream=False)
        raw = await self._postWithRetry(body)
        return self._parseResponse(raw)

    # ── 流式（逐行读取）──

    async def chatStream(
        self, messages: list[dict]
    ) -> AsyncIterator[LLMResponse]:
        """流式对话 — 逐行读取 SSE，边到边 yield。

        通过后台线程运行阻塞的 urllib 读取，用 asyncio.Queue 把每个
        chunk 桥接回事件循环，实现真正的增量输出（首 token 不必等整体）。
        重试只覆盖"建立连接 + 首字节"阶段；流式传输中途断开按错误抛出。
        """
        body = self._buildBody(messages, stream=True)
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue = asyncio.Queue()
        _SENTINEL = object()

        def _runner():
            try:
                req = self._buildRequest(body)
                with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                    for rawLine in resp:
                        line = rawLine.decode("utf-8", errors="replace").strip()
                        if not line or not line.startswith("data:"):
                            continue
                        payload = line[len("data:"):].strip()
                        if payload == "[DONE]":
                            break
                        loop.call_soon_threadsafe(queue.put_nowait, payload)
            except Exception as exc:  # noqa: BLE001 — 转交主协程统一抛出
                loop.call_soon_threadsafe(queue.put_nowait, exc)
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, _SENTINEL)

        # 在线程池启动阻塞读取（不 await，让其后台运行）
        loop.run_in_executor(None, _runner)

        while True:
            item = await queue.get()
            if item is _SENTINEL:
                break
            if isinstance(item, Exception):
                raise self._wrapHttpError(item)
            parsed = self._parseStreamChunk(item)
            if parsed is not None:
                yield parsed
        # 结束标记
        yield LLMResponse(content=None, finish_reason="stop")

    # ── 内部：请求构造 ──

    def _buildBody(self, messages: list[dict], stream: bool) -> bytes:
        return json.dumps({
            "model": self._model,
            "messages": messages,
            "max_tokens": self._maxTokens,
            "temperature": self._temperature,
            "stream": stream,
        }).encode("utf-8")

    def _buildRequest(self, body: bytes) -> urllib.request.Request:
        return urllib.request.Request(
            f"{self._endpoint}/chat/completions",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._apiKey}",
            },
            method="POST",
        )

    # ── 内部：带重试的同步 POST ──

    async def _postWithRetry(self, body: bytes) -> str:
        loop = asyncio.get_running_loop()
        lastError: AgentError | None = None

        for attempt in range(self._retryCount + 1):
            try:
                return await loop.run_in_executor(None, self._httpPost, body)
            except urllib.error.HTTPError as exc:
                wrapped = self._wrapHttpError(exc)
                # 401/4xx（除 429）不可恢复，立即抛出
                if exc.code != 429 and 400 <= exc.code < 500:
                    raise wrapped
                lastError = wrapped
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                lastError = self._wrapHttpError(exc)

            if attempt < self._retryCount:
                delay = self._retryDelay * (2 ** attempt)  # 指数退避
                await asyncio.sleep(delay)

        assert lastError is not None
        raise lastError

    def _httpPost(self, body: bytes) -> str:
        """同步 HTTP POST。在 run_in_executor 中执行。"""
        req = self._buildRequest(body)
        with urllib.request.urlopen(req, timeout=self._timeout) as resp:
            return resp.read().decode("utf-8")

    def _wrapHttpError(self, exc: Exception) -> AgentError:
        """把底层异常映射为带错误码的 AgentError。"""
        if isinstance(exc, AgentError):
            return exc
        if isinstance(exc, urllib.error.HTTPError):
            status = exc.code
            try:
                detailBody = exc.read().decode("utf-8", errors="replace")[:500]
            except Exception:  # noqa: BLE001
                detailBody = ""
            finally:
                try:
                    exc.close()
                except Exception:  # noqa: BLE001
                    pass
            if status == 429:
                return AgentError(ErrorCode.LLM_RATE_LIMITED,
                                  "LLM API 限流 (429)",
                                  {"status": status, "body": detailBody})
            if status == 401:
                return AgentError(ErrorCode.LLM_CONNECTION_FAILED,
                                  "LLM API Key 无效或未授权 (401)",
                                  {"status": status})
            return AgentError(ErrorCode.LLM_CONNECTION_FAILED,
                              f"LLM API HTTP 错误 ({status})",
                              {"status": status, "body": detailBody})
        if isinstance(exc, (TimeoutError,)):
            return AgentError(ErrorCode.TIMEOUT, "LLM API 请求超时")
        # URLError / OSError
        return AgentError(ErrorCode.LLM_CONNECTION_FAILED,
                          f"LLM API 连接失败: {exc}")

    # ── 内部：响应解析 ──

    def _parseResponse(self, raw: str) -> LLMResponse:
        """解析非流式 JSON 响应为 LLMResponse。"""
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise AgentError(ErrorCode.LLM_RESPONSE_MALFORMED,
                             f"LLM 响应非合法 JSON: {exc}") from exc

        choice = data.get("choices", [{}])[0]
        msg = choice.get("message", {})

        content = msg.get("content")
        toolCalls = []
        for tc in msg.get("tool_calls", []):
            fn = tc.get("function", {})
            try:
                args = json.loads(fn.get("arguments", "{}"))
            except json.JSONDecodeError:
                args = {}
            toolCalls.append({
                "id": tc.get("id", ""),
                "name": fn.get("name", ""),
                "arguments": args,
            })

        return LLMResponse(content=content, tool_calls=toolCalls,
                           finish_reason=choice.get("finish_reason", "stop"),
                           usage=data.get("usage", {}))

    def _parseStreamChunk(self, payload: str) -> LLMResponse | None:
        """解析单个 SSE data chunk，返回增量 LLMResponse 或 None。"""
        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            return None
        choice = obj.get("choices", [{}])[0]
        delta = choice.get("delta", {})
        finish = choice.get("finish_reason") or ""
        content = delta.get("content")
        if content:
            return LLMResponse(content=content, finish_reason=finish,
                               usage=obj.get("usage", {}))
        if finish:
            return LLMResponse(content=None, finish_reason=finish,
                               usage=obj.get("usage", {}))
        return None
