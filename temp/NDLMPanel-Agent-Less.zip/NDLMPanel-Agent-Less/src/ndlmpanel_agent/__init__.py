"""
NDLMPanel-Agent — 智能运维 Agent 内核

纯 Python 标准库实现，零外部依赖。
目标平台：LoongArch + 麒麟高级服务器版 V11，Python 3.10+。

公共 API：
    from ndlmpanel_agent import AgentSession, AgentConfig, loadConfig
"""

__version__ = "0.1.0"

from ndlmpanel_agent.shared.types import AgentConfig, AgentEvent, EventType
from ndlmpanel_agent.config_envs.loader import loadConfig
from ndlmpanel_agent.integration.session import AgentSession
from ndlmpanel_agent.trace_log.logging_setup import setupLogging, getLogger

__all__ = [
    "AgentSession",
    "AgentConfig",
    "AgentEvent",
    "EventType",
    "loadConfig",
    "setupLogging",
    "getLogger",
    "__version__",
]
