"""API 风格适配器 — OpenAI / Claude / Native。"""
from ndlmpanel_agent.compat.api_styles.openai_adapter import OpenAIAdapter
from ndlmpanel_agent.compat.api_styles.claude_adapter import ClaudeAdapter
__all__ = ["OpenAIAdapter", "ClaudeAdapter"]
