"""MCP 请求分发器 — initialize / tools/list / tools/call / ping。"""

import json
from ndlmpanel_agent.mcp.protocol.json_rpc import (
    decodeRequest,
    encodeResult,
    encodeError,
    METHOD_NOT_FOUND,
    INTERNAL_ERROR,
)
from ndlmpanel_agent.mcp.server.registry import ToolRegistry


class McpDispatcher:
    def __init__(
        self,
        registry: ToolRegistry,
        serverName: str = "ndlmpanel-agent",
        serverVersion: str = "0.1.0",
    ):
        self._reg = registry
        self._name = serverName
        self._ver = serverVersion

    def handle(self, raw: str) -> str:
        req = decodeRequest(raw)
        try:
            h = getattr(self, f"_handle_{req.method.replace('/', '_')}", None)
            if h is None:
                return encodeError(req.id, METHOD_NOT_FOUND, f"未知方法: {req.method}")
            result = h(req.params)
            return encodeResult(req.id, result)
        except Exception as exc:
            return encodeError(req.id, INTERNAL_ERROR, str(exc))

    def _handle_initialize(self, params: dict) -> dict:
        return {
            "protocolVersion": "2024-11-05",
            "serverInfo": {"name": self._name, "version": self._ver},
            "capabilities": {"tools": {}},
        }

    def _handle_tools_list(self, params: dict) -> dict:
        return {"tools": self._reg.listTools()}

    def _handle_tools_call(self, params: dict) -> dict:
        name = params.get("name", "")
        args = params.get("arguments", {})
        func = self._reg.getTool(name)
        if func is None:
            raise ValueError(f"工具未注册: {name}")
        result = func(**args)
        if hasattr(result, "__dataclass_fields__"):
            import dataclasses

            output = json.dumps(
                dataclasses.asdict(result), ensure_ascii=False, indent=2, default=str
            )
        elif (
            isinstance(result, list)
            and result
            and hasattr(result[0], "__dataclass_fields__")
        ):
            import dataclasses

            output = json.dumps(
                [dataclasses.asdict(r) for r in result],
                ensure_ascii=False,
                indent=2,
                default=str,
            )
        else:
            output = json.dumps(result, ensure_ascii=False, default=str)
        return {"content": [{"type": "text", "text": output}], "isError": False}

    def _handle_ping(self, params: dict) -> dict:
        return {}
