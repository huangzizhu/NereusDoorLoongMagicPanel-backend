"""工具注册中心。"""
from __future__ import annotations

from collections.abc import Callable
from ndlmpanel_agent.mcp.protocol.schemas import functionToToolSchema
from ndlmpanel_agent.shared.types import ToolDefinition, ToolRiskLevel


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Callable] = {}
        self._riskLevels: dict[str, ToolRiskLevel] = {}

    def register(self, func: Callable, riskLevel: ToolRiskLevel = ToolRiskLevel.WRITE):
        self._tools[func.__name__] = func
        self._riskLevels[func.__name__] = riskLevel

    def registerMany(
        self, funcs: list[Callable], riskLevel: ToolRiskLevel = ToolRiskLevel.WRITE
    ):
        for f in funcs:
            self.register(f, riskLevel)

    def registerModule(self, module) -> int:
        """自动注册模块中 TOOLS dict 声明的所有工具。

        模块需导出 `TOOLS: dict[str, ToolRiskLevel]`，
        键为函数名，值为风险等级。
        函数必须存在于模块的全局命名空间中。

        Returns:
            成功注册的工具数量
        """
        toolMap: dict[str, ToolRiskLevel] = getattr(module, "TOOLS", {})
        count = 0
        for name, riskLevel in toolMap.items():
            func = getattr(module, name, None)
            if func is not None and callable(func):
                self.register(func, riskLevel)
                count += 1
        return count

    def listTools(self) -> list[dict]:
        schemas = [functionToToolSchema(f) for f in self._tools.values()]
        schemas.sort(key=lambda s: s["function"]["name"])
        return schemas

    def getTool(self, name: str) -> Callable | None:
        return self._tools.get(name)

    def getRiskLevel(self, name: str) -> ToolRiskLevel:
        return self._riskLevels.get(name, ToolRiskLevel.WRITE)
