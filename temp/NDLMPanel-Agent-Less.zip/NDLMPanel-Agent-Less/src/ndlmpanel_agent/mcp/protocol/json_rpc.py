"""
最小 JSON-RPC 2.0 实现 — 仅 MCP 所需子集。
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Any

JSONRPC_VERSION = "2.0"
PARSE_ERROR = -32700
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603


@dataclass
class JsonRpcRequest:
    jsonrpc: str = JSONRPC_VERSION
    id: int | str | None = None
    method: str = ""
    params: dict[str, Any] = field(default_factory=dict)


def encodeRequest(
    method: str, params: dict | None = None, reqId: int | str | None = None
) -> str:
    req = {"jsonrpc": JSONRPC_VERSION, "method": method, "params": params or {}}
    if reqId is not None:
        req["id"] = reqId
    return json.dumps(req, ensure_ascii=False)


def decodeRequest(raw: str) -> JsonRpcRequest:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        return JsonRpcRequest(id=None, method="")
    return JsonRpcRequest(
        id=data.get("id"),
        method=data.get("method", ""),
        params=data.get("params", {}),
    )


def encodeResult(reqId: int | str | None, result: Any) -> str:
    return json.dumps(
        {"jsonrpc": JSONRPC_VERSION, "id": reqId, "result": result}, ensure_ascii=False
    )


def encodeError(reqId: int | str | None, code: int, message: str) -> str:
    return json.dumps(
        {
            "jsonrpc": JSONRPC_VERSION,
            "id": reqId,
            "error": {"code": code, "message": message},
        },
        ensure_ascii=False,
    )
