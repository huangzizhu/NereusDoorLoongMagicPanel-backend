"""函数签名 → JSON Schema 自动生成。"""

from __future__ import annotations
import enum, inspect, types
from typing import Any, get_args, get_origin

_PRIMITIVE_MAP = {
    str: {"type": "string"},
    int: {"type": "integer"},
    float: {"type": "number"},
    bool: {"type": "boolean"},
}


def annotationToJsonSchema(annotation: Any) -> dict:
    if annotation in _PRIMITIVE_MAP:
        return dict(_PRIMITIVE_MAP[annotation])
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        return {"type": "string", "enum": [m.value for m in annotation]}
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin is list:
        item = {"type": "string"}
        if args:
            item = annotationToJsonSchema(args[0])
        return {"type": "array", "items": item}
    isUnion = origin is types.UnionType if hasattr(types, "UnionType") else False
    try:
        import typing

        isUnion = isUnion or (origin is typing.Union)
    except AttributeError:
        pass
    if isUnion and args:
        nonNone = [a for a in args if a is not type(None)]
        if nonNone:
            return annotationToJsonSchema(nonNone[0])
    return {"type": "string"}


def functionToToolSchema(func) -> dict:
    sig = inspect.signature(func)
    props: dict = {}
    required: list = []
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        props[name] = annotationToJsonSchema(param.annotation)
        if param.default is inspect.Parameter.empty:
            required.append(name)
    return {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": (func.__doc__ or "").strip().split("\n")[0],
            "parameters": {"type": "object", "properties": props, "required": required},
        },
    }
