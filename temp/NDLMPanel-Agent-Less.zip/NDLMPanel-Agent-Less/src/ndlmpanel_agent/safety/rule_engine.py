"""
安全规则引擎。

从原 safety_guard.py 迁移，去掉 pydantic 依赖。
三层检查：READ_ONLY 放行 → 高危参数模式 → DANGEROUS 需确认。
"""
from __future__ import annotations
import re
from ndlmpanel_agent.shared.types import ToolRiskLevel, SafetyVerdict

_DANGEROUS_PATTERNS: list[tuple[re.Pattern, str]] = [
    # ── 路径类 ──
    (re.compile(r"(^|[/\\])\.\.\s*$"), "路径包含 .. 可能导致目录穿越"),
    (re.compile(r"^/$"), "操作根目录 / 极其危险"),
    (re.compile(r"^/(etc|boot|usr|lib|sbin|bin|proc|sys)\b"), "操作系统关键目录"),
    (re.compile(r"^/home$"), "操作 /home 根目录"),
    (re.compile(r"/etc/(shadow|passwd|sudoers|gshadow)\b"), "操作认证/权限关键文件"),
    (re.compile(r"~?/\.ssh\b"), "操作 SSH 密钥目录"),
    # ── 权限类 ──
    (re.compile(r"\b777\b"), "chmod 777 权限过于宽松"),
    (re.compile(r"\b000\b"), "chmod 000 会导致文件不可访问"),
    (re.compile(r"\bchmod\s+-R\s", re.IGNORECASE), "递归修改权限风险高"),
    (re.compile(r"\bchown\s+(-R\s+)?root\b", re.IGNORECASE), "变更属主为 root"),
    # ── 信号/进程类 ──
    (re.compile(r"\b(SIGKILL|9)\b"), "SIGKILL 无法被进程捕获，可能导致数据丢失"),
    # ── 删除/格式化类（命令级，匹配命令字符串任意位置）──
    (re.compile(r"\brm\s+(-\w*[rRfF]\w*\s+)+/(\s|$|\*)"), "rm -rf 作用于根/系统路径"),
    (re.compile(r"\bmkfs\.\w+"), "格式化文件系统"),
    (re.compile(r"\bdd\s+if=\S*\s+of=/dev/(sd|nvme|vd|hd)", re.IGNORECASE),
     "dd 直接写裸磁盘设备"),
    (re.compile(r">\s*/dev/(sd|nvme|vd|hd)\w*"), "重定向覆盖磁盘设备"),
    (re.compile(r"\bwipefs\b"), "擦除文件系统签名"),
    # ── 网络/数据外传类 ──
    (re.compile(r"\b(curl|wget)\b.+\|\s*(ba|z|k)?sh\b", re.IGNORECASE),
     "下载内容直接管道执行（远程代码执行风险）"),
    (re.compile(r"\biptables\s+-F\b", re.IGNORECASE), "清空防火墙规则"),
    (re.compile(r"\bnc\b.+-e\b", re.IGNORECASE), "netcat 反弹 shell 风险"),
    # ── 提权类 ──
    (re.compile(r"\bsudo\s+su\b", re.IGNORECASE), "提权到 root 交互式 shell"),
    (re.compile(r"\bsu\s+-\s*root\b", re.IGNORECASE), "切换到 root 用户"),
    # ── Fork bomb / 任意代码执行 ──
    (re.compile(r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:"), "fork bomb"),
    (re.compile(r"\b(python|perl|ruby|php)\d?\s+-c\b", re.IGNORECASE),
     "解释器 -c 执行任意代码"),
    (re.compile(r"\beval\b", re.IGNORECASE), "eval 执行动态拼接命令"),
    # ── 系统状态类 ──
    (re.compile(r"\b(shutdown|reboot|halt|poweroff)\b", re.IGNORECASE),
     "关机/重启系统"),
    (re.compile(r"\bsystemctl\s+(stop|disable|mask)\b", re.IGNORECASE),
     "停用关键系统服务"),
]

class RuleEngine:
    """安全规则引擎。"""

    def checkToolCall(self, toolName: str, riskLevel: ToolRiskLevel,
                      arguments: dict) -> SafetyVerdict:
        """校验工具调用安全性。

        Args:
            toolName: 工具名
            riskLevel: 工具风险等级
            arguments: 工具参数字典
        """
        # Layer 1: READ_ONLY 直接放行
        if riskLevel == ToolRiskLevel.READ_ONLY:
            return SafetyVerdict.ALLOW

        # Layer 2: 检查高危参数模式
        values = []
        for v in arguments.values():
            if isinstance(v, str):
                values.append(v)
            elif isinstance(v, (int, float)):
                values.append(str(v))
        for value in values:
            for pat, _reason in _DANGEROUS_PATTERNS:
                if pat.search(value):
                    return SafetyVerdict.REQUIRE_CONFIRM

        # Layer 3: DANGEROUS 级别需确认
        if riskLevel == ToolRiskLevel.DANGEROUS:
            return SafetyVerdict.REQUIRE_CONFIRM

        return SafetyVerdict.ALLOW

    def checkToolCallWithReason(self, toolName: str, riskLevel: ToolRiskLevel,
                                arguments: dict) -> tuple[SafetyVerdict, str]:
        """与 checkToolCall 相同，但额外返回原因字符串。"""
        if riskLevel == ToolRiskLevel.READ_ONLY:
            return SafetyVerdict.ALLOW, "只读操作，自动放行"

        values = []
        for v in arguments.values():
            if isinstance(v, str):
                values.append(v)
            elif isinstance(v, (int, float)):
                values.append(str(v))
        for value in values:
            for pat, reason in _DANGEROUS_PATTERNS:
                if pat.search(value):
                    return SafetyVerdict.REQUIRE_CONFIRM, f"参数触发安全规则: {reason}"

        if riskLevel == ToolRiskLevel.DANGEROUS:
            return SafetyVerdict.REQUIRE_CONFIRM, f"高危操作 [{toolName}] 需要人工确认"

        return SafetyVerdict.ALLOW, "校验通过"
