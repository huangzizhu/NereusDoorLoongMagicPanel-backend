"""ContextManagement — 系统快照采集 + 上下文压缩。"""
from ndlmpanel_agent.context_mgmt.collectors import getSystemSnapshot
from ndlmpanel_agent.context_mgmt.compressor import compressHistory
__all__ = ["getSystemSnapshot", "compressHistory"]
