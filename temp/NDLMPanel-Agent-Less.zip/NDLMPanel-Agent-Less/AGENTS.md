# NDLMPanel-Agent — 项目总览

## 项目定位

部署于 Linux 操作系统的智能运维 Agent 内核（Agent Kernel）。
- **目标平台**：LoongArch + 麒麟高级服务器版 V11
- **Python 版本**：3.10+，**零外部依赖**，仅使用标准库
- **集成方式**：作为 Python 包被后端（FastAPI / Flask）导入使用
- **参考设计**：[[Design-1]](docs/design/Design-1.md) · [[Design-2]](docs/design/Design-2.md) · [[Skeleton-Design]](docs/design/Skeleton-Design.md)
- **进度**：全部 5 Phase 已完成（122 测试），详见 [[Implementation-Plan]](docs/planning/Implementation-Plan-Next.md)
- **API 文档**：[[API-Reference]](docs/API-Reference.md) · [[后端对接]](docs/planning/Backend-Integration.md)

## 快速开始

```bash
# 环境准备（使用标准 venv，不用 uv）
python3 -m venv .venv && source .venv/bin/activate
pip install -e .

# 验证
python -c "from ndlmpanel_agent.shared.types import AgentConfig; print('OK')"
```

## 架构总览

```
backend (FastAPI / Flask)
  └── AgentSession.submit(message) → AsyncIterator[AgentEvent]
       └── AgentCore.run()  [纯 asyncio 状态机，ReAct 循环]
            ├── Safety        → RuleEngine (3层检查) + InjectionDetector (13条规则)
            ├── PromptBuilder  → 4层 KV-Cache 优化 Prompt (L1静态/L2半静态/L3会话/L4请求)
            ├── LLMProvider   → OpenAI-compat (stdlib urllib) / Mock (离线测试)
            ├── McpDispatcher → tools/list + tools/call (JSON-RPC 2.0)
            │    └── plugins/* → 纯 /proc + subprocess (零外部依赖)
            └── TraceRecorder → JSONL + SQLite + SHA-256 哈希链 (防篡改审计)
```

## 模块清单

| 模块 | 文件 | 职责 |
|------|:--:|------|
| `shared/` | 5 | 核心 dataclass 类型、错误码枚举、序列化工具、ID 生成、运维返回类型 |
| `config_envs/` | 3 | JSON 多级合并配置加载 + 环境变量覆盖 + 密钥管理 |
| `safety/` | 2 | 规则引擎（READ_ONLY通行/高危参数匹配/DANGEROUS确认）+ Prompt Injection 检测 |
| `agent_core/` | 2 | 4层 KV-Cache 优化 Prompt 组装器 + Agent ReAct 循环状态机 |
| `context_mgmt/` | 2 | /proc 系统快照采集器 + 对话历史压缩器 |
| `mcp/` | 5 | JSON-RPC 2.0 编解码 + 函数签名→Schema 自动生成 + ToolRegistry + McpDispatcher + stdio Transport |
| `plugins/` | 2 | os_observe (/proc) + filesystem (基础文件操作) |
| `llm_providers/` | 4 | 抽象接口 + OpenAI-compat (urllib实现) + SSE 流式解析器 + Mock (离线测试) |
| `compat/` | 2 | OpenAI SSE 适配器 + Claude/Anthropic SSE 适配器 |
| `integration/` | 2 | AgentSession 对外入口 + EventStream (asyncio.Queue) |
| `execution/` | 1 | subprocess 安全执行器 (路径黑白名单/shell=False/超时控制/环境清洗) |
| `trace_log/` | 4 | 事件记录器 + SQLite 存储 + SHA-256 哈希链 + 敏感信息脱敏 |
| **合计** | **34** | |

## 数据流（一次完整请求）

```
用户消息 "帮我查看系统 CPU 使用率"
  → AgentSession.submit()
    → checkPromptInjection()          # 注入检测
    → PromptBuilder.build()           # 4层 Prompt 组装
    → AgentCore.run()                 # ReAct 循环
      → [THINKING]
        → LLM.chat(messages)          # urllib HTTP POST
        → [tool_calls] → EXECUTING
          → RuleEngine.checkToolCall() # 安全校验 (3层)
          → [ALLOW] → McpDispatcher.handle(tools/call)
            → plugins.getCpuInfo()    # /proc/cpuinfo + /proc/stat
          → [BLOCK] → ERROR
          → [REQUIRE_CONFIRM] → APPROVAL_REQUIRED (当前有bug: 仍会执行)
        → 结果追加到 messages → LOOP
      → [text] → TEXT_DELTA → TEXT_DONE → DONE
    → TraceRecorder.record()          # 每步审计 (JSONL+SQLite+SHA-256)
    → EventStream → AgentEvent
```

## 命名约定

- 文件名：`snake_case.py`
- 函数/方法：`camelCase`（与 JavaScript/原项目约定一致）
- 类名：`PascalCase`
- 常量：`UPPER_SNAKE_CASE`

## 测试

```bash
# 全部测试 (54 项，全部通过)
.venv/bin/python -m unittest discover tests/ -v

# 单个模块
.venv/bin/python -m unittest tests/unit/test_mcp_dispatcher.py -v

# 冒烟测试 (Config → MCP → Plugin 全链路)
.venv/bin/python -m unittest tests/smoke/test_smoke.py -v
```

## 与后端对接

```python
from ndlmpanel_agent import AgentSession
from ndlmpanel_agent.shared.types import AgentConfig
from ndlmpanel_agent.compat.api_styles import OpenAIAdapter

# 方式一: 配置文件
session = AgentSession.fromConfigFile(
    "conf/profiles/production.json",
    userId="admin-01"
)

# 方式二: 代码配置
config = AgentConfig(llm_endpoint="https://api.deepseek.com/v1")
config.llm_api_key = os.environ["DEEPSEEK_API_KEY"]
session = AgentSession(config, userId="admin-01")

# 流式输出
async for event in session.submit("帮我看看系统负载"):
    sse = OpenAIAdapter.formatSse(event)
    yield sse  # FastAPI StreamingResponse
```

## 配置文件

```
conf/
├── profiles/
│   ├── development.json    # 开发环境 (safety_policy: default)
│   └── production.json     # 生产环境 (safety_policy: strict, user: osagent-exec)
└── prompts/
    ├── system/v1.0.0.txt   # System Prompt (版本化, 完全静态保证 KV Cache 命中)
    └── safety/rules_summary.txt  # 安全规则摘要 (嵌入 Prompt L1 层)
```

## 环境变量

| 变量 | 说明 | 必填 |
|------|------|:--:|
| `NDLM_LLM_API_KEY` | LLM API Key | ✅ |
| `NDLM_LLM_ENDPOINT` | API 地址 (覆盖配置文件) | |
| `NDLM_LLM_MODEL` | 模型名称 (覆盖配置文件) | |
| `NDLM_LLM_MAX_TOKENS` | 最大输出 token 数 | |
| `NDLM_SAFETY_POLICY` | 安全策略名称 | |
| `NDLM_EXECUTION_USER` | 工具执行用户 | |
| `NDLM_MAX_TOOL_ROUNDS` | 最大工具调用轮次 | |
| `NDLM_TOOL_TIMEOUT_SECONDS` | 工具执行超时秒数 | |
| `NDLM_TRACE_DB_PATH` | 审计数据库路径 | |

## 关键设计决策

1. **零外部依赖**：全部使用 Python 3.10 stdlib，保证 LoongArch + 麒麟 V11 开箱即用
2. **dataclass 替代 pydantic**：丢失自动校验能力，但通过 `__post_init__` 手动校验覆盖核心需求
3. **asyncio 替代 LangGraph**：Agent Loop 本质是 ReAct while 循环，不需要图引擎
4. **urllib 替代 openai SDK**：需手写 SSE 解析 (~90行)，但避免 openai 及其依赖链
5. **`/proc` 解析替代 psutil**：需手写解析逻辑 (~200行)，但去掉唯一的 C 扩展依赖
6. **4 层 KV Cache 优化**：L1 静态前缀跨用户共享，L2 同 Profile 共享，最大化前缀缓存命中率
7. **SHA-256 哈希链防篡改**：每条 trace 记录链接前一条，形成不可篡改的审计证据链

## 当前进度

全部 5 个 Phase 已完成（122 项测试全部通过）。
详见 [[计划文档]](docs/planning/Implementation-Plan-Next.md) · [[后端对接]](docs/planning/Backend-Integration.md) · [[运作流程]](docs/analysis/Operational-Flow.md)

| 阶段 | 状态 | 成果 |
|------|:--:|------|
| Phase A 修 Bug + 安全地基 | ✅ | 3 P0 bug 修复，27 组安全规则，risk_scorer，.env+日志初始化 |
| Phase B Provider + 真机 API | ✅ | Anthropic Provider + 工厂，指数退避重试，真流式 SSE |
| Phase C 插件迁移 + 自动注册 | ✅ | 48 工具/5 平铺插件(全部 psutil→/proc+subprocess)，TOOLS dict 自动发现 |
| Phase D Core 集成 + 策略配置 | ✅ | TraceRecorder+Context 集成到 AgentCore，策略 JSON 配置 |
| Phase E Router + Skills + 文档 | ✅ | 4 种运行模式，Prompt 预设 6 个诊断技能，后端对接文档 |

## 项目目录

```
NDLMPanel-Agent-Less/
├── src/ndlmpanel_agent/
│   ├── shared/               # 公共类型 (types/errors/serialization/id_gen/ops_types)
│   ├── config_envs/          # 配置管理 (loader/dotenv/schema/secrets)
│   ├── safety/               # 安全护栏 (rule_engine/injection_detector/risk_scorer)
│   ├── agent_core/           # Agent 核心 (agent_loop/prompt_builder)
│   ├── agent_router/         # 模式路由 (AgentMode: ReadOnly/Plan/Agent/BreakGlass)
│   ├── context_mgmt/         # 上下文管理 (collectors/compressor)
│   ├── mcp/                  # MCP 协议引擎 (json_rpc/schemas/registry/dispatcher/stdio)
│   ├── plugins/              # 运维工具插件 (5 模块 48 工具)
│   ├── llm_providers/        # LLM 适配层 (base/openai_compat/sse_parser/mock/factory)
│   ├── compat/               # API 兼容层 (openai_adapter/claude_adapter)
│   ├── integration/          # 后端对接层 (session/event_stream)
│   ├── execution/            # 最小权限执行 (executor)
│   └── trace_log/            # 审计日志 (recorder/storage/hash_chain/sanitizer/logging_setup)
├── conf/                     # 配置 + Prompt 模板
├── runtime/                  # 运行时数据 (logs/traces/sqlite)
├── tests/                    # 122 项测试 (全部通过)
├── docs/                     # 文档
│   ├── design/               # 设计文档 (Design-1/2, Skeleton-Design)
│   ├── analysis/             # 分析文档 (Gap-Analysis, Project-File-Analysis, MCP/Operational/Execution)
│   ├── planning/             # 计划文档 (Implementation-Plan-Next)
│   └── scripts/              # 构建/验证脚本 (build/, verify/)
├── NDLMPanel-Agent/          # 原项目 (参考，不再修改)
└── AGENTS.md                 # 本文件
```
