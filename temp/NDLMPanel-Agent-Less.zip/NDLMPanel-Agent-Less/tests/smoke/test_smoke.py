import json, os, tempfile, unittest
from ndlmpanel_agent.config_envs.loader import loadConfig
from ndlmpanel_agent.mcp.protocol.json_rpc import encodeRequest
from ndlmpanel_agent.mcp.server.registry import ToolRegistry
from ndlmpanel_agent.mcp.server.dispatcher import McpDispatcher
from ndlmpanel_agent.shared.types import ToolRiskLevel
from ndlmpanel_agent.plugins import observation, filesystem

class TestSmoke(unittest.TestCase):
    def test_fullPipeline(self):
        # 1. Config
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
        json.dump({"llm_endpoint": "https://api.test.com"}, tmp)
        tmp.close()
        cfg = loadConfig(tmp.name, envFile=None)
        self.assertEqual(cfg.llm_endpoint, "https://api.test.com")
        os.unlink(tmp.name)

        # 2. Register tools via auto-discovery
        reg = ToolRegistry()
        reg.register(observation.getCpuInfo, ToolRiskLevel.READ_ONLY)
        reg.register(observation.getMemoryInfo, ToolRiskLevel.READ_ONLY)
        reg.register(filesystem.listDirectory, ToolRiskLevel.READ_ONLY)

        # 3. MCP tools/list
        disp = McpDispatcher(reg)
        d = json.loads(disp.handle(encodeRequest("tools/list", {}, 1)))
        self.assertEqual(len(d["result"]["tools"]), 3)

        # 4. MCP tools/call getCpuInfo
        d = json.loads(disp.handle(encodeRequest("tools/call",
            {"name": "getCpuInfo", "arguments": {}}, 2)))
        cpu = json.loads(d["result"]["content"][0]["text"])
        self.assertGreater(cpu["coreCount"], 0)

        # 5. MCP tools/call getMemoryInfo
        d = json.loads(disp.handle(encodeRequest("tools/call",
            {"name": "getMemoryInfo", "arguments": {}}, 3)))
        mem = json.loads(d["result"]["content"][0]["text"])
        self.assertGreater(mem["totalBytes"], 0)

    def test_autoRegistration(self):
        """验证 registerModule 自动发现 TOOLS dict。"""
        reg = ToolRegistry()
        count = reg.registerModule(observation)
        self.assertGreater(count, 5)  # 至少 5 个工具
        self.assertEqual(count, len(observation.TOOLS))

        count2 = reg.registerModule(filesystem)
        self.assertEqual(count2, len(filesystem.TOOLS))

        # 所有注册的工具都可被 listTools 列出
        schemas = reg.listTools()
        self.assertGreaterEqual(len(schemas), count + count2)
