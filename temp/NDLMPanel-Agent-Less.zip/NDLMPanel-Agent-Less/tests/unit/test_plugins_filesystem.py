import os, tempfile, unittest, shutil
from ndlmpanel_agent.plugins.filesystem import listDirectory, createDirectory, deleteFile

class TestFilesystem(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)
    def test_create_and_list(self):
        sub = os.path.join(self.tmpdir, "subdir")
        self.assertTrue(createDirectory(sub).success)
        items = listDirectory(self.tmpdir)
        self.assertTrue(any(i.name == "subdir" and i.isDirectory for i in items))
    def test_delete_file(self):
        f = os.path.join(self.tmpdir, "test.txt")
        with open(f, "w") as fh: fh.write("data")
        self.assertTrue(deleteFile(f).success)
        self.assertFalse(os.path.exists(f))
    def test_delete_nonexistent(self):
        self.assertFalse(deleteFile(os.path.join(self.tmpdir, "no_such_file")).success)
