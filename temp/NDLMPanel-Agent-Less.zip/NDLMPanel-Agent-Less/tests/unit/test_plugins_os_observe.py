import unittest
from ndlmpanel_agent.plugins.observation import (
    getCpuInfo, getMemoryInfo, getUptime, getSystemVersion,
    getDiskInfo, listUsers,
)

class TestObservation(unittest.TestCase):
    def test_getCpuInfo(self):
        i = getCpuInfo()
        self.assertGreater(i.coreCount, 0)

    def test_getMemoryInfo(self):
        i = getMemoryInfo()
        self.assertGreater(i.totalBytes, 0)

    def test_getUptime(self):
        i = getUptime()
        self.assertGreater(i["uptimeSeconds"], 0)

    def test_getSystemVersion(self):
        i = getSystemVersion()
        self.assertTrue(len(i.get("osName", "")) > 0)

    def test_getDiskInfo(self):
        parts = getDiskInfo()
        self.assertIsInstance(parts, list)

    def test_listUsers(self):
        users = listUsers()
        self.assertIsInstance(users, list)
        if users:
            self.assertTrue(users[0].userName)
